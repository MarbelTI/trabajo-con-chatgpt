# F. Diagrama entidad-relación

**Nueva Acrópolis** · Fase 1 (relaciones públicas) · PostgreSQL / Supabase

Vista gráfica de `07-esquema-fisico.md`. **`07` manda**: si algo aquí lo contradice, el error está aquí.

| Formato | Archivo | Para qué |
|---|---|---|
| HTML | `08-diagrama-er.html` | Página autónoma: abrir en el navegador. Los 5 diagramas, las 33 tablas campo por campo, filtro y export a PDF con Imprimir |
| Mermaid | este documento | Se renderiza solo en GitHub, VS Code y `mermaid.live` |
| DBML | `08-diagrama-er.dbml` | Pegar en [dbdiagram.io](https://dbdiagram.io/d) → ERD navegable, export PNG/PDF/SVG |
| SQL | `07-esquema-fisico.md` §4 | El DDL real, única fuente de verdad |

El HTML carga Mermaid desde CDN. Sin conexión sigue sirviendo: las tablas y campos son HTML plano,
y cada diagrama cae a su código fuente en vez de quedarse en blanco.

**33 tablas** · 26 de dominio · 6 catálogos de enums abiertos · 1 de auditoría de identidad.
Más `auth.users`, externa (Supabase la gobierna, F9).

## Cómo leer estos diagramas

- `||--o{` uno a muchos · `||--||` uno a uno · `|o--||` cero-o-uno a uno · `}o--o{` muchos a muchos
- **Auditoría omitida a propósito.** Casi toda tabla tiene `registrado_por` / `modificado_por` → `usuarios(id)`.
  Son ~40 aristas hacia el mismo nodo; dibujarlas oculta el modelo. Están completas en `07` §5.2 y en el
  bloque final del `.dbml`.
- **Ninguna FK usa `ON DELETE CASCADE`.** Todas `RESTRICT`: RN-41 dice que no se borra nada, y un
  `CASCADE` sería una puerta trasera al borrado. El retiro es `personas.archivada`.
- **DENORM** marca una columna mantenida por trigger, no una fuente de verdad: existe porque la RLS la
  necesita sin hacer un join (F5).
- **CONGELADO** marca un valor calculado a la fecha del hecho y nunca recalculado (RN-17, DP-10).

---

## 1. Mapa general

Todas las tablas y sus relaciones estructurales, sin campos. Cinco módulos: organización,
persona, actividad, seguimiento y acceso.

```mermaid
erDiagram
  sedes ||--o{ areas : "tiene"
  sedes ||--o{ personas_sedes : "recibe vinculos"
  sedes ||--o{ grupos : "aloja"
  sedes ||--o{ actividades : "organiza"
  sedes ||--o{ participaciones : "DENORM RLS"
  sedes ||--o{ marcas_revision : "DENORM RLS"
  sedes ||--o{ permisos_sede : "delimita"
  sedes ||--o{ periodos_reporte : "reporta"
  sedes ||--o{ personas : "sede_vigente DENORM"

  areas ||--o{ roles_asignados : "encuadra"
  areas ||--o{ contactos_enlace : "custodia"
  areas ||--o{ organizaciones_aliadas : "custodia"
  areas ||--o{ permisos_area : "delimita"

  personas ||--o{ personas_contactos : "tiene"
  personas ||--o{ personas_sedes : "pertenece a"
  personas ||--o{ estados_persona : "recorre"
  personas ||--o{ roles_asignados : "desempena"
  personas ||--o{ historial_identidad_persona : "audita"
  personas ||--o{ participaciones : "participa"
  personas ||--o{ inscripciones : "se inscribe"
  personas ||--o{ atribuciones_captacion : "es captada"
  personas ||--o{ interacciones : "recibe"
  personas ||--o{ notas_ficha : "acumula"
  personas ||--o{ intereses_declarados : "declara"
  personas ||--o{ consentimientos_contacto : "otorga"
  personas ||--o{ contactos_enlace : "es enlace"
  personas ||--o{ marcas_revision : "genera"
  personas ||--o{ grupos : "profesor"
  personas |o--o| personas : "fusionada_en"
  personas ||--o{ atribuciones_captacion : "invito a"
  personas ||--o| usuarios : "opera como"

  ocupaciones ||--o{ personas : "clasifica"

  cursos ||--o{ grupos : "se dicta en"
  cursos |o--o| cursos : "prerrequisito"
  grupos ||--o{ inscripciones : "matricula"
  grupos ||--o{ actividades : "genera clases"
  grupos ||--o{ roles_asignados : "celaduria"

  actividades ||--o{ participaciones : "convoca"
  actividades ||--o{ atribuciones_captacion : "capta en"
  actividades ||--o{ actividades_etiquetas : ""
  etiquetas ||--o{ actividades_etiquetas : ""
  actividades ||--o{ marcas_revision : "genera"
  participaciones ||--o{ marcas_revision : "genera"

  tipos_actividad ||--o{ actividades : "tipifica"
  tipos_actividad ||--o{ intereses_declarados : "tipifica"
  medios_difusion ||--o{ atribuciones_captacion : "explica"
  organizaciones_aliadas ||--o{ atribuciones_captacion : "refiere"
  organizaciones_aliadas ||--o{ actividades : "coorganiza"
  tipos_organizacion_aliada ||--o{ organizaciones_aliadas : "tipifica"
  tipos_enlace ||--o{ contactos_enlace : "tipifica"
  tipos_marca_revision ||--o{ marcas_revision : "tipifica"

  usuarios ||--o{ permisos_sede : "recibe"
  usuarios ||--o{ permisos_area : "recibe"
  usuarios ||--o{ interacciones : "registra"
  usuarios ||--o{ notas_ficha : "escribe"
  auth_users ||--|| usuarios : "F9 Supabase"
```

---

## 2. Persona e identidad

El núcleo. *"las personas son la base de todo, de ahí parte todo"* (30-jul).

Tres tablas de historial cuelgan de `personas` y las tres son **append-only**: `estados_persona`
(RN-01), `historial_identidad_persona` (RN-47) y `notas_ficha` (RN-40). La vigencia se expresa
siempre igual: `hasta IS NULL`, con índice único parcial y `EXCLUDE USING gist` contra solapamientos.

```mermaid
erDiagram
  personas {
    uuid id PK
    enum cedula_tipo "V o E · UK parcial con cedula"
    text cedula "ID-1 · nunca obligatoria en esquema DP-24"
    text nombre "RN-53 · lo unico obligatorio"
    text apellido "DP-31 opcional"
    text nombre_completo "GENERATED"
    text nombre_busqueda "GENERATED · pg_trgm dedup F7"
    date fecha_nacimiento
    boolean es_menor_de_edad "trigger · a la fecha de registro RN-37"
    text representante_nombre
    text representante_telefono
    text representante_parentesco
    uuid ocupacion_id FK
    text ocupacion_otro "DP-17"
    text direccion
    uuid sede_vigente_id FK "DENORM F5 · lo exige la RLS"
    enum estado_vigente "DENORM desde estados_persona"
    enum ultimo_estado_alcanzado "RN-11"
    text punto_de_salida "llego hasta el tema tal"
    boolean contacto_bloqueado "RN-42"
    date contacto_bloqueado_en
    boolean sigue_en_invitaciones "DP-07"
    boolean archivada "RN-41 · sustituye al borrado"
    uuid fusionada_en FK "ID-7 · autorreferencia"
    uuid registrado_por FK "RN-06 · FK DIFERIDA"
    timestamptz registrado_en
    uuid modificado_por FK
    timestamptz modificado_en
  }

  personas_contactos {
    uuid id PK
    uuid persona_id FK
    enum tipo "TELEFONO CORREO INSTAGRAM..."
    text valor "tal como se capturo · IMP-04"
    text valor_normalizado "trigger · clave de busqueda RN-39"
    boolean es_principal "UK parcial por tipo"
    boolean es_valido "GENERATED · regex por tipo"
  }

  personas_sedes {
    uuid id PK
    uuid persona_id FK
    uuid sede_id FK
    date desde
    date hasta "NULL = vigente · UK parcial"
    enum motivo_fin "TRASLADO_FILIAL BAJA OTRO"
  }

  estados_persona {
    uuid id PK
    uuid persona_id FK
    enum estado "CONTACTO ASISTENTE PROBACIONISTA MIEMBRO INACTIVO"
    date desde
    date hasta "NULL = vigente · EXCLUDE gist"
    text disparador "inscripcion graduacion retiro reingreso"
    boolean es_automatico "solo CONTACTO a ASISTENTE"
  }

  roles_asignados {
    uuid id PK
    uuid persona_id FK
    enum rol "INSTRUCTOR CELADOR ENCARGADO_AREA..."
    uuid area_id FK "RN-09 lo exige en 2 roles"
    uuid grupo_id FK "celaduria de un curso"
    date desde
    date hasta "DP-12 · el informe cuenta ACTIVOS"
  }

  historial_identidad_persona {
    uuid id PK
    uuid persona_id FK
    text campo "cedula nombre apellido telefono"
    text valor_anterior
    text valor_nuevo
    uuid cambiado_por FK
    timestamptz cambiado_en
  }

  sedes {
    uuid id PK
    text codigo UK
    text nombre
    text zona_horaria "RN-55 F8 · corte de mes local"
    boolean es_central "UK parcial · una sola"
    boolean activa
  }

  areas {
    uuid id PK
    uuid sede_id FK "el area existe POR SEDE"
    text codigo UK
    text nombre
    boolean activa
  }

  ocupaciones {
    uuid id PK
    text codigo UK
    text etiqueta
    boolean es_semilla "19 valores reales del xlsx"
  }

  personas ||--o{ personas_contactos : "1:N · un principal por tipo"
  personas ||--o{ personas_sedes : "1:N · un solo vigente DP-03"
  personas ||--o{ estados_persona : "1:N · append-only RN-01"
  personas ||--o{ roles_asignados : "1:N · acumulables RN-08"
  personas ||--o{ historial_identidad_persona : "1:N · append-only"
  personas |o--o| personas : "fusionada_en ID-7"
  ocupaciones ||--o{ personas : "N:1"
  sedes ||--o{ personas_sedes : "1:N"
  sedes ||--o{ personas : "sede_vigente DENORM"
  sedes ||--o{ areas : "1:N"
  areas ||--o{ roles_asignados : "N:1 opcional"
```

---

## 3. Actividad, curso y participación

`participaciones` es el corazón: su par único `(persona_id, actividad_id)` elimina de raíz el
duplicado que hoy produce el Excel (P04, IMP-05).

Dos campos van **congelados a la fecha del hecho** —`es_interno_en_la_fecha` y
`categoria_oina_en_la_fecha`— porque el informe de un mes pasado no puede cambiar cuando alguien
se gradúa hoy (RN-17).

`atribuciones_captacion` es el bucle A del análisis: se captura **por evento**, no una vez por
persona, y `invitado_por_persona_id` es un selector de personas, nunca texto libre (RN-20).

```mermaid
erDiagram
  cursos {
    uuid id PK
    text nombre UK
    smallint nivel
    uuid curso_prerequisito_id FK "RN-19 autorreferencia"
    boolean es_probacionismo "define interno RN-10"
    boolean activo
  }

  grupos {
    uuid id PK
    uuid curso_id FK
    uuid sede_id FK
    uuid profesor_persona_id FK
    enum dia "LUNES a DOMINGO"
    time hora
    date fecha_inicio
    date fecha_fin
  }

  actividades {
    uuid id PK
    uuid sede_id FK
    uuid tipo_actividad_id FK
    enum linea "FILOSOFIA CULTURA VOLUNTARIADO"
    enum circulo "PRIMER SEGUNDO TERCER · DP-01"
    text titulo "convocatoria · NADA CAMBIA SI TU NO CAMBIAS"
    text tema "canonico RN-16 · no se inventa P21"
    timestamptz inicio "UTC · corte en zona de sede"
    timestamptz fin
    text lugar "Biblioteca Tariba"
    uuid grupo_id FK "opcional RN-38 · la clase suelta"
    uuid organizacion_aliada_id FK
    enum estado "PLANIFICADA REALIZADA CANCELADA"
    boolean es_gratuita
    integer cupo "RN-43 avisa NUNCA bloquea"
  }

  participaciones {
    uuid id PK
    uuid persona_id FK
    uuid actividad_id FK
    uuid sede_id FK "DENORM RLS F5"
    boolean asistio
    boolean es_interno_en_la_fecha "CONGELADO RN-17"
    enum categoria_oina_en_la_fecha "CONGELADO · informe"
    boolean pago_entrada "extension futura"
    text comentario_experiencia "86% de llenado"
  }

  inscripciones {
    uuid id PK
    uuid persona_id FK
    uuid grupo_id FK
    enum estado "INSCRITO NO_INSCRITO RETIRADO"
    date fecha_inscripcion
    date fecha_retiro
    text dias_asistencia "literal de la planilla"
    text horarios "literal de la planilla"
    uuid encargado_persona_id FK
  }

  atribuciones_captacion {
    uuid id PK
    uuid persona_id FK
    uuid actividad_id FK "por EVENTO RN-20"
    uuid medio_id FK
    uuid invitado_por_persona_id FK "selector NUNCA texto libre"
    uuid organizacion_aliada_id FK
    boolean es_primera_captacion "UK parcial · la del informe"
    boolean invitado_por_interno "RN-44 derivado a la fecha"
    text nota "MILAGRO Y ALEJANDRO"
    date fecha
  }

  actividades_etiquetas {
    uuid actividad_id PK
    uuid etiqueta_id PK
  }

  etiquetas {
    uuid id PK
    text nombre
    text nombre_normalizado UK "154 valores sucios en el xlsx P17"
  }

  medios_difusion {
    uuid id PK
    text codigo UK
    text etiqueta
    boolean exige_persona "RN-20"
    boolean exige_organizacion "RN-20"
  }

  organizaciones_aliadas {
    uuid id PK
    text nombre UK
    text nombre_busqueda "GENERATED"
    uuid tipo_id FK
    uuid area_custodia_id FK
    boolean activa
  }

  tipos_actividad {
    uuid id PK
    text codigo UK
    text etiqueta
  }

  personas {
    uuid id PK
    text nombre
  }

  cursos ||--o{ grupos : "1:N"
  cursos |o--o| cursos : "prerrequisito RN-19"
  grupos ||--o{ inscripciones : "1:N"
  grupos ||--o{ actividades : "1:N opcional RN-38"
  personas ||--o{ inscripciones : "1:N · par unico"
  personas ||--o{ grupos : "profesor"
  personas ||--o{ participaciones : "1:N"
  actividades ||--o{ participaciones : "1:N · PAR UNICO P04"
  actividades ||--o{ atribuciones_captacion : "1:N"
  personas ||--o{ atribuciones_captacion : "1:N · una primera"
  personas ||--o{ atribuciones_captacion : "invito a · autorref"
  medios_difusion ||--o{ atribuciones_captacion : "N:1"
  organizaciones_aliadas ||--o{ atribuciones_captacion : "N:1"
  organizaciones_aliadas ||--o{ actividades : "N:1"
  tipos_actividad ||--o{ actividades : "N:1"
  actividades ||--o{ actividades_etiquetas : "N:M"
  etiquetas ||--o{ actividades_etiquetas : "N:M"
```

---

## 4. Seguimiento, interés y consentimiento

Todo cuelga de `personas`. La regla que ordena el módulo: **guardar nunca se bloquea** (RN-46).
Lo que falta o no cuadra no produce un error: produce una fila en `marcas_revision`, que es una
bandeja de pendientes real y no un booleano perdido (DP-36).

`consentimientos_contacto` se registra pero **no filtra envíos** (RN-12, DP-09). Es una tensión
consciente con `01-contexto` §9, no un olvido.

```mermaid
erDiagram
  personas {
    uuid id PK
    text nombre
    boolean contacto_bloqueado "RN-42"
    boolean archivada "RN-41"
  }

  interacciones {
    uuid id PK
    uuid persona_id FK
    uuid usuario_id FK
    enum canal "LLAMADA WHATSAPP CORREO VISITA"
    timestamptz ocurrio_en
    enum resultado "INTERESADO NO_RESPONDIO SIN_CONTACTAR"
    text nota "NO PUEDE POR EL HORARIO"
  }

  notas_ficha {
    uuid id PK
    uuid persona_id FK
    uuid usuario_id FK
    text texto
    timestamptz escrita_en "append-only · sin notas privadas DP-20"
  }

  intereses_declarados {
    uuid id PK
    uuid persona_id FK
    enum linea "vigente = ultimo POR LINEA RN-52"
    uuid tipo_actividad_id FK
    text tema_sugerido "25% de llenado"
    enum interes_curso "SI NO SIN_DATO"
    date declarado_en
  }

  consentimientos_contacto {
    uuid id PK
    uuid persona_id FK
    boolean acepta
    boolean otorgado_por_representante "menores RN-37"
    date fecha
    text origen "planilla puerta verbal"
    date revocado_en
  }

  contactos_enlace {
    uuid id PK
    uuid persona_id FK
    uuid area_custodia_id FK "RN-28"
    uuid tipo_enlace_id FK
    text organizacion
    boolean es_restringido "hay gente del gobierno"
  }

  marcas_revision {
    uuid id PK
    uuid tipo_id FK
    uuid persona_id FK "CK · exactamente UNA de las 3"
    uuid actividad_id FK
    uuid participacion_id FK
    uuid sede_id FK "DENORM RLS"
    text detalle "valor original sin transformar IMP-04"
    enum origen "FORMULARIO IMPORTACION"
    timestamptz creada_en
    timestamptz resuelta_en
    uuid resuelta_por FK
  }

  tipos_enlace {
    uuid id PK
    text codigo UK
    text etiqueta
  }

  tipos_marca_revision {
    uuid id PK
    text codigo UK
    text etiqueta
    boolean aplica_persona
    boolean aplica_actividad
    boolean aplica_participacion
  }

  areas {
    uuid id PK
    text nombre
  }

  usuarios {
    uuid id PK
    text correo UK
  }

  personas ||--o{ interacciones : "1:N · RN-24"
  personas ||--o{ notas_ficha : "1:N · append-only"
  personas ||--o{ intereses_declarados : "1:N"
  personas ||--o{ consentimientos_contacto : "1:N · informativo"
  personas ||--o{ contactos_enlace : "1:N · misma persona DP-08"
  personas ||--o{ marcas_revision : "1:N"
  areas ||--o{ contactos_enlace : "custodia"
  tipos_enlace ||--o{ contactos_enlace : "N:1"
  tipos_marca_revision ||--o{ marcas_revision : "N:1"
  usuarios ||--o{ interacciones : "quien llamo"
  usuarios ||--o{ notas_ficha : "quien escribio"
```

---

## 5. Usuario, permiso y reporte

`usuarios` es tabla propia en `public`; en `auth` nunca se escribe (F9). RN-50: todo usuario es
antes una persona de la escuela —de ahí el `1:0..1`, y de ahí el ciclo `personas` ↔ `usuarios`
que obliga a diferir `fk_personas_registrado_por` (§5.2 de `07`).

Los permisos llevan **vigencia**: sin `desde` / `hasta`, quien recibió acceso durante un relevo
seguiría leyendo todo después (RN-54, DP-35).

`periodos_reporte.totales` es `jsonb` **congelado al cerrar**: el informe enviado tiene que poder
reproducirse tal como se envió (DP-10, RN-31).

```mermaid
erDiagram
  auth_users {
    uuid id PK "esquema auth · Supabase lo gobierna"
  }

  usuarios {
    uuid id PK
    uuid auth_user_id FK "UK · 1:1 con auth.users"
    uuid persona_id FK "UK · 1:0..1 RN-50"
    text correo UK
    boolean acceso_global "RN-29 director y secretaria"
    boolean activo
  }

  personas {
    uuid id PK
    text nombre
    uuid registrado_por FK "FK DIFERIDA · el ciclo"
  }

  permisos_sede {
    uuid id PK
    uuid usuario_id FK
    uuid sede_id FK
    enum nivel "LECTURA ESCRITURA · no hay borrado"
    date desde
    date hasta "RN-54 · sin esto no hay relevo"
    uuid otorgado_por FK
  }

  permisos_area {
    uuid id PK
    uuid usuario_id FK
    uuid area_id FK
    enum nivel "LECTURA ESCRITURA"
    date desde
    date hasta
    uuid otorgado_por FK
  }

  periodos_reporte {
    uuid id PK
    uuid sede_id FK
    smallint anio
    smallint mes "UK con sede y anio"
    boolean es_cierre_semestral
    enum estado "ABIERTO CERRADO ENVIADO DEVUELTO"
    jsonb totales "CONGELADO al cerrar DP-10"
    timestamptz cerrado_en
    uuid cerrado_por FK
  }

  sedes {
    uuid id PK
    text codigo UK
    text zona_horaria "el corte de mes es local"
  }

  areas {
    uuid id PK
    uuid sede_id FK
    text codigo UK
  }

  auth_users ||--|| usuarios : "1:1 · F9"
  personas ||--o| usuarios : "1:0..1 · RN-50"
  usuarios ||--o{ personas : "registrado_por · CICLO diferido"
  usuarios ||--o{ permisos_sede : "1:N con vigencia"
  usuarios ||--o{ permisos_area : "1:N con vigencia"
  sedes ||--o{ permisos_sede : "N:1"
  sedes ||--o{ areas : "1:N"
  sedes ||--o{ periodos_reporte : "1:N"
  areas ||--o{ permisos_area : "N:1"
```

---

## 6. Catálogos de enums abiertos

Decisión F1: **enum cerrado → tipo nativo de Postgres; enum abierto → tabla de catálogo.** Un enum
abierto es aquel donde el usuario crea valores en caliente (RN-15, RN-21, DP-17) —*"tú puedes crear
medios también"* (30-jul)—. Añadir un valor a un tipo nativo exige migración; añadir una fila no.

Los seis tienen la misma forma: `codigo` UK, `etiqueta`, `es_semilla`, `creado_por`.

```mermaid
erDiagram
  ocupaciones ||--o{ personas : "E-07 · 19 semillas del xlsx"
  tipos_actividad ||--o{ actividades : "E-03"
  tipos_actividad ||--o{ intereses_declarados : "E-03"
  medios_difusion ||--o{ atribuciones_captacion : "E-11 · exige_persona / exige_organizacion"
  tipos_organizacion_aliada ||--o{ organizaciones_aliadas : "E-12"
  tipos_enlace ||--o{ contactos_enlace : "E-13"
  tipos_marca_revision ||--o{ marcas_revision : "E-21 · DP-36"
  etiquetas ||--o{ actividades_etiquetas : "RN-15 · libres, N:M"
```

**Los 17 enums cerrados**, que sí son tipos nativos: `estado_persona`, `linea_actividad`,
`rol_persona`, `circulo_actividad`, `categoria_oina`, `motivo_fin_vinculo`, `estado_inscripcion`,
`canal_interaccion`, `resultado_contacto`, `interes_curso`, `nivel_permiso`, `tipo_cedula`,
`estado_actividad`, `tipo_contacto_persona`, `dia_semana`, `estado_periodo_reporte`, `origen_marca`.

---

## 7. Cardinalidades con nombre

| Relación | Card. | Regla |
|---|---|---|
| `personas` — `personas_sedes` — `sedes` | 1:N / N:1 | Un solo vínculo vigente (DP-03) |
| `personas` — `estados_persona` | 1:N | Append-only, uno vigente (RN-01) |
| `personas` — `personas_contactos` | 1:N | Un principal por tipo (DP-33) |
| `personas` — `roles_asignados` — `areas` | 1:N / N:1 | Acumulables, con vigencia (RN-08, DP-12) |
| `personas` — `participaciones` — `actividades` | 1:N / N:1 | **Par único** (P04) |
| `actividades` — `grupos` | N:1 opcional | La clase suelta también es actividad (RN-38) |
| `actividades` — `actividades_etiquetas` — `etiquetas` | N:M | *"día de la tierra más algo de arte"* |
| `personas` — `atribuciones_captacion` | 1:N | Por evento; una sola primera captación |
| `atribuciones_captacion` — `personas` (invitó) | N:1 opcional | Autorreferencia, selector (RN-20) |
| `personas` — `usuarios` | 1:0..1 | Solo algunas personas operan el sistema |
| `usuarios` — `permisos_sede` / `permisos_area` | 1:N | Con vigencia (RN-54) |
| `usuarios` — `auth.users` | 1:1 | Supabase gobierna el lado `auth` (F9) |

---

## 8. Trazabilidad

Este documento no introduce reglas: las dibuja. Cada nota apunta a su origen en
`03-especificacion-de-dominio.md` (RN, ID), `05-decisiones-pendientes.md` (DP),
`06-calidad-de-datos.md` (P, IMP) y `07-esquema-fisico.md` (F).
