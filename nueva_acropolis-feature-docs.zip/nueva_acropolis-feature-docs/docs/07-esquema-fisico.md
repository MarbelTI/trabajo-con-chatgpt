# E. Esquema físico — PostgreSQL / Supabase

**Nueva Acrópolis** · 2026-08-19 · Fase 1 (relaciones públicas)
Traduce `03-especificacion-de-dominio.md` (conceptual) y `04-diccionario-de-datos.md` (lógico) a un
esquema concreto de PostgreSQL sobre Supabase. Decisiones de motor en `05` DP-19 y DP-37.

**Regla de trazabilidad.** Cada tabla, constraint e índice referencia la regla que lo justifica
(`RN-xx`, `ID-xx`, `DP-xx`, `F-xx`, `P-xx`, `IMP-xx`). Si algo aquí contradice `03` o `04`, gana `03`/`04`
y hay que corregir este documento.

```
docs/03  conceptual   entidades, relaciones, cardinalidades, reglas de negocio
docs/04  lógico       campos, tipos abstractos, obligatoriedad, 22 enums
docs/07  FÍSICO       este documento: tablas, tipos pg, constraints, RLS, triggers, vistas
```

---

## 0. Resumen

| Métrica | Valor |
|---|---|
| Tablas | **33** — 26 de dominio, 6 catálogos de enums abiertos, 1 de auditoría de identidad |
| Tipos enum nativos | 17 (los enums *cerrados* de `04` §22) |
| Catálogos como tabla | 6 (los enums *abiertos*: el usuario crea valores, RN-21) |
| Vistas derivadas | 8 |
| Funciones | 11 (normalización, RLS, periodo en zona de sede, auditoría) |
| Volumen inicial real | 41 personas · 10 actividades · ~44 participaciones (`06` §1) |
| Volumen esperado a 5 años | orden de miles de personas, decenas de miles de participaciones |

**Convención de nombres.** `snake_case`, tablas en plural, en español —el vocabulario de la sede es
requisito, no preferencia (`03` §2, D7 del glosario). Índices `idx_`, únicos `uk_`, checks `ck_`, claves
ajenas `fk_`, exclusiones `ex_`.

Mapeo entidad → tabla: `PERSONA` → `personas`, `PARTICIPACION` → `participaciones`,
`ESTADO_PERSONA_HIST` → `estados_persona`, `PERSONA_SEDE` → `personas_sedes`,
`PERSONA_CONTACTO` → `personas_contactos`, `MARCA_REVISION` → `marcas_revision`.

---

## 1. Decisiones físicas

### F1 · Enum cerrado → tipo nativo · enum abierto → tabla de catálogo

Sale directo de `04` §22, que ya marca cada vocabulario. No es una elección estética: RN-21 dice
*"tú puedes crear medios también"*, y un tipo nativo no lo permite sin migración.

| Enum de `04` | Estrategia | Motivo |
|---|---|---|
| E-01 `ESTADO_PERSONA`, E-02 `LINEA_ACTIVIDAD`, E-04 `ROL`, E-06 `CIRCULO_ACTIVIDAD`, E-06b `CATEGORIA_OINA`, E-09 `MOTIVO_FIN_VINCULO`, E-10 `ESTADO_INSCRIPCION`, E-14 `CANAL_INTERACCION`, E-15 `RESULTADO_CONTACTO`, E-16 `INTERES_CURSO`, E-17 `NIVEL_PERMISO`, E-19 `TIPO_CEDULA`, E-20 `ESTADO_ACTIVIDAD`, E-22 `TIPO_CONTACTO_PERSONA` | **tipo enum nativo** | Cerrados. Cambiarlos es cambiar el dominio, y debe doler |
| E-03 `TIPO_ACTIVIDAD`, E-05 `AREA`, E-07 `OCUPACION`, E-11 `MEDIO_DIFUSION`, E-12 `TIPO_ORGANIZACION_ALIADA`, E-13 `TIPO_ENLACE`, E-21 `TIPO_MARCA_REVISION` | **tabla de catálogo** | Abiertos: el usuario crea valores (RN-15, RN-21, DP-17) |
| E-08 `SEDE` | ya es tabla `sedes` | |
| E-18 `CONTADOR_SEGUIMIENTO` | **no se modela** | `04` §22: se reemplaza por el conteo real de `interacciones` |

### F2 · Claves primarias: `uuid` con generador centralizado en una función

DP-19 pide UUIDv7. `uuidv7()` es nativo desde PostgreSQL 18 y puede no estar disponible en la versión de
Supabase del proyecto. Para no dispersar la decisión por 33 tablas, todas usan `DEFAULT app.id_nuevo()`,
y la función decide. Si `uuidv7()` no existe, cae a `gen_random_uuid()` (v4): se pierde la localidad de
índice, que a este volumen es irrelevante.

### F3 · Los invariantes del modelo son constraints, no validaciones de aplicación

Es la razón principal para elegir un relacional. Nueve invariantes de `03`/`04` quedan garantizados por el
motor:

| Invariante | Regla | Mecanismo |
|---|---|---|
| Un solo vínculo de sede vigente por persona | RN-07, DP-03 | índice único parcial `WHERE hasta IS NULL` |
| Un solo estado vigente por persona | RN-01 | índice único parcial `WHERE hasta IS NULL` |
| Historial de estados sin solapamiento de fechas | RN-01 | `EXCLUDE USING gist` sobre `daterange` |
| Historial de sedes sin solapamiento | DP-03 | idem |
| Cédula única cuando existe | ID-1 | índice único parcial `WHERE cedula IS NOT NULL` |
| Una participación por persona × actividad | `04` §11, P04 | clave única compuesta |
| Un contacto principal por tipo | DP-33 | índice único parcial `WHERE es_principal` |
| Una primera captación por persona | `04` §12 | índice único parcial `WHERE es_primera_captacion` |
| Una sola sede central | `04` §2 | índice único parcial `WHERE es_central` |

### F4 · Lo que **no** tiene unicidad, deliberadamente

Teléfono y correo **no** son únicos. Hay evidencia real: dos teléfonos compartidos entre personas distintas
(P08: madre/hija, hermanas) y un correo compartido (P06). El sistema avisa y no impide (ID-4, ID-5, RN-51).
Un `UNIQUE` aquí haría imposible cargar los datos que ya existen.

### F5 · Una denormalización obligada por la RLS: `personas.sede_vigente_id`

`docs/03` D2 dice que `sede_vigente` es vista. **La RLS obliga a romperlo.** Filtrar la lectura de
`personas` por sede exige evaluar la sede en la fila que se está filtrando; con una vista, cada fila
dispararía una subconsulta a `personas_sedes`, y el listado de personas se arrastra.

Solución: columna `sede_vigente_id` mantenida por trigger desde `personas_sedes`, con índice. Es la única
denormalización del esquema y se declara como excepción consciente a D2. Mismo motivo para
`participaciones.sede_id`, copiada de la actividad.

### F6 · Nunca se borra: no hay `DELETE`, y el motor lo impone

RN-41 dice que no se borra a nadie. No se implementa con un `deleted_at` que alguien pueda ignorar: se
**revoca el privilegio `DELETE`** a los roles de aplicación en todas las tablas de dominio, y no se crea
ninguna política RLS de `DELETE`. `personas.archivada` es el mecanismo de retiro. Las tablas append-only
(`estados_persona`, `notas_ficha`, `historial_identidad_persona`) además no tienen política de `UPDATE`
(RN-40).

Consecuencia: `ON DELETE CASCADE` no aparece en ninguna clave ajena. Se usa `ON DELETE RESTRICT`.

### F7 · Detección de duplicados con `pg_trgm`, no con comparación exacta

ID-6 pide *"teléfono normalizado igual **+ similitud alta de nombre**"*. Eso es similitud difusa, no
igualdad: el Excel tiene `NUEVA ACROPOILIS` con typo y nombres escritos de formas distintas. Se resuelve
con `pg_trgm` sobre una columna generada sin acentos ni mayúsculas, con índice GIN.

### F8 · Corte de periodo en la zona de la sede

RN-55 y el caso concreto: una charla el día 31 a las 20:00 en Venezuela es el día 1 en UTC, y el informe
descuadraría por uno. Todo almacenamiento es `timestamptz`; todo corte pasa por
`app.periodo_local(ts, sede_id)`, que aplica `sedes.zona_horaria`.

### F9 · `usuarios` es tabla propia, no `auth.users`

Supabase gobierna `auth.users`. `usuarios` vive en `public` con clave ajena a `auth.users`, y aporta lo que
el dominio exige: `persona_id` obligatorio (RN-50), `acceso_global`, `activo`. Nunca se escribe en el
esquema `auth`.

**El registro público debe quedar desactivado.** DP-23 dice que no hay autorregistro y RN-50 prohíbe
cuentas anónimas; Supabase trae el alta pública activada por omisión. El alta es siempre: crear la persona
→ invitar por correo → se crea `auth.users` → se crea `usuarios` enlazando ambos.

### F10 · La RLS es la única frontera de seguridad, y eso es un riesgo declarado

PostgREST expone cada tabla por HTTP. `01-contexto` §9 exige no exponer listados de personas ni su nivel de
vínculo, sobre datos que incluyen creencias, participación y **dos menores de edad reales**. Por tanto:

- `ENABLE ROW LEVEL SECURITY` en **todas** las tablas, sin excepción. Una tabla sin RLS queda abierta.
- `REVOKE ALL ON SCHEMA public FROM anon` — el rol anónimo no lee nada.
- `service_role` solo en servidor, nunca en el cliente.
- Cada política es un caso de prueba: *"un usuario de Táriba no ve personas de San Cristóbal"* se verifica,
  no se revisa a ojo.

---

## 2. Diagrama entidad-relación

```
                            ┌──────────────────────┐
                            │       sedes          │
                            ├──────────────────────┤
                            │ id (PK)              │
                            │ codigo (UK)          │
                            │ zona_horaria    F8   │
                            │ es_central (UK parc.)│
                            └───┬───┬───┬───┬──────┘
              ┌─────────────────┘   │   │   └──────────────────┐
              │ 1:N                 │   │ 1:N            1:N   │
              ▼                     │   ▼                      ▼
   ┌──────────────────┐             │  ┌──────────────┐   ┌──────────────┐
   │  personas_sedes  │             │  │    areas     │   │   grupos     │
   ├──────────────────┤             │  ├──────────────┤   ├──────────────┤
   │ persona_id  (FK) │             │  │ id (PK)      │   │ curso_id (FK)│
   │ sede_id     (FK) │             │  │ codigo       │   │ sede_id  (FK)│
   │ desde/hasta      │             │  │ sede_id (FK) │   │ profesor (FK)│
   │ motivo_fin       │             │  └───┬──────┬───┘   │ dia · hora   │
   │ UK parc. hasta IS│             │      │      │       └───┬──────┬───┘
   │ NULL · EXCLUDE   │             │      │      │           │      │
   └────────┬─────────┘             │      │      │           │      │ 1:N
            │                       │      │      │           │      ▼
            │ N:1                   │      │      │      1:N  │  ┌─────────────┐
            ▼                       │      │      │           │  │inscripciones│
   ╔══════════════════════════╗     │      │      │           │  ├─────────────┤
   ║        personas          ║     │      │      │           │  │ persona (FK)│
   ╠══════════════════════════╣     │      │      │           │  │ grupo   (FK)│
   ║ id (PK)                  ║     │      │      │           │  │ estado      │
   ║ cedula_tipo · cedula     ║     │      │      │           │  │ UK compuesta│
   ║   UK parc. NOT NULL ID-1 ║     │      │      │           │  └─────────────┘
   ║ nombre           oblig.  ║     │      │      │           │
   ║ apellido         opcion. ║     │      │      │           ▼
   ║ nombre_busqueda  GEN F7  ║     │      │      │    ┌──────────────────────┐
   ║ fecha_nacimiento         ║     │      │      │    │     actividades      │
   ║ es_menor_de_edad  trigger║     │      │      │    ├──────────────────────┤
   ║ representante_*          ║     │      │      │    │ id (PK)              │
   ║ ocupacion_id      (FK)   ║     │      │      │    │ sede_id (FK)         │
   ║ contacto_bloqueado(_en)  ║     │      │      │    │ grupo_id (FK) opc.   │
   ║ archivada                ║     │      │      │    │ tipo_actividad_id FK │
   ║ sede_vigente_id  DENORM  ║     │      │      │    │ linea · circulo      │
   ║   F5, trigger            ║     │      │      │    │ titulo · tema RN-16  │
   ║ fusionada_en (FK self)   ║     │      │      │    │ inicio · fin  tstz   │
   ║ registrado_por/_en       ║     │      │      │    │ estado    E-20 DP-26 │
   ║ modificado_por/_en RN-47 ║     │      │      │    │ cupo      RN-43      │
   ╚═╤═╤═╤═╤═╤═╤═╤═╤═╤═╤═╤═╤══╝     │      │      │    │ organizacion_al. FK  │
     │ │ │ │ │ │ │ │ │ │ │ │        │      │      │    └────┬──────────┬──────┘
     │ │ │ │ │ │ │ │ │ │ │ │ 1:N    │      │      │         │ 1:N      │ N:M
     │ │ │ │ │ │ │ │ │ │ │ └────────┼──────┼──────┼─────────┼──────────┼──────┐
     │ │ │ │ │ │ │ │ │ │ │          │      │      │         ▼          ▼      │
     │ │ │ │ │ │ │ │ │ │ │   ┌──────┴──┐   │      │  ┌─────────────┐ ┌────────┴──────┐
     │ │ │ │ │ │ │ │ │ │ │   │  roles_ │   │      │  │participacio-│ │ actividades_  │
     │ │ │ │ │ │ │ │ │ │ │   │ asignados│  │      │  │    nes      │ │  etiquetas    │
     │ │ │ │ │ │ │ │ │ │ │   ├─────────┤   │      │  ├─────────────┤ ├───────────────┤
     │ │ │ │ │ │ │ │ │ │ │   │persona  │   │      │  │ persona (FK)│ │ actividad (FK)│
     │ │ │ │ │ │ │ │ │ │ │   │rol E-04 │   │      │  │ actividad FK│ │ etiqueta (FK) │
     │ │ │ │ │ │ │ │ │ │ │   │area (FK)│   │      │  │ UK compuesta│ │ PK compuesta  │
     │ │ │ │ │ │ │ │ │ │ │   │grupo(FK)│   │      │  │ asistio     │ └───────┬───────┘
     │ │ │ │ │ │ │ │ │ │ │   │desde/   │   │      │  │ es_interno_ │         │ N:1
     │ │ │ │ │ │ │ │ │ │ │   │ hasta   │   │      │  │  en_la_fecha│         ▼
     │ │ │ │ │ │ │ │ │ │ │   │  DP-12  │   │      │  │  CONGELADO  │  ┌────────────┐
     │ │ │ │ │ │ │ │ │ │ │   └─────────┘   │      │  │  RN-17      │  │ etiquetas  │
     │ │ │ │ │ │ │ │ │ │ │                 │      │  │ sede_id F5  │  │ RN-15 libre│
     │ │ │ │ │ │ │ │ │ │ │                 │      │  └─────────────┘  └────────────┘
     │ │ │ │ │ │ │ │ │ │ └── personas_contactos ──── tipo E-22 · valor · valor_normalizado
     │ │ │ │ │ │ │ │ │ │        DP-33            UK parc. es_principal · GIN trgm · SIN unique F4
     │ │ │ │ │ │ │ │ │ │
     │ │ │ │ │ │ │ │ │ └──── estados_persona ───── estado E-01 · desde/hasta · disparador
     │ │ │ │ │ │ │ │ │           RN-01            UK parc. vigente · EXCLUDE solapamiento
     │ │ │ │ │ │ │ │ │                            append-only: sin UPDATE ni DELETE
     │ │ │ │ │ │ │ │ │
     │ │ │ │ │ │ │ │ └────── atribuciones_captacion ── medio_id FK · invitado_por_persona_id (self)
     │ │ │ │ │ │ │ │            RN-20 bucle A         · organizacion_aliada_id · actividad_id
     │ │ │ │ │ │ │ │                                  UK parc. es_primera_captacion
     │ │ │ │ │ │ │ │                                  CK exclusividad medio ↔ referencia
     │ │ │ │ │ │ │ │
     │ │ │ │ │ │ │ └──────── interacciones ─────── canal E-14 · resultado E-15 · usuario_id
     │ │ │ │ │ │ │              RN-24
     │ │ │ │ │ │ └────────── notas_ficha ────────── append-only RN-40 · sin notas privadas
     │ │ │ │ │ └──────────── intereses_declarados ── linea · tipo_actividad_id · interes_curso
     │ │ │ │ │                                       vigente = último POR LÍNEA  RN-52
     │ │ │ │ └────────────── consentimientos_contacto ── informativo, no filtra  RN-12
     │ │ │ └──────────────── contactos_enlace ────── area_custodia_id · es_restringido  RN-28
     │ │ └──────────────────  marcas_revision ────── tipo_id FK · origen · resuelta_en  DP-36
     │ │                                             bandeja de pendientes
     │ └──────────────────── historial_identidad_persona ── campo · valor_ant · valor_nuevo  RN-47
     │
     │ 1:0..1
     ▼
┌──────────────────────┐        ┌──────────────────┐        ┌──────────────────┐
│      usuarios        │        │  permisos_sede   │        │  permisos_area   │
├──────────────────────┤ 1:N    ├──────────────────┤        ├──────────────────┤
│ id (PK)              ├───────▶│ usuario_id  (FK) │        │ usuario_id  (FK) │
│ auth_user_id (FK,UK) │───┐    │ sede_id     (FK) │        │ area_id     (FK) │
│   → auth.users   F9  │   │    │ nivel      E-17  │        │ nivel      E-17  │
│ persona_id (FK,UK)   │   └───▶│ desde/hasta RN-54│        │ desde/hasta      │
│ correo (UK)          │  1:N   └──────────────────┘        └──────────────────┘
│ acceso_global RN-29  │
│ activo               │        ┌──────────────────────────────────────────┐
└──────────────────────┘        │ periodos_reporte · totales congelados    │
                                │ sede_id · anio · mes · estado · DP-10    │
CATÁLOGOS (enums abiertos F1)   └──────────────────────────────────────────┘
tipos_actividad · medios_difusion · ocupaciones · tipos_organizacion_aliada
tipos_enlace · tipos_marca_revision            (todos: codigo UK · etiqueta · creado_por)
```

---

## 3. Extensiones, esquema y tipos

```sql
-- ============================================================
-- 3.1 Extensiones
-- ============================================================
CREATE EXTENSION IF NOT EXISTS pgcrypto;    -- gen_random_uuid()
CREATE EXTENSION IF NOT EXISTS btree_gist;  -- EXCLUDE con uuid + daterange (F3)
CREATE EXTENSION IF NOT EXISTS pg_trgm;     -- similitud de nombres, ID-6 (F7)
CREATE EXTENSION IF NOT EXISTS unaccent;    -- normalizacion de nombres, F-5

-- Esquema para funciones internas: no se expone por PostgREST
CREATE SCHEMA IF NOT EXISTS app;
REVOKE ALL ON SCHEMA app FROM PUBLIC, anon, authenticated;

-- ============================================================
-- 3.2 Generador de identificadores (F2, DP-19)
-- ============================================================
-- Toda tabla usa app.id_nuevo(). Si uuidv7() no existe en la version de
-- Postgres del proyecto, se cae a v4 y solo se pierde localidad de indice,
-- irrelevante a este volumen.
CREATE OR REPLACE FUNCTION app.id_nuevo() RETURNS uuid
LANGUAGE plpgsql VOLATILE AS $$
DECLARE v uuid;
BEGIN
  BEGIN
    EXECUTE 'SELECT uuidv7()' INTO v;
  EXCEPTION WHEN undefined_function THEN
    v := gen_random_uuid();
  END;
  RETURN v;
END $$;

-- ============================================================
-- 3.3 Tipos enum nativos — enums CERRADOS de docs/04 §22 (F1)
-- ============================================================
CREATE TYPE estado_persona AS ENUM            -- E-01
  ('CONTACTO','ASISTENTE','PROBACIONISTA','MIEMBRO','INACTIVO');

CREATE TYPE linea_actividad AS ENUM           -- E-02
  ('FILOSOFIA','CULTURA','VOLUNTARIADO');

CREATE TYPE rol_persona AS ENUM               -- E-04 (cerrado, ampliable por el sistema)
  ('COLABORADOR','ENCARGADO_AREA','INSTRUCTOR','JEFE_INSTRUCTOR','CELADOR',
   'FUERZA_VIVA','SECRETARIA','DIRIGENTE','DIRECTOR_NACIONAL');

CREATE TYPE circulo_actividad AS ENUM         -- E-06 · eje de proximidad, DP-01
  ('PRIMER_CIRCULO','SEGUNDO_CIRCULO','TERCER_CIRCULO');

CREATE TYPE categoria_oina AS ENUM            -- E-06b · eje del informe, DP-01. Derivado
  ('MIEMBROS','PROBACIONISMO','FUERZA_VIVA');

CREATE TYPE motivo_fin_vinculo AS ENUM        -- E-09
  ('TRASLADO_FILIAL','BAJA','OTRO');

CREATE TYPE estado_inscripcion AS ENUM        -- E-10
  ('INSCRITO','NO_INSCRITO','RETIRADO');

CREATE TYPE canal_interaccion AS ENUM         -- E-14
  ('LLAMADA','WHATSAPP','MENSAJE_REDES','CORREO','VISITA');

CREATE TYPE resultado_contacto AS ENUM        -- E-15 · SIN_CONTACTAR = celda vacia, nunca NO (P23)
  ('INTERESADO','NO_INTERESADO','NO_RESPONDIO','SIN_CONTACTAR');

CREATE TYPE interes_curso AS ENUM             -- E-16
  ('SI','NO','SIN_DATO');

CREATE TYPE nivel_permiso AS ENUM             -- E-17 · no existe nivel de borrado (RN-41)
  ('LECTURA','ESCRITURA');

CREATE TYPE tipo_cedula AS ENUM               -- E-19
  ('V','E');

CREATE TYPE estado_actividad AS ENUM          -- E-20 · DP-26
  ('PLANIFICADA','REALIZADA','CANCELADA');

CREATE TYPE tipo_contacto_persona AS ENUM     -- E-22 · DP-33
  ('TELEFONO','TELEFONO_INTL','CORREO','INSTAGRAM','FACEBOOK','OTRA_RED');

CREATE TYPE dia_semana AS ENUM
  ('LUNES','MARTES','MIERCOLES','JUEVES','VIERNES','SABADO','DOMINGO');

CREATE TYPE estado_periodo_reporte AS ENUM    -- DP-10
  ('ABIERTO','CERRADO','ENVIADO','DEVUELTO');

CREATE TYPE origen_marca AS ENUM              -- DP-36
  ('FORMULARIO','IMPORTACION');

-- ============================================================
-- 3.4 Funciones de normalizacion (F-1 a F-3, F-5, F-8)
-- ============================================================

-- Nombre comparable: sin acentos, minusculas, espacios colapsados. F-5, ID-6
CREATE OR REPLACE FUNCTION app.normaliza_nombre(t text) RETURNS text
LANGUAGE sql IMMUTABLE PARALLEL SAFE AS $$
  SELECT regexp_replace(lower(unaccent(coalesce(t,''))), '\s+', ' ', 'g');
$$;

-- Telefono venezolano a 11 digitos con el 0 inicial; internacional a E.164. F-3, P01, P02
CREATE OR REPLACE FUNCTION app.normaliza_telefono(t text) RETURNS text
LANGUAGE plpgsql IMMUTABLE PARALLEL SAFE AS $$
DECLARE d text;
BEGIN
  IF t IS NULL THEN RETURN NULL; END IF;
  d := regexp_replace(t, '[^0-9+]', '', 'g');
  IF d LIKE '+%' THEN RETURN d; END IF;              -- ya internacional
  IF d LIKE '58%' AND length(d) = 12 THEN            -- 58 + 10 digitos
    RETURN '0' || substring(d from 3);
  END IF;
  IF length(d) = 10 AND substring(d,1,1) <> '0' THEN -- perdio el 0 inicial (P01)
    RETURN '0' || d;
  END IF;
  IF length(d) = 11 AND substring(d,1,1) = '0' THEN
    RETURN d;
  END IF;
  IF length(d) BETWEEN 11 AND 15 THEN                -- prefijo de otro pais (P02: +57)
    RETURN '+' || d;
  END IF;
  RETURN d;                                          -- invalido: se conserva tal cual (IMP-04)
END $$;

CREATE OR REPLACE FUNCTION app.normaliza_correo(t text) RETURNS text
LANGUAGE sql IMMUTABLE PARALLEL SAFE AS $$
  SELECT nullif(lower(btrim(coalesce(t,''))), '');
$$;

-- Periodo (anio, mes) de un instante EN LA ZONA DE LA SEDE. RN-55, F8
-- Sin esto, una charla el dia 31 a las 20:00 local cae en el mes siguiente en UTC
-- y el informe descuadra por uno (RN-31).
CREATE OR REPLACE FUNCTION app.periodo_local(ts timestamptz, p_sede_id uuid)
RETURNS date LANGUAGE sql STABLE AS $$
  SELECT date_trunc('month', ts AT TIME ZONE s.zona_horaria)::date
  FROM sedes s WHERE s.id = p_sede_id;
$$;

---

## 4. Definición de tablas

Nota de convención: `registrado_por` / `registrado_en` y `modificado_por` / `modificado_en` **son** los
`created_*` / `updated_*` habituales. Se nombran con el vocabulario del dominio porque son requisito
explícito (RN-06, RN-47), no metadatos accesorios.

### 4.1 Catálogos y organización

```sql
-- ============================================================
-- sedes — E-08 abierto. "la idea es que usted abra una filial" (30-jul)
-- ============================================================
CREATE TABLE sedes (
  id             uuid PRIMARY KEY DEFAULT app.id_nuevo(),
  codigo         text NOT NULL,
  nombre         text NOT NULL,
  pais           text NOT NULL DEFAULT 'Venezuela',
  zona_horaria   text NOT NULL DEFAULT 'America/Caracas',   -- RN-55, F8
  es_central     boolean NOT NULL DEFAULT false,            -- "todos le reportan a la central"
  activa         boolean NOT NULL DEFAULT true,
  registrado_en  timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT uk_sedes_codigo UNIQUE (codigo),
  CONSTRAINT ck_sedes_zona   CHECK (zona_horaria ~ '^[A-Za-z]+/[A-Za-z_]+$')
);
-- Una sola sede central (F3)
CREATE UNIQUE INDEX uk_sedes_central ON sedes ((true)) WHERE es_central;

-- ============================================================
-- areas — E-05 abierto. El area existe POR SEDE (docs/04 §6)
-- ============================================================
CREATE TABLE areas (
  id             uuid PRIMARY KEY DEFAULT app.id_nuevo(),
  sede_id        uuid NOT NULL REFERENCES sedes(id) ON DELETE RESTRICT,
  codigo         text NOT NULL,
  nombre         text NOT NULL,
  activa         boolean NOT NULL DEFAULT true,
  registrado_en  timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT uk_areas_sede_codigo UNIQUE (sede_id, codigo)
);

-- ============================================================
-- Catalogos de enums ABIERTOS (F1). Misma forma para los seis.
-- El usuario crea valores: RN-15, RN-21, DP-17
-- ============================================================
CREATE TABLE ocupaciones (                    -- E-07, catalogo semilla: 19 valores reales del xlsx
  id             uuid PRIMARY KEY DEFAULT app.id_nuevo(),
  codigo         text NOT NULL,
  etiqueta       text NOT NULL,
  es_semilla     boolean NOT NULL DEFAULT false,
  creado_por     uuid,                          -- FK a usuarios, diferida (§5)
  registrado_en  timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT uk_ocupaciones_codigo UNIQUE (codigo)
);

CREATE TABLE tipos_actividad (                -- E-03
  id uuid PRIMARY KEY DEFAULT app.id_nuevo(),
  codigo text NOT NULL, etiqueta text NOT NULL,
  es_semilla boolean NOT NULL DEFAULT false, creado_por uuid,
  registrado_en timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT uk_tipos_actividad_codigo UNIQUE (codigo)
);

CREATE TABLE medios_difusion (                -- E-11. "tu puedes crear medios tambien" (30-jul)
  id uuid PRIMARY KEY DEFAULT app.id_nuevo(),
  codigo text NOT NULL, etiqueta text NOT NULL,
  -- marca que el medio exige una referencia concreta (RN-20)
  exige_persona      boolean NOT NULL DEFAULT false,   -- INVITADO_POR_PERSONA
  exige_organizacion boolean NOT NULL DEFAULT false,   -- ALIANZA
  es_semilla boolean NOT NULL DEFAULT false, creado_por uuid,
  registrado_en timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT uk_medios_codigo UNIQUE (codigo),
  CONSTRAINT ck_medios_exclusivo CHECK (NOT (exige_persona AND exige_organizacion))
);

CREATE TABLE tipos_organizacion_aliada (      -- E-12
  id uuid PRIMARY KEY DEFAULT app.id_nuevo(),
  codigo text NOT NULL, etiqueta text NOT NULL,
  es_semilla boolean NOT NULL DEFAULT false, creado_por uuid,
  registrado_en timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT uk_tipos_org_codigo UNIQUE (codigo)
);

CREATE TABLE tipos_enlace (                   -- E-13
  id uuid PRIMARY KEY DEFAULT app.id_nuevo(),
  codigo text NOT NULL, etiqueta text NOT NULL,
  es_semilla boolean NOT NULL DEFAULT false, creado_por uuid,
  registrado_en timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT uk_tipos_enlace_codigo UNIQUE (codigo)
);

CREATE TABLE tipos_marca_revision (           -- E-21, DP-36
  id uuid PRIMARY KEY DEFAULT app.id_nuevo(),
  codigo text NOT NULL, etiqueta text NOT NULL,
  -- a que se le puede aplicar: evita marcas de persona colgadas de una actividad
  aplica_persona boolean NOT NULL DEFAULT true,
  aplica_actividad boolean NOT NULL DEFAULT false,
  aplica_participacion boolean NOT NULL DEFAULT false,
  es_semilla boolean NOT NULL DEFAULT false, creado_por uuid,
  registrado_en timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT uk_tipos_marca_codigo UNIQUE (codigo)
);

-- ============================================================
-- organizaciones_aliadas — DP-04. 14 de 44 filas del xlsx (12 personas)
-- llegaron por Rotary, Spinning Bike o Biblioteca Tariba
-- ============================================================
CREATE TABLE organizaciones_aliadas (
  id             uuid PRIMARY KEY DEFAULT app.id_nuevo(),
  nombre         text NOT NULL,
  nombre_busqueda text GENERATED ALWAYS AS (app.normaliza_nombre(nombre)) STORED,
  tipo_id        uuid REFERENCES tipos_organizacion_aliada(id) ON DELETE RESTRICT,
  area_custodia_id uuid REFERENCES areas(id) ON DELETE RESTRICT,
  activa         boolean NOT NULL DEFAULT true,
  registrado_por uuid, registrado_en timestamptz NOT NULL DEFAULT now(),
  modificado_por uuid, modificado_en timestamptz,
  CONSTRAINT uk_org_aliadas_nombre UNIQUE (nombre)
);

-- ============================================================
-- etiquetas — RN-15. Las crea el usuario. N:M con actividades
-- ============================================================
CREATE TABLE etiquetas (
  id             uuid PRIMARY KEY DEFAULT app.id_nuevo(),
  nombre         text NOT NULL,
  nombre_normalizado text GENERATED ALWAYS AS (app.normaliza_nombre(nombre)) STORED,
  creado_por     uuid,
  registrado_en  timestamptz NOT NULL DEFAULT now()
);
-- Unicidad sobre el valor normalizado: el xlsx tiene 154 valores con espacios sobrantes (P17)
CREATE UNIQUE INDEX uk_etiquetas_normalizado ON etiquetas (nombre_normalizado);
```

### 4.2 Persona y su identidad

```sql
-- ============================================================
-- personas — la entidad central. "las personas son la base de todo,
-- de ahi parte todo" (30-jul)
-- ============================================================
CREATE TABLE personas (
  id                uuid PRIMARY KEY DEFAULT app.id_nuevo(),

  -- Identidad. ID-1: la cedula es el identificador natural CUANDO EXISTE.
  -- RN-02 modificada por DP-24: nunca obligatoria a nivel de esquema; su
  -- ausencia genera marca de revision, no un error (RN-46).
  cedula_tipo       tipo_cedula,
  cedula            text,
  nombre            text NOT NULL,                    -- RN-53: obligatorio
  apellido          text,                             -- DP-31: opcional (P16)
  nombre_completo   text GENERATED ALWAYS AS
                      (btrim(nombre || ' ' || coalesce(apellido,''))) STORED,
  nombre_busqueda   text GENERATED ALWAYS AS
                      (app.normaliza_nombre(nombre || ' ' || coalesce(apellido,''))) STORED,

  -- Datos personales. Todos opcionales (RN-53)
  fecha_nacimiento  date,
  es_menor_de_edad  boolean NOT NULL DEFAULT false,    -- trigger: A LA FECHA DE REGISTRO (RN-37)
  representante_nombre     text,
  representante_telefono   text,
  representante_parentesco text,
  ocupacion_id      uuid REFERENCES ocupaciones(id) ON DELETE RESTRICT,
  ocupacion_otro    text,                              -- DP-17: catalogo + "otro"
  direccion         text,

  -- Estado del vinculo. Denormalizaciones mantenidas por trigger (F5)
  sede_vigente_id   uuid REFERENCES sedes(id) ON DELETE RESTRICT,
  estado_vigente    estado_persona NOT NULL DEFAULT 'CONTACTO',
  ultimo_estado_alcanzado estado_persona,              -- RN-11
  punto_de_salida   text,                              -- "llego hasta el tema tal" (30-jul)

  -- Marcas informativas. RN-41: no existe borrado
  contacto_bloqueado    boolean NOT NULL DEFAULT false,   -- RN-42
  contacto_bloqueado_en date,
  sigue_en_invitaciones boolean NOT NULL DEFAULT true,    -- DP-07: la diferencia con "amigo de la escuela"
  archivada             boolean NOT NULL DEFAULT false,   -- RN-41
  fusionada_en          uuid REFERENCES personas(id) ON DELETE RESTRICT,  -- ID-7

  -- Auditoria (RN-06, RN-47)
  registrado_por    uuid NOT NULL,
  registrado_en     timestamptz NOT NULL DEFAULT now(),
  modificado_por    uuid,
  modificado_en     timestamptz,

  CONSTRAINT ck_personas_cedula_formato
    CHECK (cedula IS NULL OR cedula ~ '^[0-9]{7,8}$'),          -- observado 1524974..32785762
  CONSTRAINT ck_personas_cedula_tipo
    CHECK ((cedula IS NULL) = (cedula_tipo IS NULL)),
  CONSTRAINT ck_personas_nombre
    CHECK (char_length(btrim(nombre)) >= 2),
  CONSTRAINT ck_personas_nacimiento
    CHECK (fecha_nacimiento IS NULL
           OR fecha_nacimiento BETWEEN DATE '1900-01-01' AND CURRENT_DATE),
  CONSTRAINT ck_personas_bloqueo_fecha
    CHECK (NOT contacto_bloqueado OR contacto_bloqueado_en IS NOT NULL),
  CONSTRAINT ck_personas_no_autofusion
    CHECK (fusionada_en IS NULL OR fusionada_en <> id),
  CONSTRAINT ck_personas_modificado
    CHECK (modificado_en IS NULL OR modificado_en >= registrado_en)
);

-- ID-1: cedula unica en TODO el sistema, no por sede. Parcial: hay personas sin cedula
CREATE UNIQUE INDEX uk_personas_cedula
  ON personas (cedula_tipo, cedula) WHERE cedula IS NOT NULL;

-- ============================================================
-- personas_contactos — DP-33. Sustituye 7 columnas de personas.
-- SIN unicidad global (F4): P08 dos telefonos compartidos, P06 un correo compartido
-- ============================================================
CREATE TABLE personas_contactos (
  id            uuid PRIMARY KEY DEFAULT app.id_nuevo(),
  persona_id    uuid NOT NULL REFERENCES personas(id) ON DELETE RESTRICT,
  tipo          tipo_contacto_persona NOT NULL,
  valor         text NOT NULL,                      -- tal como se capturo. NUNCA se transforma (IMP-04)
  valor_normalizado text NOT NULL,                  -- trigger, segun el tipo. Clave de busqueda (RN-39)
  es_principal  boolean NOT NULL DEFAULT false,
  es_valido     boolean GENERATED ALWAYS AS (
    CASE tipo
      WHEN 'TELEFONO'      THEN valor_normalizado ~ '^0[0-9]{10}$'
      WHEN 'TELEFONO_INTL' THEN valor_normalizado ~ '^\+[1-9][0-9]{7,14}$'
      WHEN 'CORREO'        THEN valor_normalizado ~ '^[^@[:space:]]+@[^@[:space:]]+\.[^@[:space:]]+$'
      ELSE true
    END
  ) STORED,
  registrado_por uuid, registrado_en timestamptz NOT NULL DEFAULT now(),
  modificado_por uuid, modificado_en timestamptz,
  CONSTRAINT ck_pcontactos_valor CHECK (char_length(btrim(valor)) > 0),
  CONSTRAINT uk_pcontactos_valor UNIQUE (persona_id, tipo, valor_normalizado)
);
-- Un solo contacto principal por tipo (F3)
CREATE UNIQUE INDEX uk_pcontactos_principal
  ON personas_contactos (persona_id, tipo) WHERE es_principal;

-- ============================================================
-- historial_identidad_persona — RN-47. Solo los campos donde una edicion
-- equivocada rompe en silencio la identidad (ID-1) y el deduplicado (ID-6).
-- Append-only.
-- ============================================================
CREATE TABLE historial_identidad_persona (
  id            uuid PRIMARY KEY DEFAULT app.id_nuevo(),
  persona_id    uuid NOT NULL REFERENCES personas(id) ON DELETE RESTRICT,
  campo         text NOT NULL,
  valor_anterior text,
  valor_nuevo   text,
  cambiado_por  uuid,
  cambiado_en   timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT ck_hist_ident_campo CHECK (campo IN
    ('cedula','cedula_tipo','nombre','apellido','telefono'))
);

-- ============================================================
-- personas_sedes — DP-03. UN SOLO vinculo vigente, con historial.
-- El traslado cierra uno y abre otro: alimenta "altas traslado de filiales" (RN-34)
-- ============================================================
CREATE TABLE personas_sedes (
  id            uuid PRIMARY KEY DEFAULT app.id_nuevo(),
  persona_id    uuid NOT NULL REFERENCES personas(id) ON DELETE RESTRICT,
  sede_id       uuid NOT NULL REFERENCES sedes(id) ON DELETE RESTRICT,
  desde         date NOT NULL DEFAULT CURRENT_DATE,
  hasta         date,
  motivo_fin    motivo_fin_vinculo,
  registrado_por uuid, registrado_en timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT ck_psedes_rango CHECK (hasta IS NULL OR hasta > desde),
  CONSTRAINT ck_psedes_motivo CHECK ((hasta IS NULL) = (motivo_fin IS NULL)),
  -- Sin solapamiento de periodos por persona (F3)
  CONSTRAINT ex_psedes_solapamiento EXCLUDE USING gist (
    persona_id WITH =, daterange(desde, hasta, '[)') WITH &&
  )
);
-- Un solo vinculo vigente (F3, DP-03)
CREATE UNIQUE INDEX uk_psedes_vigente
  ON personas_sedes (persona_id) WHERE hasta IS NULL;

-- ============================================================
-- estados_persona — RN-01. Append-only. Insumo directo de las altas y
-- bajas del informe, incluida la clasificacion por antiguedad (RN-33)
-- ============================================================
CREATE TABLE estados_persona (
  id            uuid PRIMARY KEY DEFAULT app.id_nuevo(),
  persona_id    uuid NOT NULL REFERENCES personas(id) ON DELETE RESTRICT,
  estado        estado_persona NOT NULL,
  desde         date NOT NULL DEFAULT CURRENT_DATE,
  hasta         date,
  disparador    text,                                 -- inscripcion, graduacion, retiro, reingreso
  es_automatico boolean NOT NULL DEFAULT false,       -- solo CONTACTO -> ASISTENTE lo es
  registrado_por uuid NOT NULL,
  registrado_en  timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT ck_estados_rango CHECK (hasta IS NULL OR hasta >= desde),
  CONSTRAINT ex_estados_solapamiento EXCLUDE USING gist (
    persona_id WITH =, daterange(desde, hasta, '[)') WITH &&
  )
);
CREATE UNIQUE INDEX uk_estados_vigente
  ON estados_persona (persona_id) WHERE hasta IS NULL;

-- ============================================================
-- roles_asignados — RN-08: acumulables y ortogonales al estado.
-- DP-12: con vigencia, porque el informe cuenta instructores ACTIVOS
-- ============================================================
CREATE TABLE roles_asignados (
  id            uuid PRIMARY KEY DEFAULT app.id_nuevo(),
  persona_id    uuid NOT NULL REFERENCES personas(id) ON DELETE RESTRICT,
  rol           rol_persona NOT NULL,
  area_id       uuid REFERENCES areas(id) ON DELETE RESTRICT,
  grupo_id      uuid,                                 -- FK diferida: celaduria de un curso (18-jul)
  desde         date NOT NULL DEFAULT CURRENT_DATE,
  hasta         date,
  registrado_por uuid, registrado_en timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT ck_roles_rango CHECK (hasta IS NULL OR hasta > desde),
  -- RN-09: el rol de colaborador y encargado exige area
  CONSTRAINT ck_roles_area CHECK (
    rol NOT IN ('COLABORADOR','ENCARGADO_AREA') OR area_id IS NOT NULL
  )
);
-- No dos veces el mismo rol vigente en la misma area
CREATE UNIQUE INDEX uk_roles_vigente
  ON roles_asignados (persona_id, rol, coalesce(area_id, '00000000-0000-0000-0000-000000000000'::uuid))
  WHERE hasta IS NULL;
```

### 4.3 Actividades, cursos y participación

```sql
-- ============================================================
-- cursos — el catalogo. RN-19: prerrequisitos entre cursos
-- ============================================================
CREATE TABLE cursos (
  id            uuid PRIMARY KEY DEFAULT app.id_nuevo(),
  nombre        text NOT NULL,
  nivel         smallint,
  curso_prerequisito_id uuid REFERENCES cursos(id) ON DELETE RESTRICT,
  es_probacionismo boolean NOT NULL DEFAULT false,   -- marca el curso que define "interno" (RN-10)
  activo        boolean NOT NULL DEFAULT true,
  registrado_por uuid, registrado_en timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT uk_cursos_nombre UNIQUE (nombre),
  CONSTRAINT ck_cursos_no_autoprerequisito
    CHECK (curso_prerequisito_id IS NULL OR curso_prerequisito_id <> id)
);

-- ============================================================
-- grupos — RN-18: la edicion se identifica por dia + hora + profesor.
-- "dia, hora de la clase para distinguir como los grupos, el profesor" (10-jul#2)
-- ============================================================
CREATE TABLE grupos (
  id            uuid PRIMARY KEY DEFAULT app.id_nuevo(),
  curso_id      uuid NOT NULL REFERENCES cursos(id) ON DELETE RESTRICT,
  sede_id       uuid NOT NULL REFERENCES sedes(id) ON DELETE RESTRICT,
  profesor_persona_id uuid NOT NULL REFERENCES personas(id) ON DELETE RESTRICT,
  dia           dia_semana NOT NULL,
  hora          time NOT NULL,
  fecha_inicio  date NOT NULL,
  fecha_fin     date,
  registrado_por uuid, registrado_en timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT ck_grupos_rango CHECK (fecha_fin IS NULL OR fecha_fin > fecha_inicio),
  CONSTRAINT uk_grupos_identidad UNIQUE (curso_id, sede_id, dia, hora, fecha_inicio)
);

-- ============================================================
-- actividades — RN-14, RN-48. Se crea ANTES de registrar participaciones (DP-26).
-- RN-16: el titulo de convocatoria es distinto del tema canonico
-- ============================================================
CREATE TABLE actividades (
  id            uuid PRIMARY KEY DEFAULT app.id_nuevo(),
  sede_id       uuid NOT NULL REFERENCES sedes(id) ON DELETE RESTRICT,
  tipo_actividad_id uuid NOT NULL REFERENCES tipos_actividad(id) ON DELETE RESTRICT,
  linea         linea_actividad NOT NULL,
  circulo       circulo_actividad NOT NULL,           -- RN-15b, DP-01. Obligatorio
  titulo        text NOT NULL,                        -- "NADA CAMBIA SI TU NO CAMBIAS"
  tema          text,                                 -- "filosofia natural". No se inventa (P21, M-6)
  inicio        timestamptz NOT NULL,                 -- UTC. Corte en zona de sede (RN-55)
  fin           timestamptz,
  lugar         text,                                 -- "Biblioteca Tariba", "Spinning Bike" (P22)
  grupo_id      uuid REFERENCES grupos(id) ON DELETE RESTRICT,   -- RN-38: la clase suelta
  organizacion_aliada_id uuid REFERENCES organizaciones_aliadas(id) ON DELETE RESTRICT,
  estado        estado_actividad NOT NULL DEFAULT 'PLANIFICADA',  -- DP-26
  es_gratuita   boolean,
  cupo          integer,                              -- RN-43: avisa, NUNCA bloquea
  registrado_por uuid NOT NULL, registrado_en timestamptz NOT NULL DEFAULT now(),
  modificado_por uuid, modificado_en timestamptz,
  CONSTRAINT ck_actividades_rango CHECK (fin IS NULL OR fin > inicio),
  CONSTRAINT ck_actividades_cupo  CHECK (cupo IS NULL OR cupo > 0),
  CONSTRAINT ck_actividades_titulo CHECK (char_length(btrim(titulo)) > 0),
  -- El grupo, si existe, debe ser de la misma sede: se valida por trigger (§6)
  CONSTRAINT ck_actividades_tema_distinto CHECK (tema IS NULL OR tema <> titulo)
);

-- ============================================================
-- actividades_etiquetas — N:M. "dia de la tierra mas algo de arte" (18-jul)
-- ============================================================
CREATE TABLE actividades_etiquetas (
  actividad_id  uuid NOT NULL REFERENCES actividades(id) ON DELETE RESTRICT,
  etiqueta_id   uuid NOT NULL REFERENCES etiquetas(id)   ON DELETE RESTRICT,
  registrado_por uuid, registrado_en timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (actividad_id, etiqueta_id)
);

-- ============================================================
-- inscripciones — 10-jul#2. La inscripcion es SIEMPRE MANUAL (DP-05):
-- ningun numero de clases la dispara
-- ============================================================
CREATE TABLE inscripciones (
  id            uuid PRIMARY KEY DEFAULT app.id_nuevo(),
  persona_id    uuid NOT NULL REFERENCES personas(id) ON DELETE RESTRICT,
  grupo_id      uuid NOT NULL REFERENCES grupos(id) ON DELETE RESTRICT,
  estado        estado_inscripcion NOT NULL DEFAULT 'INSCRITO',
  fecha_inscripcion date NOT NULL DEFAULT CURRENT_DATE,
  fecha_retiro  date,
  dias_asistencia text,                              -- campos literales de la planilla formal
  horarios      text,
  encargado_persona_id uuid REFERENCES personas(id) ON DELETE RESTRICT,
  registrado_por uuid NOT NULL, registrado_en timestamptz NOT NULL DEFAULT now(),
  modificado_por uuid, modificado_en timestamptz,
  CONSTRAINT uk_inscripciones UNIQUE (persona_id, grupo_id),
  CONSTRAINT ck_inscripciones_retiro
    CHECK (fecha_retiro IS NULL OR fecha_retiro >= fecha_inscripcion),
  CONSTRAINT ck_inscripciones_estado_retiro
    CHECK (estado <> 'RETIRADO' OR fecha_retiro IS NOT NULL)
);
-- DP-24: la cedula SI es obligatoria en la inscripcion. Se impone por trigger (§6),
-- porque el CHECK no puede mirar otra tabla.

-- ============================================================
-- participaciones — el corazon del sistema. Par unico evita el duplicado
-- que hoy produce el Excel (P04, IMP-05)
-- ============================================================
CREATE TABLE participaciones (
  id            uuid PRIMARY KEY DEFAULT app.id_nuevo(),
  persona_id    uuid NOT NULL REFERENCES personas(id) ON DELETE RESTRICT,
  actividad_id  uuid NOT NULL REFERENCES actividades(id) ON DELETE RESTRICT,
  sede_id       uuid NOT NULL REFERENCES sedes(id) ON DELETE RESTRICT,  -- DENORM para RLS (F5)
  asistio       boolean NOT NULL DEFAULT true,
  -- RN-17: CONGELADO a la fecha de la actividad, no recalculado hoy (D2)
  es_interno_en_la_fecha boolean NOT NULL,
  categoria_oina_en_la_fecha categoria_oina,          -- idem, para el informe
  pago_entrada  boolean,                              -- punto de extension: economia
  comentario_experiencia text,                         -- 86% de llenado en el xlsx
  registrado_por uuid NOT NULL, registrado_en timestamptz NOT NULL DEFAULT now(),
  modificado_por uuid, modificado_en timestamptz,
  CONSTRAINT uk_participaciones UNIQUE (persona_id, actividad_id)
);

-- ============================================================
-- atribuciones_captacion — bucle A, el requisito de mayor intensidad
-- del analisis (R06, I=20.07). RN-20: se captura POR EVENTO
-- ============================================================
CREATE TABLE atribuciones_captacion (
  id            uuid PRIMARY KEY DEFAULT app.id_nuevo(),
  persona_id    uuid NOT NULL REFERENCES personas(id) ON DELETE RESTRICT,
  actividad_id  uuid REFERENCES actividades(id) ON DELETE RESTRICT,
  medio_id      uuid NOT NULL REFERENCES medios_difusion(id) ON DELETE RESTRICT,
  -- RN-20: selector de personas, NUNCA texto libre
  invitado_por_persona_id uuid REFERENCES personas(id) ON DELETE RESTRICT,
  organizacion_aliada_id  uuid REFERENCES organizaciones_aliadas(id) ON DELETE RESTRICT,
  es_primera_captacion boolean NOT NULL DEFAULT false,   -- la que cuenta para el informe
  invitado_por_interno boolean,                           -- RN-44: derivado A LA FECHA
  nota          text,                                     -- IMP-18: "MILAGRO Y ALEJANDRO"
  fecha         date NOT NULL DEFAULT CURRENT_DATE,
  registrado_por uuid NOT NULL, registrado_en timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT ck_atrib_no_autoinvitacion
    CHECK (invitado_por_persona_id IS NULL OR invitado_por_persona_id <> persona_id),
  -- Coherencia medio <-> referencia: se impone por trigger (§6), porque depende
  -- de medios_difusion.exige_persona / exige_organizacion
  CONSTRAINT ck_atrib_una_referencia
    CHECK (NOT (invitado_por_persona_id IS NOT NULL AND organizacion_aliada_id IS NOT NULL))
);
-- Una sola primera captacion por persona (F3)
CREATE UNIQUE INDEX uk_atrib_primera
  ON atribuciones_captacion (persona_id) WHERE es_primera_captacion;
```

### 4.4 Seguimiento, interés y consentimiento

```sql
-- ============================================================
-- interacciones — RN-24. "para no duplicar el esfuerzo entre Milagros,
-- Manuelita, el profe y Claudia". Debe costar UN toque o no se registra:
-- 33 de 36 filas del xlsx tienen exactamente 1 llamada
-- ============================================================
CREATE TABLE interacciones (
  id            uuid PRIMARY KEY DEFAULT app.id_nuevo(),
  persona_id    uuid NOT NULL REFERENCES personas(id) ON DELETE RESTRICT,
  usuario_id    uuid NOT NULL,                          -- FK diferida a usuarios
  canal         canal_interaccion NOT NULL,
  ocurrio_en    timestamptz NOT NULL DEFAULT now(),
  resultado     resultado_contacto,
  nota          text,                                   -- "NO PUEDE POR EL HORARIO"
  registrado_en timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT ck_interacciones_futuro CHECK (ocurrio_en <= now())
);

-- ============================================================
-- notas_ficha — RN-40. Append-only, sin notas privadas (DP-20).
-- "esta persona me bloqueo pero esta interesada"
-- ============================================================
CREATE TABLE notas_ficha (
  id            uuid PRIMARY KEY DEFAULT app.id_nuevo(),
  persona_id    uuid NOT NULL REFERENCES personas(id) ON DELETE RESTRICT,
  usuario_id    uuid NOT NULL,
  texto         text NOT NULL,
  escrita_en    timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT ck_notas_texto CHECK (char_length(btrim(texto)) > 0)
);

-- ============================================================
-- intereses_declarados — RN-25, RN-52. Vigente = el ULTIMO POR LINEA (DP-30):
-- declarar interes en un concierto no borra el interes en voluntariado
-- ============================================================
CREATE TABLE intereses_declarados (
  id            uuid PRIMARY KEY DEFAULT app.id_nuevo(),
  persona_id    uuid NOT NULL REFERENCES personas(id) ON DELETE RESTRICT,
  linea         linea_actividad,
  tipo_actividad_id uuid REFERENCES tipos_actividad(id) ON DELETE RESTRICT,
  tema_sugerido text,                                   -- solo 25% de llenado en el xlsx
  interes_curso interes_curso NOT NULL DEFAULT 'SIN_DATO',
  declarado_en  date NOT NULL DEFAULT CURRENT_DATE,
  registrado_por uuid, registrado_en timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT ck_intereses_algo CHECK (
    linea IS NOT NULL OR tipo_actividad_id IS NOT NULL
    OR tema_sugerido IS NOT NULL OR interes_curso <> 'SIN_DATO'
  )
);

-- ============================================================
-- consentimientos_contacto — DP-09. INFORMATIVO: se registra y NO filtra
-- envios (RN-12). Tension consciente con 01-contexto §9, registrada en DP-09
-- ============================================================
CREATE TABLE consentimientos_contacto (
  id            uuid PRIMARY KEY DEFAULT app.id_nuevo(),
  persona_id    uuid NOT NULL REFERENCES personas(id) ON DELETE RESTRICT,
  acepta        boolean NOT NULL,
  otorgado_por_representante boolean NOT NULL DEFAULT false,   -- RN-37, menores
  fecha         date NOT NULL DEFAULT CURRENT_DATE,
  origen        text NOT NULL,                          -- planilla de evento, puerta, verbal
  revocado_en   date,
  registrado_por uuid, registrado_en timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT ck_consent_revoca CHECK (revocado_en IS NULL OR revocado_en >= fecha)
);

-- ============================================================
-- contactos_enlace — DP-08. Es la MISMA persona, con area custodia y
-- restriccion de lectura. RN-28: "Carlos solo ve sus contactos de difusion"
-- ============================================================
CREATE TABLE contactos_enlace (
  id            uuid PRIMARY KEY DEFAULT app.id_nuevo(),
  persona_id    uuid NOT NULL REFERENCES personas(id) ON DELETE RESTRICT,
  area_custodia_id uuid NOT NULL REFERENCES areas(id) ON DELETE RESTRICT,
  tipo_enlace_id uuid NOT NULL REFERENCES tipos_enlace(id) ON DELETE RESTRICT,
  organizacion  text,
  es_restringido boolean NOT NULL DEFAULT true,         -- "hay gente del gobierno" (30-jul)
  registrado_por uuid, registrado_en timestamptz NOT NULL DEFAULT now(),
  modificado_por uuid, modificado_en timestamptz,
  CONSTRAINT uk_contactos_enlace UNIQUE (persona_id, area_custodia_id, tipo_enlace_id)
);

-- ============================================================
-- marcas_revision — DP-36. "Guardar nunca se bloquea" (RN-46).
-- Es la BANDEJA DE PENDIENTES, no un booleano perdido
-- ============================================================
CREATE TABLE marcas_revision (
  id            uuid PRIMARY KEY DEFAULT app.id_nuevo(),
  tipo_id       uuid NOT NULL REFERENCES tipos_marca_revision(id) ON DELETE RESTRICT,
  persona_id    uuid REFERENCES personas(id) ON DELETE RESTRICT,
  actividad_id  uuid REFERENCES actividades(id) ON DELETE RESTRICT,
  participacion_id uuid REFERENCES participaciones(id) ON DELETE RESTRICT,
  sede_id       uuid NOT NULL REFERENCES sedes(id) ON DELETE RESTRICT,   -- DENORM para RLS (F5)
  detalle       text,                                   -- valor original sin transformar (IMP-04)
  origen        origen_marca NOT NULL DEFAULT 'FORMULARIO',
  creada_por    uuid,                                   -- nulo cuando la genera la importacion
  creada_en     timestamptz NOT NULL DEFAULT now(),
  resuelta_en   timestamptz,
  resuelta_por  uuid,
  -- Exactamente UNA de las tres referencias
  CONSTRAINT ck_marcas_una_referencia CHECK (
    (persona_id IS NOT NULL)::int + (actividad_id IS NOT NULL)::int
      + (participacion_id IS NOT NULL)::int = 1
  ),
  CONSTRAINT ck_marcas_resolucion CHECK ((resuelta_en IS NULL) = (resuelta_por IS NULL)),
  CONSTRAINT ck_marcas_orden CHECK (resuelta_en IS NULL OR resuelta_en >= creada_en)
);
-- No acumular la misma marca abierta dos veces sobre el mismo objeto
CREATE UNIQUE INDEX uk_marcas_abierta_persona
  ON marcas_revision (tipo_id, persona_id) WHERE resuelta_en IS NULL AND persona_id IS NOT NULL;
```

### 4.5 Usuarios, permisos y reporte

```sql
-- ============================================================
-- usuarios — F9. Tabla propia en public, NUNCA se escribe en auth.
-- RN-50: todo usuario es antes una persona de la escuela.
-- El guardia de la puerta tiene el suyo porque es miembro y la puerta
-- es su voluntariado (DP-34)
-- ============================================================
CREATE TABLE usuarios (
  id            uuid PRIMARY KEY DEFAULT app.id_nuevo(),
  auth_user_id  uuid NOT NULL REFERENCES auth.users(id) ON DELETE RESTRICT,
  persona_id    uuid NOT NULL REFERENCES personas(id)   ON DELETE RESTRICT,
  correo        text NOT NULL,
  acceso_global boolean NOT NULL DEFAULT false,         -- RN-29: director y secretaria privada
  activo        boolean NOT NULL DEFAULT true,
  registrado_por uuid, registrado_en timestamptz NOT NULL DEFAULT now(),
  modificado_por uuid, modificado_en timestamptz,
  CONSTRAINT uk_usuarios_auth    UNIQUE (auth_user_id),
  CONSTRAINT uk_usuarios_persona UNIQUE (persona_id),   -- 1:0..1 (docs/03 §3.2)
  CONSTRAINT uk_usuarios_correo  UNIQUE (correo)
);

-- ============================================================
-- permisos_sede / permisos_area — RN-54, DP-35. CON VIGENCIA:
-- sin fechas, Milagros seguiria leyendo todo tras el relevo de Isdrey
-- ============================================================
CREATE TABLE permisos_sede (
  id            uuid PRIMARY KEY DEFAULT app.id_nuevo(),
  usuario_id    uuid NOT NULL REFERENCES usuarios(id) ON DELETE RESTRICT,
  sede_id       uuid NOT NULL REFERENCES sedes(id)    ON DELETE RESTRICT,
  nivel         nivel_permiso NOT NULL,
  desde         date NOT NULL DEFAULT CURRENT_DATE,
  hasta         date,
  otorgado_por  uuid,
  registrado_en timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT ck_psede_rango CHECK (hasta IS NULL OR hasta > desde)
);
CREATE UNIQUE INDEX uk_psede_vigente
  ON permisos_sede (usuario_id, sede_id, nivel) WHERE hasta IS NULL;

CREATE TABLE permisos_area (
  id            uuid PRIMARY KEY DEFAULT app.id_nuevo(),
  usuario_id    uuid NOT NULL REFERENCES usuarios(id) ON DELETE RESTRICT,
  area_id       uuid NOT NULL REFERENCES areas(id)    ON DELETE RESTRICT,
  nivel         nivel_permiso NOT NULL,
  desde         date NOT NULL DEFAULT CURRENT_DATE,
  hasta         date,
  otorgado_por  uuid,
  registrado_en timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT ck_parea_rango CHECK (hasta IS NULL OR hasta > desde)
);
CREATE UNIQUE INDEX uk_parea_vigente
  ON permisos_area (usuario_id, area_id, nivel) WHERE hasta IS NULL;

-- ============================================================
-- periodos_reporte — DP-10. Totales CONGELADOS al cerrar: el informe
-- enviado es reproducible tal como se envio. "si uno se pela por uno,
-- de una vez le devuelven esa vaina" (RN-31)
-- ============================================================
CREATE TABLE periodos_reporte (
  id            uuid PRIMARY KEY DEFAULT app.id_nuevo(),
  sede_id       uuid NOT NULL REFERENCES sedes(id) ON DELETE RESTRICT,
  anio          smallint NOT NULL,
  mes           smallint NOT NULL,
  es_cierre_semestral boolean NOT NULL DEFAULT false,
  estado        estado_periodo_reporte NOT NULL DEFAULT 'ABIERTO',
  totales       jsonb,                                 -- congelado al cerrar. Tolera secciones vacias
  cerrado_en    timestamptz,
  cerrado_por   uuid,
  registrado_en timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT uk_periodos UNIQUE (sede_id, anio, mes),
  CONSTRAINT ck_periodos_mes  CHECK (mes BETWEEN 1 AND 12),
  CONSTRAINT ck_periodos_anio CHECK (anio BETWEEN 2020 AND 2100),
  -- Cerrado, enviado o devuelto exige totales congelados (DP-10)
  CONSTRAINT ck_periodos_totales
    CHECK (estado = 'ABIERTO' OR (totales IS NOT NULL AND cerrado_en IS NOT NULL))
);
```

---

## 5. Relaciones y claves ajenas

### 5.1 Política general

**Ninguna clave ajena usa `ON DELETE CASCADE`.** Todas son `ON DELETE RESTRICT`, porque RN-41 dice que no
se borra nada: un `CASCADE` sería una puerta trasera al borrado. El retiro es `personas.archivada`.

### 5.2 Claves ajenas diferidas — el ciclo `personas` ↔ `usuarios`

`personas.registrado_por` apunta a `usuarios`, y `usuarios.persona_id` apunta a `personas`. Es un ciclo
real, no un error de diseño: RN-06 exige saber quién registró a cada persona, y RN-50 exige que todo
usuario sea una persona. El primer usuario del sistema no tiene registrador anterior.

Se resuelve con `DEFERRABLE INITIALLY DEFERRED` en la clave de auditoría, de modo que la semilla pueda
crear la primera persona y su usuario **en la misma transacción**.

```sql
-- Auditoria: quien registro y quien modifico. Diferida por el ciclo con la semilla
ALTER TABLE personas
  ADD CONSTRAINT fk_personas_registrado_por FOREIGN KEY (registrado_por)
    REFERENCES usuarios(id) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED,
  ADD CONSTRAINT fk_personas_modificado_por FOREIGN KEY (modificado_por)
    REFERENCES usuarios(id) ON DELETE RESTRICT;

-- El resto de las referencias a usuarios, no diferidas
ALTER TABLE personas_contactos
  ADD CONSTRAINT fk_pcontactos_reg  FOREIGN KEY (registrado_por) REFERENCES usuarios(id),
  ADD CONSTRAINT fk_pcontactos_mod  FOREIGN KEY (modificado_por) REFERENCES usuarios(id);
ALTER TABLE historial_identidad_persona
  ADD CONSTRAINT fk_hist_ident_usuario FOREIGN KEY (cambiado_por) REFERENCES usuarios(id);
ALTER TABLE personas_sedes
  ADD CONSTRAINT fk_psedes_reg FOREIGN KEY (registrado_por) REFERENCES usuarios(id);
ALTER TABLE estados_persona
  ADD CONSTRAINT fk_estados_reg FOREIGN KEY (registrado_por) REFERENCES usuarios(id);
ALTER TABLE roles_asignados
  ADD CONSTRAINT fk_roles_reg   FOREIGN KEY (registrado_por) REFERENCES usuarios(id),
  ADD CONSTRAINT fk_roles_grupo FOREIGN KEY (grupo_id)       REFERENCES grupos(id);
ALTER TABLE actividades
  ADD CONSTRAINT fk_actividades_reg FOREIGN KEY (registrado_por) REFERENCES usuarios(id),
  ADD CONSTRAINT fk_actividades_mod FOREIGN KEY (modificado_por) REFERENCES usuarios(id);
ALTER TABLE actividades_etiquetas
  ADD CONSTRAINT fk_actetiq_reg FOREIGN KEY (registrado_por) REFERENCES usuarios(id);
ALTER TABLE etiquetas
  ADD CONSTRAINT fk_etiquetas_creador FOREIGN KEY (creado_por) REFERENCES usuarios(id);
ALTER TABLE participaciones
  ADD CONSTRAINT fk_part_reg FOREIGN KEY (registrado_por) REFERENCES usuarios(id),
  ADD CONSTRAINT fk_part_mod FOREIGN KEY (modificado_por) REFERENCES usuarios(id);
ALTER TABLE inscripciones
  ADD CONSTRAINT fk_insc_reg FOREIGN KEY (registrado_por) REFERENCES usuarios(id),
  ADD CONSTRAINT fk_insc_mod FOREIGN KEY (modificado_por) REFERENCES usuarios(id);
ALTER TABLE atribuciones_captacion
  ADD CONSTRAINT fk_atrib_reg FOREIGN KEY (registrado_por) REFERENCES usuarios(id);
ALTER TABLE interacciones
  ADD CONSTRAINT fk_interacciones_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id);
ALTER TABLE notas_ficha
  ADD CONSTRAINT fk_notas_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id);
ALTER TABLE intereses_declarados
  ADD CONSTRAINT fk_intereses_reg FOREIGN KEY (registrado_por) REFERENCES usuarios(id);
ALTER TABLE consentimientos_contacto
  ADD CONSTRAINT fk_consent_reg FOREIGN KEY (registrado_por) REFERENCES usuarios(id);
ALTER TABLE contactos_enlace
  ADD CONSTRAINT fk_cenlace_reg FOREIGN KEY (registrado_por) REFERENCES usuarios(id),
  ADD CONSTRAINT fk_cenlace_mod FOREIGN KEY (modificado_por) REFERENCES usuarios(id);
ALTER TABLE marcas_revision
  ADD CONSTRAINT fk_marcas_creador  FOREIGN KEY (creada_por)   REFERENCES usuarios(id),
  ADD CONSTRAINT fk_marcas_resolutor FOREIGN KEY (resuelta_por) REFERENCES usuarios(id);
ALTER TABLE organizaciones_aliadas
  ADD CONSTRAINT fk_org_reg FOREIGN KEY (registrado_por) REFERENCES usuarios(id),
  ADD CONSTRAINT fk_org_mod FOREIGN KEY (modificado_por) REFERENCES usuarios(id);
ALTER TABLE cursos
  ADD CONSTRAINT fk_cursos_reg FOREIGN KEY (registrado_por) REFERENCES usuarios(id);
ALTER TABLE grupos
  ADD CONSTRAINT fk_grupos_reg FOREIGN KEY (registrado_por) REFERENCES usuarios(id);
ALTER TABLE usuarios
  ADD CONSTRAINT fk_usuarios_reg FOREIGN KEY (registrado_por) REFERENCES usuarios(id),
  ADD CONSTRAINT fk_usuarios_mod FOREIGN KEY (modificado_por) REFERENCES usuarios(id);
ALTER TABLE permisos_sede
  ADD CONSTRAINT fk_psede_otorgante FOREIGN KEY (otorgado_por) REFERENCES usuarios(id);
ALTER TABLE permisos_area
  ADD CONSTRAINT fk_parea_otorgante FOREIGN KEY (otorgado_por) REFERENCES usuarios(id);
ALTER TABLE periodos_reporte
  ADD CONSTRAINT fk_periodos_cerrador FOREIGN KEY (cerrado_por) REFERENCES usuarios(id);
-- Los seis catalogos de enums abiertos
ALTER TABLE ocupaciones              ADD CONSTRAINT fk_ocup_creador FOREIGN KEY (creado_por) REFERENCES usuarios(id);
ALTER TABLE tipos_actividad          ADD CONSTRAINT fk_tact_creador FOREIGN KEY (creado_por) REFERENCES usuarios(id);
ALTER TABLE medios_difusion          ADD CONSTRAINT fk_medio_creador FOREIGN KEY (creado_por) REFERENCES usuarios(id);
ALTER TABLE tipos_organizacion_aliada ADD CONSTRAINT fk_torg_creador FOREIGN KEY (creado_por) REFERENCES usuarios(id);
ALTER TABLE tipos_enlace             ADD CONSTRAINT fk_tenl_creador FOREIGN KEY (creado_por) REFERENCES usuarios(id);
ALTER TABLE tipos_marca_revision     ADD CONSTRAINT fk_tmarca_creador FOREIGN KEY (creado_por) REFERENCES usuarios(id);
```

### 5.3 Cardinalidades

| Relación | Card. | Regla |
|---|---|---|
| `personas` — `personas_sedes` — `sedes` | 1:N / N:1 | **Un solo vínculo vigente** (DP-03) |
| `personas` — `estados_persona` | 1:N | Append-only, un vigente (RN-01) |
| `personas` — `personas_contactos` | 1:N | Un principal por tipo (DP-33) |
| `personas` — `roles_asignados` — `areas` | 1:N / N:1 | Acumulables, con vigencia (RN-08, DP-12) |
| `personas` — `participaciones` — `actividades` | 1:N / N:1 | **Par único** (P04) |
| `actividades` — `grupos` | N:1 opcional | La clase suelta es actividad (RN-38) |
| `actividades` — `actividades_etiquetas` — `etiquetas` | N:M | *"día de la tierra más algo de arte"* |
| `personas` — `atribuciones_captacion` | 1:N | Por evento; una primera captación |
| `atribuciones_captacion` — `personas` (invitó) | N:1 opcional | Autorreferencia, selector (RN-20) |
| `personas` — `usuarios` | 1:0..1 | Solo algunas personas operan el sistema |
| `usuarios` — `permisos_sede` / `permisos_area` | 1:N | Con vigencia (RN-54) |
| `usuarios` — `auth.users` | 1:1 | Supabase gobierna el lado `auth` (F9) |

---

## 6. Triggers

Cinco cosas no se pueden expresar con `CHECK` porque miran otra tabla o dependen del usuario de sesión.

```sql
-- ============================================================
-- 6.1 Usuario de la sesion. Base de la auditoria y de la RLS
-- ============================================================
CREATE OR REPLACE FUNCTION app.usuario_actual() RETURNS uuid
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT u.id FROM usuarios u
  WHERE u.auth_user_id = auth.uid() AND u.activo;
$$;

-- ============================================================
-- 6.2 Auditoria automatica (RN-06, RN-47)
-- Si registrado_por llega nulo, lo pone; en UPDATE sella modificado_*.
-- Nota: auth.uid() es nulo bajo service_role, por eso no se fuerza NOT NULL aqui
-- ============================================================
CREATE OR REPLACE FUNCTION app.tg_auditoria() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    IF to_jsonb(NEW) ? 'registrado_por' AND NEW.registrado_por IS NULL THEN
      NEW.registrado_por := app.usuario_actual();
    END IF;
  ELSIF TG_OP = 'UPDATE' THEN
    NEW.modificado_por := coalesce(app.usuario_actual(), OLD.modificado_por);
    NEW.modificado_en  := now();
    NEW.registrado_por := OLD.registrado_por;   -- inmutable
    NEW.registrado_en  := OLD.registrado_en;
  END IF;
  RETURN NEW;
END $$;
-- Se aplica a las 12 tablas con columnas modificado_*

-- ============================================================
-- 6.3 Normalizacion de valores de contacto (F-3, F-8, P01, P02)
-- ============================================================
CREATE OR REPLACE FUNCTION app.tg_normaliza_contacto() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
  NEW.valor := btrim(NEW.valor);                                  -- F-1: 154 casos en el xlsx (P17)
  NEW.valor_normalizado := CASE NEW.tipo
    WHEN 'TELEFONO'      THEN app.normaliza_telefono(NEW.valor)
    WHEN 'TELEFONO_INTL' THEN app.normaliza_telefono(NEW.valor)
    WHEN 'CORREO'        THEN app.normaliza_correo(NEW.valor)
    ELSE app.normaliza_nombre(NEW.valor)
  END;
  RETURN NEW;
END $$;
CREATE TRIGGER tg_pcontactos_normaliza BEFORE INSERT OR UPDATE ON personas_contactos
  FOR EACH ROW EXECUTE FUNCTION app.tg_normaliza_contacto();

-- ============================================================
-- 6.4 Denormalizaciones que la RLS obliga (F5)
-- ============================================================
-- personas.sede_vigente_id desde personas_sedes
CREATE OR REPLACE FUNCTION app.tg_sede_vigente() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
  UPDATE personas p SET sede_vigente_id = (
    SELECT ps.sede_id FROM personas_sedes ps
    WHERE ps.persona_id = p.id AND ps.hasta IS NULL
  ) WHERE p.id = coalesce(NEW.persona_id, OLD.persona_id);
  RETURN NULL;
END $$;
CREATE TRIGGER tg_psedes_sede_vigente AFTER INSERT OR UPDATE OR DELETE ON personas_sedes
  FOR EACH ROW EXECUTE FUNCTION app.tg_sede_vigente();

-- personas.estado_vigente y ultimo_estado_alcanzado desde estados_persona (RN-11)
CREATE OR REPLACE FUNCTION app.tg_estado_vigente() RETURNS trigger
LANGUAGE plpgsql AS $$
DECLARE orden constant estado_persona[] :=
  ARRAY['CONTACTO','ASISTENTE','PROBACIONISTA','MIEMBRO']::estado_persona[];
BEGIN
  UPDATE personas p SET
    estado_vigente = coalesce(
      (SELECT e.estado FROM estados_persona e
        WHERE e.persona_id = p.id AND e.hasta IS NULL), 'CONTACTO'),
    ultimo_estado_alcanzado = (
      SELECT e.estado FROM estados_persona e
      WHERE e.persona_id = p.id AND e.estado <> 'INACTIVO'
      ORDER BY array_position(orden, e.estado) DESC NULLS LAST LIMIT 1)
  WHERE p.id = NEW.persona_id;
  RETURN NULL;
END $$;
CREATE TRIGGER tg_estados_vigente AFTER INSERT OR UPDATE ON estados_persona
  FOR EACH ROW EXECUTE FUNCTION app.tg_estado_vigente();

-- ============================================================
-- 6.5 Menor de edad A LA FECHA DE REGISTRO (RN-37, IMP-13)
-- Columna y no generada: la expresion no es inmutable
-- ============================================================
CREATE OR REPLACE FUNCTION app.tg_menor_de_edad() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
  NEW.es_menor_de_edad := NEW.fecha_nacimiento IS NOT NULL
    AND NEW.fecha_nacimiento > ((NEW.registrado_en AT TIME ZONE 'UTC')::date - INTERVAL '18 years');
  RETURN NEW;
END $$;
CREATE TRIGGER tg_personas_menor BEFORE INSERT OR UPDATE OF fecha_nacimiento ON personas
  FOR EACH ROW EXECUTE FUNCTION app.tg_menor_de_edad();

-- ============================================================
-- 6.6 Las marcas de revision se generan solas (RN-46, DP-36)
-- ============================================================
CREATE OR REPLACE FUNCTION app.marca(p_codigo text, p_persona uuid,
                                     p_detalle text DEFAULT NULL) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO marcas_revision (tipo_id, persona_id, sede_id, detalle, creada_por)
  SELECT t.id, p.id, p.sede_vigente_id, p_detalle, app.usuario_actual()
  FROM tipos_marca_revision t, personas p
  WHERE t.codigo = p_codigo AND p.id = p_persona
  ON CONFLICT DO NOTHING;     -- el indice unico parcial evita duplicar la marca abierta
END $$;

CREATE OR REPLACE FUNCTION app.tg_marcas_persona() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.cedula IS NULL AND NEW.estado_vigente <> 'CONTACTO' THEN
    PERFORM app.marca('CEDULA_FALTANTE', NEW.id);          -- DP-24, P03
  END IF;
  IF NEW.apellido IS NULL OR btrim(NEW.apellido) = '' THEN
    PERFORM app.marca('APELLIDO_FALTANTE', NEW.id);        -- DP-31, P16
  END IF;
  IF NEW.es_menor_de_edad AND NEW.representante_nombre IS NULL THEN
    PERFORM app.marca('MENOR_SIN_REPRESENTANTE', NEW.id);  -- RN-37, P25
  END IF;
  RETURN NULL;
END $$;
CREATE TRIGGER tg_personas_marcas AFTER INSERT OR UPDATE ON personas
  FOR EACH ROW EXECUTE FUNCTION app.tg_marcas_persona();

-- Telefono o correo invalido -> marca (P02, P05)
CREATE OR REPLACE FUNCTION app.tg_marcas_contacto() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
  IF NOT NEW.es_valido THEN
    PERFORM app.marca(
      CASE WHEN NEW.tipo IN ('TELEFONO','TELEFONO_INTL')
           THEN 'TELEFONO_INVALIDO' ELSE 'CORREO_INVALIDO' END,
      NEW.persona_id, NEW.valor);
  END IF;
  RETURN NULL;
END $$;
CREATE TRIGGER tg_pcontactos_marcas AFTER INSERT OR UPDATE ON personas_contactos
  FOR EACH ROW EXECUTE FUNCTION app.tg_marcas_contacto();

-- Rol cerrado con permisos de area abiertos -> marca (RN-54, DP-35)
CREATE OR REPLACE FUNCTION app.tg_marcas_permiso_huerfano() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.hasta IS NOT NULL AND OLD.hasta IS NULL AND NEW.area_id IS NOT NULL THEN
    IF EXISTS (
      SELECT 1 FROM permisos_area pa JOIN usuarios u ON u.id = pa.usuario_id
      WHERE u.persona_id = NEW.persona_id AND pa.area_id = NEW.area_id AND pa.hasta IS NULL
    ) THEN
      PERFORM app.marca('PERMISO_SIN_ROL_VIGENTE', NEW.persona_id,
                        'Rol ' || NEW.rol::text || ' cerrado el ' || NEW.hasta);
    END IF;
  END IF;
  RETURN NULL;
END $$;
CREATE TRIGGER tg_roles_permiso_huerfano AFTER UPDATE ON roles_asignados
  FOR EACH ROW EXECUTE FUNCTION app.tg_marcas_permiso_huerfano();

-- ============================================================
-- 6.7 Bitacora de identidad (RN-47)
-- ============================================================
CREATE OR REPLACE FUNCTION app.tg_hist_identidad() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.cedula IS DISTINCT FROM OLD.cedula THEN
    INSERT INTO historial_identidad_persona (persona_id, campo, valor_anterior, valor_nuevo, cambiado_por)
      VALUES (NEW.id, 'cedula', OLD.cedula, NEW.cedula, app.usuario_actual());
  END IF;
  IF NEW.nombre IS DISTINCT FROM OLD.nombre THEN
    INSERT INTO historial_identidad_persona (persona_id, campo, valor_anterior, valor_nuevo, cambiado_por)
      VALUES (NEW.id, 'nombre', OLD.nombre, NEW.nombre, app.usuario_actual());
  END IF;
  IF NEW.apellido IS DISTINCT FROM OLD.apellido THEN
    INSERT INTO historial_identidad_persona (persona_id, campo, valor_anterior, valor_nuevo, cambiado_por)
      VALUES (NEW.id, 'apellido', OLD.apellido, NEW.apellido, app.usuario_actual());
  END IF;
  RETURN NULL;
END $$;
CREATE TRIGGER tg_personas_hist_identidad AFTER UPDATE ON personas
  FOR EACH ROW EXECUTE FUNCTION app.tg_hist_identidad();

-- ============================================================
-- 6.8 Coherencia que el CHECK no alcanza
-- ============================================================
-- El medio exige la referencia que declara su catalogo (RN-20, IMP-16, IMP-17)
CREATE OR REPLACE FUNCTION app.tg_valida_atribucion() RETURNS trigger
LANGUAGE plpgsql AS $$
DECLARE m record;
BEGIN
  SELECT exige_persona, exige_organizacion INTO m FROM medios_difusion WHERE id = NEW.medio_id;
  IF m.exige_persona AND NEW.invitado_por_persona_id IS NULL THEN
    RAISE EXCEPTION 'El medio exige indicar quien invito (RN-20)';
  END IF;
  IF m.exige_organizacion AND NEW.organizacion_aliada_id IS NULL THEN
    RAISE EXCEPTION 'El medio exige indicar la organizacion aliada (DP-04)';
  END IF;
  -- RN-44: se DERIVA si quien invito pertenecia a la escuela A ESA FECHA
  IF NEW.invitado_por_persona_id IS NOT NULL THEN
    NEW.invitado_por_interno := EXISTS (
      SELECT 1 FROM estados_persona e
      WHERE e.persona_id = NEW.invitado_por_persona_id
        AND e.estado IN ('PROBACIONISTA','MIEMBRO')
        AND daterange(e.desde, e.hasta, '[)') @> NEW.fecha
    ) OR EXISTS (
      SELECT 1 FROM roles_asignados r
      WHERE r.persona_id = NEW.invitado_por_persona_id
        AND daterange(r.desde, r.hasta, '[)') @> NEW.fecha
    );
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER tg_atrib_valida BEFORE INSERT OR UPDATE ON atribuciones_captacion
  FOR EACH ROW EXECUTE FUNCTION app.tg_valida_atribucion();

-- DP-24: la cedula SI es obligatoria al inscribir a un curso
CREATE OR REPLACE FUNCTION app.tg_valida_inscripcion() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM personas WHERE id = NEW.persona_id AND cedula IS NOT NULL) THEN
    RAISE EXCEPTION 'La cedula es obligatoria para inscribir a un curso (RN-02, DP-24)';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER tg_insc_valida BEFORE INSERT ON inscripciones
  FOR EACH ROW EXECUTE FUNCTION app.tg_valida_inscripcion();

-- La actividad ligada a un grupo debe ser de la misma sede (RN-38)
CREATE OR REPLACE FUNCTION app.tg_valida_actividad() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.grupo_id IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM grupos g WHERE g.id = NEW.grupo_id AND g.sede_id = NEW.sede_id
  ) THEN
    RAISE EXCEPTION 'El grupo pertenece a otra sede';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER tg_actividades_valida BEFORE INSERT OR UPDATE ON actividades
  FOR EACH ROW EXECUTE FUNCTION app.tg_valida_actividad();

-- ============================================================
-- 6.9 La participacion CONGELA el interno/externo y avanza el estado
-- Es la unica transicion automatica de la maquina (docs/03 §5)
-- ============================================================
CREATE OR REPLACE FUNCTION app.tg_participacion() RETURNS trigger
LANGUAGE plpgsql AS $$
DECLARE f_act date; est estado_persona;
BEGIN
  SELECT (a.inicio AT TIME ZONE s.zona_horaria)::date, a.sede_id
    INTO f_act, NEW.sede_id
    FROM actividades a JOIN sedes s ON s.id = a.sede_id WHERE a.id = NEW.actividad_id;

  SELECT e.estado INTO est FROM estados_persona e
   WHERE e.persona_id = NEW.persona_id AND daterange(e.desde, e.hasta, '[)') @> f_act
   LIMIT 1;

  -- RN-10: interno = PROBACIONISTA/MIEMBRO o CUALQUIER rol vigente a esa fecha
  NEW.es_interno_en_la_fecha := coalesce(est IN ('PROBACIONISTA','MIEMBRO'), false)
    OR EXISTS (SELECT 1 FROM roles_asignados r
               WHERE r.persona_id = NEW.persona_id
                 AND daterange(r.desde, r.hasta, '[)') @> f_act);

  NEW.categoria_oina_en_la_fecha := CASE
    WHEN EXISTS (SELECT 1 FROM roles_asignados r WHERE r.persona_id = NEW.persona_id
                   AND r.rol = 'FUERZA_VIVA' AND daterange(r.desde, r.hasta, '[)') @> f_act)
      THEN 'FUERZA_VIVA'::categoria_oina
    WHEN est = 'MIEMBRO'       THEN 'MIEMBROS'::categoria_oina
    WHEN est = 'PROBACIONISTA' THEN 'PROBACIONISMO'::categoria_oina
    ELSE NULL END;
  RETURN NEW;
END $$;
CREATE TRIGGER tg_part_congela BEFORE INSERT ON participaciones
  FOR EACH ROW EXECUTE FUNCTION app.tg_participacion();

-- CONTACTO -> ASISTENTE automatico al registrar la primera participacion
CREATE OR REPLACE FUNCTION app.tg_part_avanza_estado() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
  IF EXISTS (SELECT 1 FROM personas WHERE id = NEW.persona_id AND estado_vigente = 'CONTACTO') THEN
    UPDATE estados_persona SET hasta = CURRENT_DATE
      WHERE persona_id = NEW.persona_id AND hasta IS NULL;
    INSERT INTO estados_persona (persona_id, estado, desde, disparador, es_automatico, registrado_por)
      VALUES (NEW.persona_id, 'ASISTENTE', CURRENT_DATE,
              'Primera participacion registrada', true, NEW.registrado_por);
  END IF;
  RETURN NULL;
END $$;
CREATE TRIGGER tg_part_estado AFTER INSERT ON participaciones
  FOR EACH ROW EXECUTE FUNCTION app.tg_part_avanza_estado();
```

---

## 7. Índices

Cada índice responde a una consulta citada en `03` §7 o a una regla. Ninguno es especulativo.

```sql
-- ============================================================
-- 7.1 Busqueda de personas — consulta 1 y RN-39. La mas usada del sistema
-- ============================================================
-- Nombre difuso: ID-6 pide "similitud alta de nombre", no igualdad (F7)
CREATE INDEX idx_personas_nombre_trgm ON personas USING gin (nombre_busqueda gin_trgm_ops);
-- Prefijo de nombre para el autocompletado de la pantalla de participacion (D11)
CREATE INDEX idx_personas_nombre_prefijo ON personas (nombre_busqueda text_pattern_ops);
-- Busqueda por telefono o correo normalizado (RN-39) y deteccion de duplicado (RN-51)
CREATE INDEX idx_pcontactos_normalizado ON personas_contactos (valor_normalizado);
CREATE INDEX idx_pcontactos_persona     ON personas_contactos (persona_id);
-- Similitud de telefono no hace falta: la comparacion es exacta sobre el normalizado

-- ============================================================
-- 7.2 Filtro de RLS — se ejecuta en CADA lectura, es el mas critico
-- ============================================================
CREATE INDEX idx_personas_sede_vigente ON personas (sede_vigente_id) WHERE NOT archivada;
CREATE INDEX idx_psede_usuario_vigente ON permisos_sede (usuario_id, sede_id) WHERE hasta IS NULL;
CREATE INDEX idx_parea_usuario_vigente ON permisos_area (usuario_id, area_id) WHERE hasta IS NULL;
CREATE INDEX idx_usuarios_auth         ON usuarios (auth_user_id) WHERE activo;

-- ============================================================
-- 7.3 Cumpleanos — consulta 2, RN-35. Vista de entrada del sistema
-- ============================================================
-- Indice de expresion: el mes y el dia, no la fecha completa
CREATE INDEX idx_personas_cumple ON personas
  ((extract(month from fecha_nacimiento)), (extract(day from fecha_nacimiento)))
  WHERE fecha_nacimiento IS NOT NULL AND NOT archivada;

-- ============================================================
-- 7.4 Actividades y participacion — consultas 3, 6
-- ============================================================
CREATE INDEX idx_actividades_sede_inicio ON actividades (sede_id, inicio DESC);
CREATE INDEX idx_actividades_proximas    ON actividades (inicio)
  WHERE estado = 'PLANIFICADA';                       -- pantalla de entrada (D10)
CREATE INDEX idx_actividades_grupo       ON actividades (grupo_id) WHERE grupo_id IS NOT NULL;
CREATE INDEX idx_actividades_circulo     ON actividades (circulo, inicio);  -- "3.er circulo" del informe
CREATE INDEX idx_part_actividad          ON participaciones (actividad_id);
CREATE INDEX idx_part_persona            ON participaciones (persona_id);
-- Conteo internos/externos por actividad (RN-17, consulta 3) sin tocar la tabla base
CREATE INDEX idx_part_conteo ON participaciones (actividad_id, es_interno_en_la_fecha)
  WHERE asistio;
CREATE INDEX idx_actetiq_etiqueta        ON actividades_etiquetas (etiqueta_id);

-- ============================================================
-- 7.5 Atribucion — consulta 5, bucle A. "Rotary 9, Alejandro 4" (30-jul)
-- ============================================================
CREATE INDEX idx_atrib_persona     ON atribuciones_captacion (persona_id);
CREATE INDEX idx_atrib_invitador   ON atribuciones_captacion (invitado_por_persona_id, fecha)
  WHERE invitado_por_persona_id IS NOT NULL;           -- RN-22: cuantas invito cada quien
CREATE INDEX idx_atrib_organizacion ON atribuciones_captacion (organizacion_aliada_id, fecha)
  WHERE organizacion_aliada_id IS NOT NULL;            -- rendimiento por alianza (DP-04)
CREATE INDEX idx_atrib_medio_fecha ON atribuciones_captacion (medio_id, fecha);

-- ============================================================
-- 7.6 Estados y embudo — consultas 4, 9, 10
-- ============================================================
CREATE INDEX idx_estados_persona    ON estados_persona (persona_id, desde DESC);
-- Altas y bajas del periodo (RN-33): estado + fecha de inicio
CREATE INDEX idx_estados_altas      ON estados_persona (estado, desde);
CREATE INDEX idx_estados_bajas      ON estados_persona (estado, hasta) WHERE hasta IS NOT NULL;
CREATE INDEX idx_psedes_persona     ON personas_sedes (persona_id, desde DESC);
CREATE INDEX idx_psedes_sede        ON personas_sedes (sede_id) WHERE hasta IS NULL;
CREATE INDEX idx_roles_persona      ON roles_asignados (persona_id) WHERE hasta IS NULL;
CREATE INDEX idx_roles_area         ON roles_asignados (area_id)    WHERE hasta IS NULL;  -- consulta 11

-- ============================================================
-- 7.7 Bitacora unica de la ficha — consulta 8
-- La vista une notas, interacciones y cambios de estado en una linea de tiempo
-- ============================================================
CREATE INDEX idx_interacciones_persona ON interacciones (persona_id, ocurrio_en DESC);
CREATE INDEX idx_notas_persona         ON notas_ficha    (persona_id, escrita_en DESC);

-- ============================================================
-- 7.8 Interes declarado — consulta 7. Vigente = ultimo POR LINEA (RN-52)
-- ============================================================
CREATE INDEX idx_intereses_persona_linea
  ON intereses_declarados (persona_id, linea, declarado_en DESC);
CREATE INDEX idx_intereses_linea ON intereses_declarados (linea, declarado_en DESC);

-- ============================================================
-- 7.9 Bandeja de marcas — DP-36
-- ============================================================
CREATE INDEX idx_marcas_pendientes ON marcas_revision (sede_id, tipo_id, creada_en)
  WHERE resuelta_en IS NULL;
CREATE INDEX idx_marcas_persona    ON marcas_revision (persona_id) WHERE resuelta_en IS NULL;

-- ============================================================
-- 7.10 Inscripciones y auditoria
-- ============================================================
CREATE INDEX idx_insc_grupo   ON inscripciones (grupo_id, estado);
CREATE INDEX idx_insc_persona ON inscripciones (persona_id);
-- RN-06: cuantas personas registro cada quien
CREATE INDEX idx_personas_registrador ON personas (registrado_por, registrado_en);
CREATE INDEX idx_hist_ident_persona   ON historial_identidad_persona (persona_id, cambiado_en DESC);
CREATE INDEX idx_cenlace_area ON contactos_enlace (area_custodia_id);
```

**Índices deliberadamente ausentes.** No hay índice sobre `personas.cedula` suelto: el único parcial
`uk_personas_cedula` ya lo cubre. No hay índices sobre las tablas de catálogo más allá de su clave única:
tienen decenas de filas y el planificador hará *seq scan*, que es lo correcto.

---

## 8. Row Level Security

Es la única frontera de seguridad del sistema (F10). Cada política corresponde a una regla citada.

```sql
-- ============================================================
-- 8.1 Cerrar la puerta antes de abrir ventanas
-- ============================================================
REVOKE ALL ON ALL TABLES    IN SCHEMA public FROM anon;
REVOKE ALL ON ALL SEQUENCES IN SCHEMA public FROM anon;
REVOKE ALL ON ALL FUNCTIONS IN SCHEMA public FROM anon;
ALTER DEFAULT PRIVILEGES IN SCHEMA public REVOKE ALL ON TABLES FROM anon;

-- RN-41: no existe borrado. Se revoca el privilegio, no se confia en la aplicacion (F6)
REVOKE DELETE ON ALL TABLES IN SCHEMA public FROM authenticated;

-- RLS en TODAS las tablas. Una tabla sin RLS queda abierta: es el error clasico
--
-- CAUTELA con FORCE: somete tambien al DUEÑO de la tabla a las politicas. Es lo
-- correcto en produccion, pero rompe migraciones y semillas ejecutadas como dueño.
-- `service_role` tiene BYPASSRLS y no se ve afectado; ejecutar la semilla con el.
-- Si una migracion posterior falla por esto, aplicar solo ENABLE y dejar FORCE
-- para el final del despliegue.
DO $$ DECLARE t text;
BEGIN
  FOR t IN SELECT tablename FROM pg_tables WHERE schemaname = 'public' LOOP
    EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format('ALTER TABLE public.%I FORCE ROW LEVEL SECURITY', t);
  END LOOP;
END $$;

-- ============================================================
-- 8.2 Funciones auxiliares. STABLE para que se evaluen una vez por consulta,
-- no una vez por fila
-- ============================================================
CREATE OR REPLACE FUNCTION app.es_global() RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT coalesce((SELECT u.acceso_global FROM usuarios u
                   WHERE u.auth_user_id = auth.uid() AND u.activo), false);
$$;   -- RN-29: director nacional y secretaria privada

CREATE OR REPLACE FUNCTION app.sedes_legibles() RETURNS uuid[]
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT coalesce(array_agg(DISTINCT ps.sede_id), '{}')
  FROM permisos_sede ps JOIN usuarios u ON u.id = ps.usuario_id
  WHERE u.auth_user_id = auth.uid() AND u.activo
    AND ps.hasta IS NULL;      -- RN-54: el permiso caducado no da acceso
$$;

CREATE OR REPLACE FUNCTION app.sedes_escribibles() RETURNS uuid[]
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT coalesce(array_agg(DISTINCT ps.sede_id), '{}')
  FROM permisos_sede ps JOIN usuarios u ON u.id = ps.usuario_id
  WHERE u.auth_user_id = auth.uid() AND u.activo
    AND ps.hasta IS NULL AND ps.nivel = 'ESCRITURA';
$$;

CREATE OR REPLACE FUNCTION app.areas_legibles() RETURNS uuid[]
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT coalesce(array_agg(DISTINCT pa.area_id), '{}')
  FROM permisos_area pa JOIN usuarios u ON u.id = pa.usuario_id
  WHERE u.auth_user_id = auth.uid() AND u.activo AND pa.hasta IS NULL;
$$;

CREATE OR REPLACE FUNCTION app.puede_leer_sede(p uuid) RETURNS boolean
LANGUAGE sql STABLE AS $$ SELECT app.es_global() OR p = ANY(app.sedes_legibles()); $$;

CREATE OR REPLACE FUNCTION app.puede_escribir_sede(p uuid) RETURNS boolean
LANGUAGE sql STABLE AS $$ SELECT app.es_global() OR p = ANY(app.sedes_escribibles()); $$;

-- ============================================================
-- 8.3 personas — RN-27: escritura de alta casi universal, lectura cerrada.
-- La asimetria de D2 del documento 02 se vuelve dos politicas distintas
-- ============================================================
CREATE POLICY personas_lectura ON personas FOR SELECT TO authenticated
  USING (app.puede_leer_sede(sede_vigente_id) OR sede_vigente_id IS NULL);

CREATE POLICY personas_alta ON personas FOR INSERT TO authenticated
  WITH CHECK (app.usuario_actual() IS NOT NULL);   -- RN-45: cualquier usuario activo da de alta

CREATE POLICY personas_edicion ON personas FOR UPDATE TO authenticated
  USING (app.puede_escribir_sede(sede_vigente_id))
  WITH CHECK (app.puede_escribir_sede(sede_vigente_id));
-- Sin politica DELETE: RN-41

-- ============================================================
-- 8.4 Tablas hijas de persona: heredan la visibilidad de la ficha
-- ============================================================
CREATE POLICY pcontactos_lectura ON personas_contactos FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM personas p WHERE p.id = persona_id
                   AND (app.puede_leer_sede(p.sede_vigente_id) OR p.sede_vigente_id IS NULL)));
CREATE POLICY pcontactos_escritura ON personas_contactos FOR INSERT TO authenticated
  WITH CHECK (app.usuario_actual() IS NOT NULL);
CREATE POLICY pcontactos_edicion ON personas_contactos FOR UPDATE TO authenticated
  USING (EXISTS (SELECT 1 FROM personas p WHERE p.id = persona_id
                   AND app.puede_escribir_sede(p.sede_vigente_id)));

-- estados_persona: APPEND-ONLY. Solo SELECT e INSERT. Sin UPDATE ni DELETE (RN-01)
CREATE POLICY estados_lectura ON estados_persona FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM personas p WHERE p.id = persona_id
                   AND (app.puede_leer_sede(p.sede_vigente_id) OR p.sede_vigente_id IS NULL)));
CREATE POLICY estados_insercion ON estados_persona FOR INSERT TO authenticated
  WITH CHECK (app.usuario_actual() IS NOT NULL);
-- El cierre del periodo (poner `hasta`) lo hace un trigger SECURITY DEFINER, no el usuario

-- notas_ficha: APPEND-ONLY y SIN notas privadas (RN-40, DP-20)
CREATE POLICY notas_lectura ON notas_ficha FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM personas p WHERE p.id = persona_id
                   AND (app.puede_leer_sede(p.sede_vigente_id) OR p.sede_vigente_id IS NULL)));
CREATE POLICY notas_insercion ON notas_ficha FOR INSERT TO authenticated
  WITH CHECK (usuario_id = app.usuario_actual());
-- Sin UPDATE ni DELETE: "no se editan ni se borran" (RN-40)

-- ============================================================
-- 8.5 contactos_enlace — RN-28: los ve el area que los custodia,
-- mas los accesos globales. "Carlos solo ve sus contactos de difusion"
-- ============================================================
CREATE POLICY cenlace_lectura ON contactos_enlace FOR SELECT TO authenticated
  USING (
    NOT es_restringido
    OR app.es_global()
    OR area_custodia_id = ANY(app.areas_legibles())
  );
CREATE POLICY cenlace_escritura ON contactos_enlace FOR INSERT TO authenticated
  WITH CHECK (app.es_global() OR area_custodia_id = ANY(app.areas_legibles()));

-- ============================================================
-- 8.6 Actividades y participacion — por sede
-- ============================================================
CREATE POLICY actividades_lectura ON actividades FOR SELECT TO authenticated
  USING (app.puede_leer_sede(sede_id));
CREATE POLICY actividades_escritura ON actividades FOR INSERT TO authenticated
  WITH CHECK (app.puede_escribir_sede(sede_id));
CREATE POLICY actividades_edicion ON actividades FOR UPDATE TO authenticated
  USING (app.puede_escribir_sede(sede_id)) WITH CHECK (app.puede_escribir_sede(sede_id));

-- participaciones usa su sede_id denormalizado (F5): sin join en la politica
CREATE POLICY part_lectura ON participaciones FOR SELECT TO authenticated
  USING (app.puede_leer_sede(sede_id));
CREATE POLICY part_escritura ON participaciones FOR INSERT TO authenticated
  WITH CHECK (app.puede_escribir_sede(sede_id));
CREATE POLICY part_edicion ON participaciones FOR UPDATE TO authenticated
  USING (app.puede_escribir_sede(sede_id)) WITH CHECK (app.puede_escribir_sede(sede_id));

CREATE POLICY marcas_lectura ON marcas_revision FOR SELECT TO authenticated
  USING (app.puede_leer_sede(sede_id));
CREATE POLICY marcas_resolucion ON marcas_revision FOR UPDATE TO authenticated
  USING (app.puede_escribir_sede(sede_id)) WITH CHECK (app.puede_escribir_sede(sede_id));

-- ============================================================
-- 8.7 Catalogos: lectura para todos los autenticados, creacion tambien
-- (RN-15, RN-21: los crea el usuario). Sin edicion ni borrado
-- ============================================================
DO $$ DECLARE t text;
BEGIN
  FOR t IN SELECT unnest(ARRAY['ocupaciones','tipos_actividad','medios_difusion',
                               'tipos_organizacion_aliada','tipos_enlace',
                               'tipos_marca_revision','etiquetas']) LOOP
    EXECUTE format('CREATE POLICY %I_lectura ON public.%I FOR SELECT TO authenticated USING (true)', t, t);
    EXECUTE format('CREATE POLICY %I_creacion ON public.%I FOR INSERT TO authenticated
                    WITH CHECK (app.usuario_actual() IS NOT NULL)', t, t);
  END LOOP;
END $$;

-- ============================================================
-- 8.8 usuarios y permisos: solo acceso global los administra
-- ============================================================
CREATE POLICY usuarios_lectura ON usuarios FOR SELECT TO authenticated
  USING (app.es_global() OR auth_user_id = auth.uid());
CREATE POLICY usuarios_admin ON usuarios FOR ALL TO authenticated
  USING (app.es_global()) WITH CHECK (app.es_global());
CREATE POLICY psede_admin ON permisos_sede FOR ALL TO authenticated
  USING (app.es_global()) WITH CHECK (app.es_global());
CREATE POLICY parea_admin ON permisos_area FOR ALL TO authenticated
  USING (app.es_global()) WITH CHECK (app.es_global());
```

### 8.9 Pruebas obligatorias de política

No son revisión visual. Son tests, y cada uno viene de una regla:

| Test | Regla | Debe |
|---|---|---|
| Usuario de Táriba lista personas | RN-30 | No ver ninguna de San Cristóbal |
| Rol anónimo consulta `personas` | `01` §9 | Recibir 0 filas, no un error revelador |
| Encargado de difusión abre contactos-enlace | RN-28 | Ver solo los de su área |
| Usuario con permiso caducado (`hasta` en el pasado) | RN-54 | Perder el acceso |
| Cualquier usuario activo da de alta una persona de otra sede | RN-27 | Poder |
| Ese mismo usuario intenta editarla | RN-27 | No poder |
| Cualquiera intenta `DELETE` sobre `personas` | RN-41 | Fallar |
| Cualquiera intenta `UPDATE` sobre `notas_ficha` | RN-40 | Fallar |
| Director nacional lista personas | RN-29 | Ver todas las sedes |

---

## 9. Vistas derivadas

Implementan D2 de `design.md`: derivar por defecto, congelar solo donde la semántica lo exige.
Cada vista responde a una consulta de `03` §7.

```sql
-- Consulta 1: ficha completa con lo derivado (RN-10, DP-01)
CREATE VIEW v_personas AS
SELECT p.*,
  -- RN-10: interno = PROBACIONISTA/MIEMBRO o cualquier rol vigente. SIEMPRE derivado
  (p.estado_vigente IN ('PROBACIONISTA','MIEMBRO')
   OR EXISTS (SELECT 1 FROM roles_asignados r
              WHERE r.persona_id = p.id AND r.hasta IS NULL)) AS es_interno,
  -- E-06b: eje del informe, distinto del circulo de la actividad
  CASE
    WHEN EXISTS (SELECT 1 FROM roles_asignados r WHERE r.persona_id = p.id
                   AND r.rol = 'FUERZA_VIVA' AND r.hasta IS NULL) THEN 'FUERZA_VIVA'
    WHEN p.estado_vigente = 'MIEMBRO'       THEN 'MIEMBROS'
    WHEN p.estado_vigente = 'PROBACIONISTA' THEN 'PROBACIONISMO'
  END::categoria_oina AS categoria_oina,
  (SELECT count(*) FROM marcas_revision m
    WHERE m.persona_id = p.id AND m.resuelta_en IS NULL) AS marcas_pendientes
FROM personas p;

-- Consulta 2: cumpleaneros de hoy y del mes (RN-35)
CREATE VIEW v_cumpleanos AS
SELECT p.id, p.nombre_completo, p.sede_vigente_id, p.fecha_nacimiento,
       extract(month from p.fecha_nacimiento)::int AS mes,
       extract(day   from p.fecha_nacimiento)::int AS dia,
       (to_char(p.fecha_nacimiento,'MM-DD') = to_char(CURRENT_DATE,'MM-DD')) AS es_hoy
FROM personas p
WHERE p.fecha_nacimiento IS NOT NULL AND NOT p.archivada;

-- Consulta 3: de un evento, cuantos asistieron, internos y externos (RN-17)
CREATE VIEW v_actividades_conteo AS
SELECT a.id AS actividad_id, a.sede_id, a.titulo, a.tema, a.inicio, a.circulo, a.linea, a.estado,
       (a.inicio AT TIME ZONE s.zona_horaria)::date AS fecha_local,   -- RN-55, F8
       count(*) FILTER (WHERE pa.asistio) AS total,
       count(*) FILTER (WHERE pa.asistio AND pa.es_interno_en_la_fecha) AS internos,
       count(*) FILTER (WHERE pa.asistio AND NOT pa.es_interno_en_la_fecha) AS externos,
       a.cupo,
       (a.cupo IS NOT NULL AND count(*) FILTER (WHERE pa.asistio) >= a.cupo) AS cupo_alcanzado
FROM actividades a
JOIN sedes s ON s.id = a.sede_id
LEFT JOIN participaciones pa ON pa.actividad_id = a.id
GROUP BY a.id, s.zona_horaria;

-- Consulta 5: ranking de quien invita y de que medio convierte (bucle A, RN-22)
CREATE VIEW v_ranking_captacion AS
SELECT ac.fecha, ac.medio_id, md.etiqueta AS medio,
       ac.invitado_por_persona_id, pi.nombre_completo AS invitador,
       ac.organizacion_aliada_id, oa.nombre AS organizacion,
       ac.invitado_por_interno,
       count(*) AS personas
FROM atribuciones_captacion ac
JOIN medios_difusion md ON md.id = ac.medio_id
LEFT JOIN personas pi ON pi.id = ac.invitado_por_persona_id
LEFT JOIN organizaciones_aliadas oa ON oa.id = ac.organizacion_aliada_id
WHERE ac.es_primera_captacion
GROUP BY 1,2,3,4,5,6,7,8;

-- Consulta 7: interes vigente = el ULTIMO POR LINEA (RN-52, DP-30)
CREATE VIEW v_interes_vigente AS
SELECT DISTINCT ON (i.persona_id, i.linea)
       i.persona_id, i.linea, i.tipo_actividad_id, i.tema_sugerido,
       i.interes_curso, i.declarado_en
FROM intereses_declarados i
WHERE i.linea IS NOT NULL
ORDER BY i.persona_id, i.linea, i.declarado_en DESC;

-- Consulta 8: bitacora unica — notas, interacciones y cambios de estado
-- en UNA sola linea de tiempo (decision 2026-08-17)
CREATE VIEW v_bitacora_persona AS
SELECT persona_id, 'NOTA' AS clase, escrita_en AS ocurrio_en,
       usuario_id, NULL::text AS canal, NULL::text AS resultado, texto AS detalle
FROM notas_ficha
UNION ALL
SELECT persona_id, 'INTERACCION', ocurrio_en, usuario_id,
       canal::text, resultado::text, nota
FROM interacciones
UNION ALL
SELECT persona_id, 'ESTADO', desde::timestamptz, registrado_por,
       NULL, NULL, estado::text || coalesce(' — ' || disparador, '')
FROM estados_persona
UNION ALL
SELECT persona_id, 'MARCA', creada_en, creada_por, NULL,
       CASE WHEN resuelta_en IS NULL THEN 'PENDIENTE' ELSE 'RESUELTA' END,
       (SELECT etiqueta FROM tipos_marca_revision t WHERE t.id = tipo_id)
FROM marcas_revision WHERE persona_id IS NOT NULL;

-- Consultas 4, 9 y 10: embudo por periodo, en la zona de la sede (RN-55)
CREATE VIEW v_embudo_periodo AS
SELECT p.sede_vigente_id AS sede_id,
       date_trunc('month', e.desde)::date AS periodo,
       e.estado, count(*) AS altas,
       count(*) FILTER (WHERE e.es_automatico) AS altas_automaticas
FROM estados_persona e
JOIN personas p ON p.id = e.persona_id
GROUP BY 1,2,3;

-- Bajas clasificadas por antiguedad de mas o menos de 2 anios (RN-33)
CREATE VIEW v_bajas_antiguedad AS
SELECT p.sede_vigente_id AS sede_id,
       date_trunc('month', e.hasta)::date AS periodo,
       e.estado AS estado_perdido,
       (e.hasta - e.desde) >= 730 AS mas_de_dos_anios,
       count(*) AS bajas
FROM estados_persona e
JOIN personas p ON p.id = e.persona_id
WHERE e.hasta IS NOT NULL
GROUP BY 1,2,3,4;

-- Consulta 11: personas de mi area con su estado (RN-09)
CREATE VIEW v_personas_por_area AS
SELECT r.area_id, a.nombre AS area, p.id AS persona_id, p.nombre_completo,
       p.estado_vigente, r.rol, r.desde
FROM roles_asignados r
JOIN areas a ON a.id = r.area_id
JOIN personas p ON p.id = r.persona_id
WHERE r.hasta IS NULL;

-- Insumo del informe: clases asistidas al corte (DP-05). Vista, no columna
CREATE VIEW v_inscripciones_corte AS
SELECT i.id AS inscripcion_id, i.persona_id, i.grupo_id, i.estado, i.fecha_inscripcion,
       (SELECT count(*) FROM participaciones pa
          JOIN actividades a ON a.id = pa.actividad_id
         WHERE pa.persona_id = i.persona_id AND a.grupo_id = i.grupo_id
           AND pa.asistio) AS clases_asistidas_al_corte
FROM inscripciones i;
```

**Las vistas heredan la RLS de sus tablas base** porque se crean sin `security_invoker = off`. Conviene
declararlo explícitamente en Postgres 15 y posteriores:

```sql
ALTER VIEW v_personas            SET (security_invoker = on);
ALTER VIEW v_cumpleanos          SET (security_invoker = on);
ALTER VIEW v_actividades_conteo  SET (security_invoker = on);
ALTER VIEW v_ranking_captacion   SET (security_invoker = on);
ALTER VIEW v_interes_vigente     SET (security_invoker = on);
ALTER VIEW v_bitacora_persona    SET (security_invoker = on);
ALTER VIEW v_embudo_periodo      SET (security_invoker = on);
ALTER VIEW v_bajas_antiguedad    SET (security_invoker = on);
ALTER VIEW v_personas_por_area   SET (security_invoker = on);
ALTER VIEW v_inscripciones_corte SET (security_invoker = on);
```

Sin esto, una vista se ejecuta con los privilegios de su dueño y **se salta la RLS**. Es la segunda
trampa clásica de Supabase, después de olvidar `ENABLE ROW LEVEL SECURITY` en una tabla.

---

## 10. Migraciones

Diez migraciones, en orden de dependencia. Cada una con su reversión.

| # | Migración | Contenido |
|---|---|---|
| 001 | `extensiones_y_tipos` | Extensiones, esquema `app`, `app.id_nuevo()`, 17 tipos enum |
| 002 | `funciones_normalizacion` | `normaliza_nombre`, `normaliza_telefono`, `normaliza_correo`, `periodo_local` |
| 003 | `organizacion` | `sedes`, `areas`, los 6 catálogos, `organizaciones_aliadas`, `etiquetas` |
| 004 | `personas` | `personas`, `personas_contactos`, `personas_sedes`, `estados_persona`, `roles_asignados`, `historial_identidad_persona` |
| 005 | `actividades` | `cursos`, `grupos`, `actividades`, `actividades_etiquetas`, `inscripciones`, `participaciones`, `atribuciones_captacion` |
| 006 | `seguimiento` | `interacciones`, `notas_ficha`, `intereses_declarados`, `consentimientos_contacto`, `contactos_enlace`, `marcas_revision` |
| 007 | `usuarios_y_permisos` | `usuarios`, `permisos_sede`, `permisos_area`, `periodos_reporte`, y **todas** las claves ajenas diferidas de §5 |
| 008 | `triggers` | Los 14 triggers de §6 |
| 009 | `indices` | Los 38 índices de §7 |
| 010 | `rls` | Revocaciones, `ENABLE`/`FORCE ROW LEVEL SECURITY`, funciones auxiliares y políticas de §8 |
| 011 | `semilla` | Sedes con zona horaria, áreas, catálogos semilla, primer usuario global |

```sql
-- ============================================================
-- Migracion 011: semilla
-- Resuelve el ciclo personas <-> usuarios con la FK diferida de §5
-- ============================================================
BEGIN;
SET CONSTRAINTS fk_personas_registrado_por DEFERRED;

INSERT INTO sedes (codigo, nombre, zona_horaria, es_central) VALUES
  ('SAN_CRISTOBAL','San Cristóbal','America/Caracas', true),
  ('TARIBA',       'Táriba',       'America/Caracas', false),
  ('EJIDO',        'Ejido',        'America/Caracas', false),
  ('MERIDA',       'Mérida',       'America/Caracas', false);

INSERT INTO areas (sede_id, codigo, nombre)
SELECT s.id, a.codigo, a.nombre
FROM sedes s CROSS JOIN (VALUES
  ('RELACIONES_PUBLICAS','Relaciones públicas'), ('DIFUSION','Difusión'),
  ('ESCOLASTICA','Escolástica'),                 ('ECONOMIA','Economía'),
  ('BIBLIOTECA','Biblioteca / librería'),        ('INTEGRACION','Integración'),
  ('TECNICA','Técnica')
) AS a(codigo, nombre);

-- E-11: los 9 valores de la validacion real del xlsx, mas los de las planillas
INSERT INTO medios_difusion (codigo, etiqueta, exige_persona, exige_organizacion, es_semilla) VALUES
  ('INVITADO_POR_PERSONA','Invitado por alguien', true,  false, true),
  ('ALIANZA',             'Vía organización aliada', false, true, true),
  ('INSTAGRAM','Instagram', false,false,true), ('FACEBOOK','Facebook', false,false,true),
  ('LIBRERIA','Librería / sede', false,false,true), ('AFICHE','Afiche', false,false,true),
  ('WHATSAPP','WhatsApp', false,false,true), ('RADIO','Radio', false,false,true),
  ('TV','Televisión', false,false,true), ('YOUTUBE','YouTube', false,false,true),
  ('PAGINA_WEB','Página web', false,false,true), ('PROPAGANDA','Propaganda', false,false,true),
  ('ACTIVIDAD_TERCER_CIRCULO','Actividad de tercer círculo', false,false,true),
  ('VALLA_FACHADA','Vio la sede y entró', false,false,true), ('OTRO','Otro', false,false,true);

-- E-21: los 10 tipos de marca de docs/04
INSERT INTO tipos_marca_revision (codigo, etiqueta, aplica_persona, es_semilla) VALUES
  ('CEDULA_FALTANTE','Cédula faltante', true, true),
  ('APELLIDO_FALTANTE','Apellido faltante', true, true),
  ('TELEFONO_INVALIDO','Teléfono inválido', true, true),
  ('CORREO_INVALIDO','Correo inválido', true, true),
  ('POSIBLE_DUPLICADO','Posible duplicado', true, true),
  ('DATO_SOSPECHOSO','Dato sospechoso', true, true),
  ('MENOR_SIN_REPRESENTANTE','Menor sin representante', true, true),
  ('PERMISO_SIN_ROL_VIGENTE','Permiso sin rol vigente', true, true),
  ('VALOR_FUERA_DE_ENUM','Valor fuera del catálogo', true, true),
  ('REFERENTE_AMBIGUO','Referente ambiguo', true, true);

-- E-07: los 19 valores REALES del xlsx que si son ocupaciones.
-- BIBLIOTECA y ROTARIA quedan FUERA: son procedencia institucional (P19)
INSERT INTO ocupaciones (codigo, etiqueta, es_semilla) VALUES
  ('DOCENTE','Docente',true),         ('ESTUDIANTE','Estudiante',true),
  ('JUBILADA','Jubilada',true),       ('ABOGADO','Abogado',true),
  ('COMERCIANTE','Comerciante',true), ('HOGAR','Hogar',true),
  ('TRABAJADORA','Trabajadora',true), ('CAJERA','Cajera',true),
  ('GANADERO','Ganadero',true),       ('ARQUITECTO','Arquitecto',true),
  ('ASISTENTE','Asistente',true),     ('GASTROENTEROLOGA','Gastroenteróloga',true),
  ('DISENADOR','Diseñador',true),     ('ODONTOLOGO','Odontólogo',true),
  ('INSTRUCTORA','Instructora',true), ('GERENTE','Gerente',true),
  ('PROFESOR_YOGA','Profesor de yoga',true), ('CULTOR','Cultor',true),
  ('OTRO','Otro',true);

-- Primer usuario: la persona existe antes que la cuenta (RN-50, F9).
-- El registrado_por se cierra sobre si mismo gracias a la FK diferida
WITH p AS (
  INSERT INTO personas (nombre, apellido, registrado_por)
  VALUES ('Administrador','Inicial', '00000000-0000-0000-0000-000000000000')
  RETURNING id
)
INSERT INTO usuarios (auth_user_id, persona_id, correo, acceso_global)
SELECT :auth_user_id, p.id, :correo, true FROM p;
-- Ajuste final del ciclo
UPDATE personas SET registrado_por = (SELECT id FROM usuarios LIMIT 1)
WHERE registrado_por = '00000000-0000-0000-0000-000000000000';

COMMIT;
```

```sql
-- ============================================================
-- Reversion completa. Solo valida MIENTRAS NO HAYA DATOS REALES:
-- a partir de la primera actividad registrada, la reversion es hacia atras
-- migracion por migracion, nunca destruyendo
-- ============================================================
BEGIN;
DROP VIEW IF EXISTS v_inscripciones_corte, v_personas_por_area, v_bajas_antiguedad,
  v_embudo_periodo, v_bitacora_persona, v_interes_vigente, v_ranking_captacion,
  v_actividades_conteo, v_cumpleanos, v_personas CASCADE;

DROP TABLE IF EXISTS periodos_reporte, permisos_area, permisos_sede, usuarios,
  marcas_revision, contactos_enlace, consentimientos_contacto, intereses_declarados,
  notas_ficha, interacciones, atribuciones_captacion, participaciones, inscripciones,
  actividades_etiquetas, actividades, grupos, cursos, historial_identidad_persona,
  roles_asignados, estados_persona, personas_sedes, personas_contactos, personas,
  etiquetas, organizaciones_aliadas, tipos_marca_revision, tipos_enlace,
  tipos_organizacion_aliada, medios_difusion, tipos_actividad, ocupaciones,
  areas, sedes CASCADE;

DROP TYPE IF EXISTS origen_marca, estado_periodo_reporte, dia_semana, tipo_contacto_persona,
  estado_actividad, tipo_cedula, nivel_permiso, interes_curso, resultado_contacto,
  canal_interaccion, estado_inscripcion, motivo_fin_vinculo, categoria_oina,
  circulo_actividad, rol_persona, linea_actividad, estado_persona CASCADE;

DROP SCHEMA IF EXISTS app CASCADE;
COMMIT;
```

---

## 11. Notas de optimización

### 11.1 Rendimiento — el volumen real, dicho sin adornos

| Métrica | Hoy (`06` §1) | A 5 años, estimado |
|---|---:|---:|
| Personas | 41 | 3.000 – 8.000 |
| Actividades | 10 | 1.500 |
| Participaciones | ~44 | 40.000 |
| Interacciones | ~36 | 60.000 |
| Estados | — | 20.000 |

**Ninguna tabla llega a un millón de filas en la vida útil previsible del sistema.** Por tanto:

- **Sin particionado.** Particionar `participaciones` por año sería complejidad sin beneficio. Se
  reconsidera si `participaciones` supera el millón de filas, cosa que exigiría ~200 actividades al mes
  durante veinte años.
- **Sin sharding.** El multi-sede es una dimensión lógica, no un eje de reparto. Cuatro sedes con miles de
  personas caben en una instancia pequeña.
- **Sin réplicas de lectura.** Cuatro a diez usuarios concurrentes. Añadir una réplica introduciría retraso
  de replicación en un sistema cuyo requisito duro es el cuadre exacto (RN-31).
- **Sin caché.** La consulta más caliente es la búsqueda de personas, que con el índice GIN de trigramas
  responde en milisegundos sobre miles de filas.

**Dónde sí está el riesgo de rendimiento, y no es el volumen: es la RLS.** Cada `SELECT` evalúa
`app.puede_leer_sede()`. Por eso las funciones auxiliares son `STABLE` —se evalúan una vez por consulta, no
una por fila— y por eso `personas.sede_vigente_id` y `participaciones.sede_id` están denormalizados (F5).
Sin esas dos columnas, listar personas dispararía una subconsulta a `personas_sedes` por fila.

Verificación obligatoria antes de dar por bueno el esquema: `EXPLAIN ANALYZE` de la búsqueda de personas y
del listado de participaciones **con un usuario no global**, no con `service_role`. Con `service_role` la
RLS no se aplica y el plan miente.

### 11.2 Escalabilidad

El eje de crecimiento real no es el volumen de datos: es el **número de sedes** (*"la idea es que usted abra
una filial"*, 30-jul) y el número de módulos (`03` §8). El esquema soporta ambos sin cambios estructurales:

- Sede nueva = una fila en `sedes` y siete en `areas`. Nada más.
- Módulo nuevo (escolástica, economía, biblioteca) = tablas que cuelgan de `personas`, `inscripciones` y
  `grupos`, que quedan estables. `sesiones_clase` colgará de `grupos`; `pagos` de `personas` e
  `inscripciones`; `prestamos` de `personas`.
- Todo importe futuro llevará **moneda y fecha explícitas** (F-6): contexto inflacionario, nunca un número
  suelto.

### 11.3 Integridad de datos

| Mecanismo | Qué garantiza |
|---|---|
| 9 índices únicos parciales | Los invariantes de vigencia y unicidad condicional (F3) |
| 2 constraints `EXCLUDE` | Historial de estados y de sedes sin solapamiento de fechas |
| 31 `CHECK` | Formatos, rangos, coherencia interna de cada fila |
| `ON DELETE RESTRICT` en todas las claves ajenas | Que RN-41 no tenga puerta trasera |
| `REVOKE DELETE` + ausencia de políticas `DELETE` | Que nadie borre, ni por error de aplicación |
| Ausencia de políticas `UPDATE` en `estados_persona`, `notas_ficha`, `historial_identidad_persona` | Append-only real (RN-40) |
| 14 triggers | Lo que el `CHECK` no alcanza: derivaciones congeladas, auditoría, marcas |
| `security_invoker = on` en las 10 vistas | Que las vistas no se salten la RLS |

**Auditoría.** `registrado_por` / `registrado_en` en las 26 tablas de dominio,
`modificado_por` / `modificado_en` en las 12 editables, y bitácora completa de cambios en los 4 campos de
identidad de `personas`. Es la base de la confianza en la base única, que es el bucle raíz del análisis
(`02` §5, bucle B).

**Lo que el esquema deliberadamente NO garantiza**, y hay que decirlo:

- **No hay unicidad de teléfono ni de correo** (F4). Es una decisión, no un olvido: los datos reales tienen
  duplicados legítimos (P06, P08).
- **La identidad de un contacto sin cédula es frágil** (ID-3). Se asume a conciencia.
- **`estado_vigente` y `sede_vigente_id` son denormalizaciones mantenidas por trigger.** Si alguien escribe
  en `estados_persona` o `personas_sedes` saltándose el trigger —por ejemplo con `service_role` y
  `session_replication_role = replica`— quedan desincronizadas. Conviene una consulta de conciliación
  periódica.

---

## 12. Pendientes de verificación

No son decisiones abiertas: son cosas que hay que comprobar en el proyecto real de Supabase antes de dar
por bueno este documento.

| # | Qué verificar | Si falla |
|---|---|---|
| V1 | Versión de PostgreSQL y si `uuidv7()` existe | `app.id_nuevo()` cae a v4 sola. Sin impacto a este volumen |
| V2 | Que `btree_gist` esté disponible | Sin él, los dos `EXCLUDE` se sustituyen por triggers de validación. Peor, pero funciona |
| V3 | Que `unaccent` esté disponible y sea marcable como `IMMUTABLE` en columna generada | Si no, `nombre_busqueda` pasa a mantenerse por trigger |
| V4 | Comportamiento del plan gratuito ante inactividad | Si pausa el proyecto, hay que presupuestar plan pagado: una sede que no entra una semana no puede encontrarse el sistema caído |
| V5 | Región disponible más cercana y latencia real desde Táchira | |
| V6 | Que el registro público esté **desactivado** (F9, RN-50) | Es requisito, no preferencia |
| V7 | Que el medio de pago en dólares sea sostenible por la organización | Condiciona V4 |

## 13. Trazabilidad

| Documento | Qué aporta a este esquema |
|---|---|
| `03` §3.1, §3.2 | Las 23 entidades y sus cardinalidades |
| `03` §4 | ID-1 a ID-9 → índices únicos parciales y detección de duplicados |
| `03` §5 | Máquina de estados → `estados_persona` y el trigger de transición automática |
| `03` §6 | RN-01 a RN-55 → constraints, triggers y políticas RLS |
| `03` §7 | Las 12 consultas → los 38 índices y las 10 vistas |
| `03` §8 | Puntos de extensión → qué queda estable para colgar módulos |
| `04` §1 a §21b | Campos, tipos y obligatoriedad de cada tabla |
| `04` §22 | Los 22 enums → 17 tipos nativos + 6 catálogos (F1) |
| `04` §23 | F-1 a F-11 → funciones de normalización y reglas transversales |
| `05` DP-01 a DP-37 | Cada decisión física referencia su DP |
| `06` | P01 a P25 → los `CHECK`, las funciones de normalización y los tipos de marca |
