# A. Especificación de dominio — Fase 1 (Relaciones Públicas)

**Nueva Acrópolis** · Sede San Cristóbal, con Táriba, Ejido y Mérida · 2026-08-17
**Revisión 2026-08-19**: incorpora las decisiones DP-19 y DP-23 a DP-36 de `05-decisiones-pendientes.md`.
El modelo sigue siendo independiente de framework y de motor, y no contiene DDL. La elección de motor
(DP-19, resuelta) vive en `05`, no aquí.

Trazabilidad: `[CONFIRMADO]` lo afirmó Milagros · `[DATO]` está en el Excel o en la planilla física ·
`[INFERIDO]` se deduce, nadie lo dijo · `[PENDIENTE]` requiere confirmación antes de implementar.
Fuentes citadas como `02-jul`, `10-jul#1`, `10-jul#2`, `18-jul`, `30-jul`, `xlsx`, `planillas`, `OINA`
(planilla del informe internacional, leída en voz alta el 18-jul).

---

## 1. Propósito y alcance

**Propósito.** Sustituir el conjunto de Excel y cuadernos personales por una base única de personas,
actividades y participación, consultable por varias personas a la vez, desde teléfono o computador, con
alcance multi-sede, y capaz de producir los totales que exige el informe a la organización internacional.

Origen del requisito: *"como la escuela ha crecido, se me está haciendo más pesado llevar eso"* (02-jul)
y *"las personas son la base de todo… de ahí parte todo"* (30-jul).

**Dentro del alcance (Fase 1)**

| Capacidad | Ancla |
|---|---|
| Registro de personas con estado y roles | `[CONFIRMADO]` 10-jul#2, 30-jul |
| Actividades con tipo, tema, fecha, sede y etiquetas | `[CONFIRMADO]` 18-jul |
| Participación / asistencia a actividades | `[CONFIRMADO]` 18-jul |
| Atribución de captación (medio + quién invitó) | `[CONFIRMADO]` 02-jul, 10-jul#1, 30-jul |
| Seguimiento de leads con bitácora de interacciones | `[CONFIRMADO]` 30-jul |
| Multi-sede con permisos por sede y área | `[CONFIRMADO]` 18-jul, 30-jul |
| Auditoría de quién registra y cuándo | `[CONFIRMADO]` 18-jul, 30-jul |
| Cumpleaños del día y del mes | `[CONFIRMADO]` 02-jul, 18-jul |
| Totales y exportación hacia el informe OINA | `[CONFIRMADO]` 18-jul |
| Inscripción a curso y grupo (día/hora/profesor) | `[CONFIRMADO]` 10-jul#2 |

**Fuera del alcance, solo como puntos de extensión** (§8): escolástica (asistencia por clase y notas),
economía y pagos, biblioteca (inventario y préstamos), café, inventario de sede, automatización de
mensajería masiva.
Diferido por Milagros: *"claro, pero por fases… el dolor que debemos apaciguar ahorita es este"* (30-jul).

**No objetivos.** No se modela contabilidad. No se publica ningún listado de personas ni su nivel de
vínculo (`01-contexto` §9). No se diseña la mensajería automática, aunque el núcleo debe permitirla.
**Fase 1 sustituye el Excel, no la planilla de papel**: al no existir autorregistro (DP-23), en un evento
grande alguien teclea en vivo o se transcribe después. El OCR sigue siendo punto de extensión (§8).

---

## 2. Glosario del vocabulario interno

El sistema habla el vocabulario de la sede, no el de las fuentes públicas. Donde `01-contexto` dice
"socio", "alumno" o "egresado", la sede dice otra cosa; gana la sede `[CONFIRMADO por contraste]`.

| Término | Definición según la sede | Fuente | Confianza |
|---|---|---|---|
| **Escuela** | La sede local y su actividad; *"toda la gente que viene a la escuela"* | 02-jul | `[CONFIRMADO]` |
| **Acropolitano** | Persona interna de la escuela; se cuenta aparte de los externos en cada actividad | 10-jul#1 | `[CONFIRMADO]` |
| **Interno / externo** | Interno = **inscrito en filosofía**. Respuesta literal a *"¿se considera alguien interno cuando pasó el segundo módulo?"* → *"No, cuando está inscrito en filosofía"* | 18-jul | `[CONFIRMADO]` |
| **Probacionismo** | El curso introductorio de filosofía y su etapa; incluye las charlas inaugurales asociadas | 10-jul#2, 18-jul | `[CONFIRMADO]` |
| **Probacionista** | Persona inscrita en el curso de filosofía | 30-jul | `[CONFIRMADO]` |
| **Miembro** | Quien terminó el probacionismo; hay **acto de graduación**; la membresía permite asistir a clases en otro país | 18-jul | `[CONFIRMADO]` |
| **Círculos** | Tres niveles de proximidad: 3.º **cultura**, 2.º **filosofía**, 1.º **voluntariado** (centro). *"la filosofía se vuelve acción concreta"*. Es el eje de la **actividad** | 18-jul | `[CONFIRMADO]` |
| **Categoría OINA** | Eje **distinto** del anterior, propio del informe internacional: 1 miembros, 2 probacionismo, 3 fuerza viva. Se **deriva** del estado y de los roles de la persona | 18-jul | `[CONFIRMADO]` — DP-01 resuelta 2026-08-17: son dos ejes, no dos numeraciones del mismo |
| **Fuerza viva** (grado) | Grado interno que exige un curso adicional de instructores; *"se involucra más en la escuela"*. En Táriba no existe todavía | 10-jul#2, 18-jul | `[CONFIRMADO]` |
| **Fuerzas vivas** (de la ciudad) | Instituciones externas con las que se teje alianza: protección civil, bomberos, empresas. **Homónimo del anterior, concepto distinto** | 02-jul | `[CONFIRMADO]` |
| **Celador / celaduría** | Rol de voluntariado asociado a un curso; *"es un compromiso mayor al de una persona de clase normal"*; podría cargar asistencias | 18-jul | `[CONFIRMADO]` |
| **Consejo** | La reunión de un área: *"las reuniones de las áreas se llama consejo"*. El informe OINA cuenta "reuniones de consejo" | 18-jul, OINA | `[CONFIRMADO]` |
| **Área** | Unidad funcional de la sede: relaciones públicas, difusión, escolástica, economía, biblioteca/librería, integración, técnica | 30-jul | `[CONFIRMADO]` |
| **Encargado de área** | Responsable de un área. En 02-jul se le llamó "consejero"; el término vigente es el de 30-jul | 30-jul | `[CONFIRMADO]` (cambio de criterio) |
| **Colaborador** | Quien sostiene la operación; **no es un estado del embudo sino una subcategoría** con área: *"mi estatus es probacionista, pero dentro de mí podría ver que está colaborando en tal área"* | 30-jul | `[CONFIRMADO]` |
| **Instructor / jefe instructor** | Quien dicta clases. El informe pide total de instructores activos y cursos de instructores | 30-jul, OINA | `[CONFIRMADO]` |
| **Amigo de la escuela** | Quien pasó por la escuela y ya no está inscrito, a quien se sigue invitando; existen grupos de WhatsApp con ese nombre. **No es un estado propio**: es el `INACTIVO` al que se sigue invitando (DP-07 resuelta) | 10-jul#2, 30-jul | `[CONFIRMADO]` |
| **Filial** | Sede de otro lugar o país. El informe pide *"altas traslado de filiales"*: una persona puede trasladarse a una filial de otro país | 18-jul, OINA | `[CONFIRMADO]` |
| **Alta / baja** | Ingreso y salida registrados en el periodo del informe. Las bajas se clasifican por antigüedad **más / menos de 2 años** | 18-jul, OINA | `[CONFIRMADO]` |
| **Escolástica** | Área que lleva la asistencia y el control académico del curso; hoy en otro Excel | 18-jul | `[CONFIRMADO]` |
| **Difusión** | Área de propaganda, redes y anuncios; su encargado es Carlos | 30-jul | `[CONFIRMADO]` |
| **Planilla** | Formulario, en papel o en Excel. *"La planilla grande"* = la que se envía a la internacional | 18-jul | `[CONFIRMADO]` |
| **Ficha** | El registro consolidado de una persona; *"que eso sea tu ficha, tu cédula"* | 18-jul | `[CONFIRMADO]` |
| **Actividad de tercer círculo** | Canal de captación reconocido por el informe OINA; por ahí ingresó el entrevistador (charla de estoicismo) | 18-jul, OINA | `[CONFIRMADO]` |
| **FILOART** | Evento de proyección cultural asociado al día internacional de la filosofía. Transcrito como "filoar" (18-jul) y "Piloat" (02-jul); el nombre correcto es **FILOART** | 02-jul, 18-jul | `[CONFIRMADO]` 2026-08-17 |
| **"FV"** | En *"solamente FB es Claudia y Jesús"* (18-jul): error de transcripción de **FV = fuerza viva**. Claudia y Jesús son las dos fuerzas vivas de San Cristóbal | 18-jul | `[CONFIRMADO]` 2026-08-17 |

---

## 3. Modelo conceptual

### 3.1 Entidades del núcleo

| Entidad | Razón de existir | Fuente | Confianza |
|---|---|---|---|
| **PERSONA** | Ficha única, buscable por nombre y cédula; *"si yo busco Javier Bastidas… número de teléfono, cédula"* | 02-jul, 18-jul | `[CONFIRMADO]` |
| **SEDE** | Táriba, San Cristóbal, Mérida, Ejido, y las que se abran; *"la sucursal es una pregunta en el formulario"* | 18-jul, 30-jul | `[CONFIRMADO]` |
| **PERSONA_SEDE** | Pertenencia con fecha, porque existe el traslado entre filiales. **Un solo vínculo activo**; el acceso a varias sedes es permiso de usuario, no doble pertenencia | 18-jul/OINA | `[CONFIRMADO]` DP-03 resuelta |
| **ESTADO_PERSONA_HIST** | Historial de estatus con fecha; *"que haya su registro de cuándo empezó"*, *"último estatus dentro de la escuela"* | 18-jul, 30-jul | `[CONFIRMADO]` |
| **ROL_ASIGNADO** | Roles acumulables sobre el estatus, ligados a un área | 10-jul#2, 30-jul | `[CONFIRMADO]` |
| **AREA** | Agrupa roles, contactos-enlace y permisos de lectura | 30-jul | `[CONFIRMADO]` |
| **ACTIVIDAD** | Instancia con fecha, tema, sede y línea; *"tiene que tener fecha"* porque *"esto se hace en varios meses"* | 18-jul | `[CONFIRMADO]` |
| **ETIQUETA** / **ACTIVIDAD_ETIQUETA** | *"me suena la idea de etiquetas más que clasificarlos… pueden tener varias cosas a la vez"*; creables por el usuario | 18-jul | `[CONFIRMADO]` |
| **CURSO** | El catálogo (filosofía introductorio, avanzados, curso de instructores) | 10-jul#2, 18-jul | `[CONFIRMADO]` |
| **GRUPO** | Edición del curso identificada por **día + hora + profesor**: *"día, hora de la clase para distinguir como los grupos, el profesor, el encargado del curso"* | 10-jul#2 | `[CONFIRMADO]` |
| **INSCRIPCION** | Persona↔grupo con estado propio y fechas | 10-jul#2, 18-jul | `[CONFIRMADO]` |
| **PARTICIPACION** | Persona↔actividad; base de *"¿cuántos asistieron? ¿cuántos de la escuela, cuántos externos?"* | 18-jul | `[CONFIRMADO]` |
| **ATRIBUCION_CAPTACION** | Cómo llegó: medio + invitado por persona + vía organización aliada | 02-jul, 10-jul#1, 30-jul, xlsx | `[CONFIRMADO]` |
| **ORGANIZACION_ALIADA** | 14 de 44 filas del Excel (12 personas) llegaron por Rotary, Spinning Bike o Biblioteca Táriba, registradas en la columna de "invitado por" como si fueran personas | xlsx, 02-jul | `[CONFIRMADO]` DP-04 resuelta: deben poder identificarse |
| **CONTACTO_ENLACE** | Medios, músicos, filoartistas, danza, teatro, gobierno: *"eso es otra categoría… tiene más importancia"*. **Es la misma `PERSONA`** con una marca de enlace y área custodia; la restricción es de permisos, no de estructura | 02-jul, 30-jul | `[CONFIRMADO]` DP-08 resuelta |
| **INTERACCION** | Bitácora de seguimiento: *"entras a la ficha de Javier y hoy le escribí"* | 02-jul, 30-jul, xlsx | `[CONFIRMADO]` |
| **NOTA_FICHA** | **Chatter de la ficha**: anotación libre con fecha y autor, sin canal ni resultado — *"último seguimiento"*, *"esta persona me bloqueó pero está interesada"*. Append-only | Decisión 2026-08-17 | `[CONFIRMADO]` |
| **INTERES_DECLARADO** | *"¿está interesado en asistir nuevamente y cuál?"*; *"hay gente que solo le interesa el voluntariado"* | 10-jul#1, 30-jul | `[CONFIRMADO]` |
| **PERSONA_CONTACTO** | Teléfonos y redes como filas, no como columnas: la búsqueda (RN-39) y el deduplicado (ID-6) necesitan un solo índice sobre el valor normalizado | DP-33 | `[DECISION-EQUIPO]` 2026-08-19 |
| **MARCA_REVISION** | Guardar nunca se bloquea; lo que falta o es dudoso genera una marca resoluble. Unifica las banderas que `06` había inventado solo para la importación | DP-36 | `[DECISION-EQUIPO]` 2026-08-19 |
| **CONSENTIMIENTO_CONTACTO** | *"¿Te gustaría recibir más información de nuestras actividades? SI / NO"* — solo aparece en la planilla. **Informativo: no bloquea envíos** | planillas | `[CONFIRMADO]` DP-09 resuelta |
| **USUARIO** + **PERMISO_SEDE** / **PERMISO_AREA** | Escritura casi abierta, lectura restringida por sede y área; el director nacional y la secretaria privada ven todo | 18-jul, 30-jul | `[CONFIRMADO]` |
| **PERIODO_REPORTE** | El informe se llena mensual y se reporta semestral, y debe cuadrar con el detalle. Los totales se **congelan al cerrar** el periodo | 18-jul | `[CONFIRMADO]` DP-10 resuelta |

**Derivados, no entidades**: cumpleañeros (vista sobre fecha de nacimiento), interno/externo (derivado del
estado), ranking de invitadores (agregado sobre `ATRIBUCION_CAPTACION`), conversión por charla.

### 3.2 Relaciones y cardinalidades

| Relación | Cardinalidad | Nota |
|---|---|---|
| PERSONA — PERSONA_SEDE — SEDE | 1:N / N:1 | Vínculos sucesivos en el tiempo, **uno solo activo** (DP-03). Que Milagros trabaje con San Cristóbal y Táriba se resuelve en `PERMISO_SEDE`, no aquí |
| PERSONA — ESTADO_PERSONA_HIST | 1:N | Append-only; el estado vigente es el registro sin fecha de fin |
| PERSONA — ROL_ASIGNADO — AREA | 1:N / N:1 | Varios roles simultáneos: *"estoy haciendo el curso de instructores, estoy encargada del área"* (10-jul#2) |
| PERSONA — PARTICIPACION — ACTIVIDAD | 1:N / N:1 | Una persona asiste a muchas actividades; el 02-jul pide justamente *"cada persona con las distintas actividades en la que ha participado"* |
| ACTIVIDAD — SEDE | N:1 | La actividad ocurre en una sede; el Excel lo codifica en el nombre de la hoja (P22) |
| ACTIVIDAD — GRUPO | N:1 **opcional** | Una clase suelta **es una actividad que además pertenece al curso** (DP-06 resuelta). Permite que alguien asista sin estar inscrito y que esa asistencia cuente para el corte del informe |
| ACTIVIDAD — ACTIVIDAD_ETIQUETA — ETIQUETA | 1:N / N:1 | N:M por diseño: *"día de la tierra más algo de arte"* |
| CURSO — GRUPO | 1:N | |
| GRUPO — PERSONA (profesor) | N:1 | *"el profesor, el encargado del curso"* (10-jul#2) |
| GRUPO — INSCRIPCION — PERSONA | 1:N / N:1 | Una persona puede inscribirse en varios cursos: *"si están haciendo otros cursos adicionales"* (10-jul#2) |
| PERSONA — ATRIBUCION_CAPTACION | 1:N | Se captura por evento, no una sola vez: el Excel registra el medio en cada fila de asistencia |
| ATRIBUCION_CAPTACION — PERSONA (invitado_por) | N:1 opcional | Autorreferencia; *"ese invitado por tiene que ser un selector de las personas"* (30-jul) |
| ATRIBUCION_CAPTACION — ORGANIZACION_ALIADA | N:1 opcional | Confirmado (DP-04): la alianza se identifica aparte de la persona que invita |
| PERSONA — INTERACCION — USUARIO | 1:N / N:1 | Quién contactó, cuándo, por qué canal, con qué resultado |
| PERSONA — NOTA_FICHA — USUARIO | 1:N / N:1 | Anotaciones libres. La vista de bitácora **une** notas, interacciones y cambios de estado en una sola línea de tiempo |
| PERSONA — INTERES_DECLARADO | 1:N | Por línea y por tema |
| PERSONA — PERSONA_CONTACTO | 1:N | Teléfonos y redes. Un solo `es_principal` por tipo (DP-33) |
| PERSONA — MARCA_REVISION | 1:N | También cuelgan de `ACTIVIDAD` y de `PARTICIPACION`; se resuelven, no se borran (DP-36) |
| PERSONA — USUARIO | 1:0..1 | Solo algunas personas operan el sistema |
| USUARIO — PERMISO_SEDE / PERMISO_AREA | 1:N | *"cada usuario tendría su grupo de permisos"* (30-jul) |

### 3.3 Diagrama ER conceptual

```mermaid
erDiagram
  PERSONA ||--o{ PERSONA_SEDE : "pertenece a"
  SEDE ||--o{ PERSONA_SEDE : "agrupa"
  PERSONA ||--o{ ESTADO_PERSONA_HIST : "tiene historial de"
  PERSONA ||--o{ ROL_ASIGNADO : "desempena"
  AREA ||--o{ ROL_ASIGNADO : "define"
  PERSONA ||--o{ PARTICIPACION : "asiste"
  ACTIVIDAD ||--o{ PARTICIPACION : "recibe"
  SEDE ||--o{ ACTIVIDAD : "realiza"
  GRUPO ||--o{ ACTIVIDAD : "genera clases sueltas"
  ACTIVIDAD ||--o{ ACTIVIDAD_ETIQUETA : "clasificada por"
  ETIQUETA ||--o{ ACTIVIDAD_ETIQUETA : "aplica a"
  CURSO ||--o{ GRUPO : "se dicta como"
  SEDE ||--o{ GRUPO : "aloja"
  PERSONA ||--o{ GRUPO : "dicta como profesor"
  GRUPO ||--o{ INSCRIPCION : "matricula"
  PERSONA ||--o{ INSCRIPCION : "se inscribe"
  PERSONA ||--o{ ATRIBUCION_CAPTACION : "llega mediante"
  PERSONA ||--o{ ATRIBUCION_CAPTACION : "invita como referente"
  ORGANIZACION_ALIADA ||--o{ ATRIBUCION_CAPTACION : "canaliza"
  ACTIVIDAD ||--o{ ATRIBUCION_CAPTACION : "contextualiza"
  PERSONA ||--o{ INTERACCION : "recibe seguimiento"
  USUARIO ||--o{ INTERACCION : "registra"
  PERSONA ||--o{ NOTA_FICHA : "acumula notas"
  USUARIO ||--o{ NOTA_FICHA : "escribe"
  PERSONA ||--o{ INTERES_DECLARADO : "declara"
  PERSONA ||--o{ PERSONA_CONTACTO : "tiene telefonos y redes"
  PERSONA ||--o{ MARCA_REVISION : "acumula pendientes"
  PERSONA ||--o{ CONSENTIMIENTO_CONTACTO : "otorga"
  PERSONA ||--o| USUARIO : "opera como"
  USUARIO ||--o{ PERMISO_SEDE : "limitado a"
  SEDE ||--o{ PERMISO_SEDE : "expone"
  USUARIO ||--o{ PERMISO_AREA : "limitado a"
  AREA ||--o{ PERMISO_AREA : "expone"
  AREA ||--o{ CONTACTO_ENLACE : "custodia"
  PERSONA ||--o| CONTACTO_ENLACE : "figura como"

  PERSONA {
    id id PK
    string cedula_tipo "V o E"
    string cedula "unico cuando existe"
    string nombre "obligatorio"
    string apellido "opcional DP-31"
    date fecha_nacimiento
    string ocupacion
    string representante_nombre "si es menor de edad"
    string representante_telefono
    boolean contacto_bloqueado "marca informativa"
    boolean archivada "nunca se borra"
    string estado_vigente "derivado del historial"
    string categoria_oina "derivado MIEMBROS PROBACIONISMO FUERZA_VIVA"
    id registrado_por FK
    datetime registrado_en
    id modificado_por FK "ultimo que edito DP-25"
    datetime modificado_en
  }
  PERSONA_CONTACTO {
    id id PK
    id persona_id FK
    string tipo "TELEFONO TELEFONO_INTL CORREO INSTAGRAM FACEBOOK OTRA_RED"
    string valor
    string valor_normalizado "indexado para busqueda y dedup"
    boolean es_principal
  }
  MARCA_REVISION {
    id id PK
    id persona_id FK "o actividad_id o participacion_id"
    string tipo "CEDULA_FALTANTE TELEFONO_INVALIDO POSIBLE_DUPLICADO ..."
    string detalle
    datetime creada_en
    datetime resuelta_en "null = pendiente"
    id resuelta_por FK
  }
  SEDE {
    id id PK
    string codigo "SAN_CRISTOBAL TARIBA EJIDO MERIDA"
    string nombre
    boolean es_central
    string zona_horaria "corte de periodo en hora local DP-25b"
  }
  PERSONA_SEDE {
    id id PK
    id persona_id FK
    id sede_id FK
    date desde
    date hasta "null = vigente"
    string motivo_fin "traslado de filial"
  }
  ESTADO_PERSONA_HIST {
    id id PK
    id persona_id FK
    string estado "CONTACTO ASISTENTE PROBACIONISTA MIEMBRO INACTIVO"
    date desde
    date hasta
    string disparador
    id registrado_por FK
  }
  ROL_ASIGNADO {
    id id PK
    id persona_id FK
    id area_id FK "opcional"
    string rol "COLABORADOR ENCARGADO_AREA INSTRUCTOR CELADOR FUERZA_VIVA"
    date desde
    date hasta
  }
  AREA {
    id id PK
    string codigo
    string nombre
  }
  ACTIVIDAD {
    id id PK
    id sede_id FK
    id grupo_id FK "opcional: clase de un curso"
    string tipo
    string linea "FILOSOFIA CULTURA VOLUNTARIADO"
    string titulo "titulo de convocatoria"
    string tema "tema canonico"
    datetime inicio
    string circulo_actividad "3 CULTURA 2 FILOSOFIA 1 VOLUNTARIADO"
    string estado "PLANIFICADA REALIZADA CANCELADA DP-26"
    boolean es_gratuita
  }
  ETIQUETA {
    id id PK
    string nombre "creable por el usuario"
  }
  ACTIVIDAD_ETIQUETA {
    id actividad_id FK
    id etiqueta_id FK
  }
  PARTICIPACION {
    id id PK
    id persona_id FK
    id actividad_id FK
    boolean asistio
    boolean es_interno "derivado del estado a la fecha"
    id registrado_por FK
    datetime registrado_en
  }
  CURSO {
    id id PK
    string nombre
    string nivel
    id curso_prerequisito_id FK
  }
  GRUPO {
    id id PK
    id curso_id FK
    id sede_id FK
    id profesor_persona_id FK
    string dia_semana
    time hora
    date fecha_inicio
  }
  INSCRIPCION {
    id id PK
    id persona_id FK
    id grupo_id FK
    string estado "INSCRITO NO_INSCRITO RETIRADO"
    date fecha_inscripcion
    date fecha_retiro
    integer clases_asistidas_al_corte
  }
  ATRIBUCION_CAPTACION {
    id id PK
    id persona_id FK
    id actividad_id FK "opcional"
    string medio_difusion
    id invitado_por_persona_id FK "opcional"
    id organizacion_aliada_id FK "opcional"
    date fecha
  }
  ORGANIZACION_ALIADA {
    id id PK
    string nombre "ROTARY SPINNING BIKE BIBLIOTECA TARIBA"
    string tipo "CLUB_SERVICIO COMERCIO BIBLIOTECA MEDIO"
  }
  CONTACTO_ENLACE {
    id id PK
    id persona_id FK
    id area_custodia_id FK
    string tipo_enlace "MEDIO MUSICO FILOARTISTA INSTITUCION"
    string organizacion
  }
  NOTA_FICHA {
    id id PK
    id persona_id FK
    id usuario_id FK
    datetime escrita_en
    string texto "append-only"
  }
  INTERACCION {
    id id PK
    id persona_id FK
    id usuario_id FK
    string canal "LLAMADA WHATSAPP REDES CORREO VISITA"
    datetime ocurrio_en
    string resultado
    string nota
  }
  INTERES_DECLARADO {
    id id PK
    id persona_id FK
    string linea
    string tipo_actividad
    string tema_sugerido
    string interes_curso "SI NO SIN_DATO"
  }
  CONSENTIMIENTO_CONTACTO {
    id id PK
    id persona_id FK
    boolean acepta
    date fecha
    string origen "planilla evento"
  }
  USUARIO {
    id id PK
    id persona_id FK "todo usuario es persona de la escuela"
    string correo "unico"
    string hash_contrasena
    string google_sub "atajo opcional DP-28"
    boolean acceso_global
    boolean activo
  }
  PERMISO_SEDE {
    id usuario_id FK
    id sede_id FK
    string nivel "LECTURA ESCRITURA"
  }
  PERMISO_AREA {
    id usuario_id FK
    id area_id FK
    string nivel
  }
```

`%%` Módulos de extensión (pago, préstamo de libro, sesión de clase, inventario) deliberadamente ausentes:
se enganchan a `PERSONA`, `ACTIVIDAD`, `GRUPO` e `INSCRIPCION` según §8.

---

## 4. Identidad y deduplicación

**Problema real, no hipotético.** El Excel tiene 44 filas con nombre y **41 personas**: tres personas están
duplicadas entre hojas con cédula y teléfono idénticos, porque asistieron a un evento que aparece en las
dos hojas (P04). Y el nombre no sirve como clave: *"el nombre podría repetirse o alguien escribe diferente
el nombre, pero la cédula sí es como su ID"* (18-jul).

| Regla | Contenido | Confianza |
|---|---|---|
| **ID-1** | La **cédula** es el identificador natural de la persona. Única en todo el sistema, no por sede | `[CONFIRMADO]` 18-jul |
| **ID-2** | La cédula es **obligatoria desde el estado `ASISTENTE`** en adelante. En `CONTACTO` no se pide | `[CONFIRMADO]` 30-jul — cambio de criterio respecto a 18-jul |
| **ID-3** | Un `CONTACTO` sin cédula se identifica por **teléfono normalizado + nombre**, y ambos deben servir para buscarlo después. Clave débil asumida a conciencia. El valor normalizado vive en `PERSONA_CONTACTO`, no en una columna de `PERSONA` | `[CONFIRMADO]` DP-02 · precisado por DP-33 (2026-08-19) |
| **ID-4** | El teléfono **no** puede ser clave única: hay dos casos reales de teléfono compartido entre personas distintas (madre/hija, hermanas) | `[DATO]` xlsx |
| **ID-5** | El correo **no** puede ser clave única: un correo aparece en dos personas distintas | `[DATO]` xlsx |
| **ID-6** | Candidato a duplicado = misma cédula, **o** teléfono normalizado igual + similitud alta de nombre. Se propone, no se fusiona en silencio | `[INFERIDO]` de P04/P08 |
| **ID-7** | La fusión conserva el historial de estados, las participaciones y las interacciones de ambas fichas, y deja rastro de la fusión | `[INFERIDO]` de *"que haya su registro de cuándo empezó"* (18-jul) |
| **ID-8** | Al convertir un `CONTACTO` sin cédula en `ASISTENTE` con cédula, se **enriquece la misma ficha**: *"no le va a pedir otra vez todos los datos"* | `[CONFIRMADO]` 30-jul |
| **ID-9** | Un referido **nace como `PERSONA` en estado `CONTACTO`** desde el momento en que alguien lo sugiere, con `ATRIBUCION_CAPTACION` apuntando a quien lo refirió. No existe entidad intermedia ni paso de conversión | `[DECISION-EQUIPO]` DP-32 (2026-08-19), sobre planillas + *"cuántos invitó Alejandro"* (30-jul) |

---

## 5. Máquina de estados de la persona

Un solo estado vigente por persona; los roles son ortogonales al estado (§6, RN-08).

```mermaid
stateDiagram-v2
  [*] --> CONTACTO : alta con solo telefono (manual)
  [*] --> ASISTENTE : alta en puerta o evento con cedula (manual)
  CONTACTO --> ASISTENTE : primera participacion registrada (automatica)
  ASISTENTE --> PROBACIONISTA : inscripcion al curso de filosofia (manual)
  PROBACIONISTA --> MIEMBRO : acto de graduacion (manual)
  ASISTENTE --> INACTIVO : sin actividad / no continuo (manual)
  PROBACIONISTA --> INACTIVO : retiro (manual)
  MIEMBRO --> INACTIVO : baja (manual)
  INACTIVO --> ASISTENTE : reingreso (manual)
  INACTIVO --> PROBACIONISTA : reingreso con inscripcion (manual)
```

| Estado | Definición | Datos mínimos | Fuente |
|---|---|---|---|
| **CONTACTO** | Pidió información o dejó datos, no ha venido. *"solamente tenemos el número de teléfono porque no ha venido"* | Teléfono. **Sin cédula ni fecha de nacimiento** | `[CONFIRMADO]` 30-jul |
| **ASISTENTE** | Vino a algo — evento, arteterapia, charla o clase suelta — sin inscribirse. *"si vino a la escuela e hizo parte de algo, hizo contacto"* | **Obligatorio: nombre + teléfono.** Apellido, cédula, fecha de nacimiento y ocupación se piden pero no bloquean; su ausencia genera `MARCA_REVISION` | `[CONFIRMADO]` 30-jul, 10-jul#1 · datos mínimos por DP-24/DP-31 `[POR-VALIDAR]` |
| **PROBACIONISTA** | Inscrito en el curso de filosofía. Es la frontera de "interno" | Ficha completa de inscripción | `[CONFIRMADO]` 30-jul, 18-jul |
| **MIEMBRO** | Terminó el probacionismo; hay acto de graduación; membresía internacional | Igual, más fecha de graduación | `[CONFIRMADO]` 18-jul |
| **INACTIVO** | Se salió. Se le sigue invitando *"hasta que no nos bloquees"*. Conserva **último estatus alcanzado** y hasta qué tema llegó | Marca de último estatus y punto de salida | `[CONFIRMADO]` 30-jul |

| Transición | Disparador | Modo | Confianza |
|---|---|---|---|
| → CONTACTO | Alta manual desde WhatsApp, Instagram o mención | Manual | `[CONFIRMADO]` 30-jul |
| → ASISTENTE (directo) | Registro en puerta por seguridad o en planilla de evento | Manual | `[CONFIRMADO]` 10-jul#1 |
| CONTACTO → ASISTENTE | Se registra su primera participación en una actividad | **Automática** | `[INFERIDO]` de *"si vino a la escuela e hizo parte de algo"* (30-jul) |
| ASISTENTE → PROBACIONISTA | **La inscripción la hace una persona de la escuela cuando el interesado decide**. No hay automatismo por número de clases: las menciones de 3 (OINA) y 4 clases (18-jul) son un **corte de reporte**, no un disparador | Manual, con botón que despliega los campos de curso (18-jul) | `[CONFIRMADO]` DP-05 resuelta 2026-08-17 |
| PROBACIONISTA → MIEMBRO | Acto de graduación. *"solamente un estatus dentro de la misma ficha"* | Manual | `[CONFIRMADO]` 18-jul, 30-jul |
| cualquiera → INACTIVO | Deja de asistir; *"debe haber una forma en el sistema de quitarlos"* | Manual | `[CONFIRMADO]` 18-jul, 30-jul |
| INACTIVO → activo | Reingreso: *"ay, yo quiero volver… pero no me acuerdo dónde iba esa persona"* | Manual | `[CONFIRMADO]` 30-jul |
| **No existe estado `BLOQUEADO`** | *"hasta que no nos bloquees"* — el bloqueo se registra como **marca informativa** en la ficha (con fecha) y como nota, no como estado del embudo. Tampoco existe baja definitiva: **no se borra a nadie** | Manual | `[CONFIRMADO]` 2026-08-17 |

**Historial.** `ESTADO_PERSONA_HIST` es append-only con `desde`/`hasta`. Es el insumo directo de las
**altas y bajas** del informe OINA, incluida la clasificación de bajas por antigüedad de más o menos de
2 años (18-jul).

**No modelados como estado**: `NO_INSCRITO` y `AMIGO_DE_LA_ESCUELA`. El 10-jul#2 los enumera como
destinos distintos (*"quedan como no inscritos, quedan como amigos de la escuela"*), el 30-jul los trata
casi como `INACTIVO` — y así queda: **un solo estado `INACTIVO`**, con el atributo de si sigue en la lista
de invitación. `[CONFIRMADO]` DP-07 resuelta 2026-08-17.

---

## 6. Reglas de negocio

Numeradas, con fuente y confianza. Las `[PENDIENTE]` aparecen además en el documento C.

### Identidad y captura

| # | Regla | Fuente | Confianza |
|---|---|---|---|
| RN-01 | Toda persona tiene exactamente un estado vigente y un historial de estados con fecha | 18-jul, 30-jul | `[CONFIRMADO]` |
| RN-02 | En `CONTACTO` está **prohibido exigir** la cédula. Desde `ASISTENTE` **se pide y se avisa si falta, pero no bloquea**; es **obligatoria solo en la inscripción a curso**. La falta genera `MARCA_REVISION` | 30-jul; **modificada** por DP-24 (2026-08-19) | `[POR-VALIDAR]` — suaviza un `[CONFIRMADO]` del 30-jul |
| RN-03 | El alta mínima de una persona es **nombre + teléfono**; es la que hace seguridad en la puerta. El apellido se pide y no bloquea — `MELANY VALENTINA` no tiene apellido distinguible (P16) | 10-jul#1; precisada por DP-31 (2026-08-19) | `[CONFIRMADO]` + `[DECISION-EQUIPO]` |
| RN-04 | El formulario es progresivo: una planilla básica sirve para cualquier actividad, y al inscribirse a curso se despliegan los campos adicionales sin volver a pedir lo ya capturado | 18-jul | `[CONFIRMADO]` |
| RN-05 | Nunca se vuelve a pedir un dato que ya está en la ficha: *"si tú le pides es porque algo literal faltó, pero no volver a pedirle lo mismo"* | 30-jul | `[CONFIRMADO]` |
| RN-06 | Todo registro guarda **quién lo registró** y la fecha y hora; y debe poder contarse cuántas personas registró cada quien | 18-jul, 30-jul | `[CONFIRMADO]` |
| RN-07 | Toda persona pertenece a una sede; quien tiene acceso a varias debe elegirla al registrar | 18-jul | `[CONFIRMADO]` |

### Estados, roles y áreas

| # | Regla | Fuente | Confianza |
|---|---|---|---|
| RN-08 | Los roles son acumulables y ortogonales al estado: un probacionista puede ser colaborador de un área | 10-jul#2, 30-jul | `[CONFIRMADO]` |
| RN-09 | El rol se asigna a un área, y el encargado del área puede listar a los suyos con su estado: *"tengo cuatro miembros y dos probacionistas"* | 30-jul | `[CONFIRMADO]` |
| RN-10 | **Interno** = persona inscrita en filosofía **o más allá**: estado `PROBACIONISTA` / `MIEMBRO`, o cualquier **rol vigente** (instructor, fuerza viva, encargado de área, celador, colaborador). Externo = todo lo demás. **Siempre derivado**, nunca capturado a mano | 18-jul; precisado 2026-08-17 | `[CONFIRMADO]` |
| RN-11 | `INACTIVO` conserva el último estatus alcanzado y hasta qué punto llegó del curso | 30-jul | `[CONFIRMADO]` |
| RN-12 | Una persona inactiva sigue siendo destinataria de invitaciones. El consentimiento registrado es **informativo**: no bloquea envíos | 30-jul; DP-09 resuelta 2026-08-17 | `[CONFIRMADO]` |
| RN-13 | El grado de **fuerza viva** exige un curso adicional de instructores; puede no existir en una sede nueva | 18-jul | `[CONFIRMADO]` |

### Actividades y participación

| # | Regla | Fuente | Confianza |
|---|---|---|---|
| RN-14 | Toda actividad tiene fecha, sede y tipo, y puede llevar varias etiquetas | 18-jul | `[CONFIRMADO]` |
| RN-15 | Las etiquetas las crea el usuario; el conteo por etiqueta y por año alimenta el informe | 18-jul | `[CONFIRMADO]` |
| RN-15b | Toda actividad lleva su **círculo** (3.º cultura / 2.º filosofía / 1.º voluntariado). La **categoría OINA** de la persona (1 miembros / 2 probacionismo / 3 fuerza viva) es un eje distinto y derivado; ambos se cuentan por separado en el informe | 18-jul, DP-01 | `[CONFIRMADO]` |
| RN-16 | La actividad distingue **título de convocatoria** de **tema canónico**: *"la primera es 'nada cambia si tú no cambias'… pero en realidad el tema se llama filosofía natural"* | 18-jul | `[CONFIRMADO]` |
| RN-17 | Cada actividad reporta asistentes internos y externos por separado | 18-jul, 10-jul#1 | `[CONFIRMADO]` |
| RN-18 | El grupo de un curso se identifica por día, hora y profesor | 10-jul#2 | `[CONFIRMADO]` |
| RN-19 | Un curso puede exigir otro como prerrequisito (introductorio antes de avanzados y de la membresía) | `01-contexto`, 18-jul | `[DATO]` + `[CONFIRMADO]` parcial |

### Captación y seguimiento

| # | Regla | Fuente | Confianza |
|---|---|---|---|
| RN-20 | Toda captación registra el **medio de difusión**, y cuando el medio es "invitado", **quién invitó**, elegido de una lista de personas, no escrito a mano | 30-jul, 02-jul | `[CONFIRMADO]` |
| RN-21 | El catálogo de medios es **extensible por el usuario**: *"tú puedes crear medios también"* | 30-jul | `[CONFIRMADO]` |
| RN-22 | Debe poder contarse cuántas personas invitó cada quien: *"Rotary 9, Alejandro 4"* | 30-jul, xlsx | `[CONFIRMADO]` |
| RN-23 | Un referido sugerido se guarda **como persona en estado `CONTACTO`** con su nombre y sus teléfonos, y con la atribución de quién lo refirió. No hay entidad `REFERIDO` | planillas, xlsx; DP-32 (2026-08-19) | `[DATO]` + `[DECISION-EQUIPO]` |
| RN-24 | Cada contacto de seguimiento queda registrado con quién, cuándo y por qué canal, para no duplicar el esfuerzo entre Milagros, Manuelita, el profe y Claudia | 30-jul | `[CONFIRMADO]` |
| RN-25 | El interés declarado (línea, tipo de actividad, tema) es la base de las invitaciones segmentadas | 10-jul#1, 30-jul | `[CONFIRMADO]` |
| RN-26 | Interés en el curso, estado del embudo y resultado del contacto son **tres campos distintos**; hoy están fundidos en la columna `INTERESADO` del Excel | xlsx | `[INFERIDO]` de P15 |

### Permisos, multi-sede y reporte

| # | Regla | Fuente | Confianza |
|---|---|---|---|
| RN-27 | Alta de personas casi sin restricción — *"desde seguridad hasta desde la secretaría"* — y lectura restringida por sede y área. Escritura abierta, lectura cerrada | 18-jul, 02-jul, 30-jul | `[CONFIRMADO]` |
| RN-28 | Los contactos-enlace (medios, gobierno, artistas) solo los ve el encargado del área que los custodia, más los accesos globales | 30-jul | `[CONFIRMADO]` |
| RN-29 | El director nacional y la secretaria privada tienen acceso global; el consejo local, acceso amplio | 18-jul, 30-jul | `[CONFIRMADO]` |
| RN-30 | Una sede no ve los datos de otra salvo permiso explícito; toda sede reporta a la central | 18-jul, 30-jul | `[CONFIRMADO]` |
| RN-31 | Los totales del informe deben **cuadrar exactamente** con el detalle: *"si uno se pela por uno, de una vez le devuelven esa vaina"* | 18-jul | `[CONFIRMADO]` |
| RN-32 | El informe se llena mensual y se reporta semestral, y debe poder exportarse | 18-jul | `[CONFIRMADO]` |
| RN-33 | Las bajas se clasifican por antigüedad de más o menos de 2 años | OINA/18-jul | `[CONFIRMADO]` |
| RN-34 | El traslado de una persona a otra filial es un tipo de alta y de baja distinto del ingreso y del retiro; cierra el vínculo anterior y abre el nuevo | OINA/18-jul | `[CONFIRMADO]` |
| RN-35 | Hay una vista de cumpleañeros del día y del mes en la entrada del sistema | 02-jul, 18-jul | `[CONFIRMADO]` |
| RN-37 | Si la persona es **menor de edad** a la fecha de registro, se registra su **representante** (nombre, teléfono y parentesco); el consentimiento de contacto lo otorga el representante | Decisión 2026-08-17 sobre datos reales (2 menores en 2024) | `[CONFIRMADO]` |
| RN-38 | Una **clase suelta es una actividad** que además pertenece al grupo de un curso. Permite registrar a quien asiste sin estar inscrito, y que esa asistencia alimente el corte del informe | Decisión 2026-08-17; *"algunos vienen y pagan solo clases"* (18-jul) | `[CONFIRMADO]` |
| RN-39 | La búsqueda de personas funciona por **nombre, cédula y teléfono**; para un `CONTACTO` sin cédula, nombre y teléfono son la única vía | 02-jul, DP-02 | `[CONFIRMADO]` |
| RN-40 | Cualquier usuario con acceso a la ficha puede dejar una **nota libre** fechada y firmada, y **todas las notas son visibles para quien tenga acceso a la ficha** — no hay notas privadas. Son **append-only**: no se editan ni se borran | Decisión 2026-08-17 | `[CONFIRMADO]` |
| RN-41 | **Nunca se borra una persona.** Solo se marca inactiva o archivada; el historial se conserva íntegro | Decisión 2026-08-17 | `[CONFIRMADO]` |
| RN-42 | El **bloqueo** por parte de la persona (p. ej. en WhatsApp) se registra con fecha como marca informativa; no impide conservar la ficha ni su historial | Decisión 2026-08-17 | `[CONFIRMADO]` |
| RN-43 | Una actividad puede tener **cupo**. Cuando está definido, el sistema **avisa** al alcanzarlo y **nunca impide** registrar a quien llegó | Decisión 2026-08-17 | `[CONFIRMADO]` |
| RN-44 | La distinción *invitado por un amigo* / *invitado por un acropolitano* **se deriva** del estado de quien invita; no se captura como campo | 10-jul#1; DP-18 resuelta | `[CONFIRMADO]` |
| RN-36 | No se expone públicamente ningún listado de personas ni su nivel de vínculo | `01-contexto` §9 | `[DATO]` |

### Formulario, acceso y auditoría — sesión 2026-08-19

Todas provienen de `05-decisiones-pendientes.md` DP-23 a DP-36. Ninguna la afirmó Milagros: son decisiones
de equipo. La única que **modifica** un requisito suyo es RN-02, ya marcada arriba como `[POR-VALIDAR]`.

| # | Regla | Fuente | Confianza |
|---|---|---|---|
| RN-45 | **No existe autorregistro.** Toda persona la crea un usuario autenticado de la escuela; `registrado_por` nunca es nulo ni genérico | DP-23 | `[DECISION-EQUIPO]` |
| RN-46 | **Guardar nunca se bloquea.** Un dato faltante, inválido o sospechoso genera una `MARCA_REVISION` resoluble, no un error de validación. Aplica al alta manual y a la importación | DP-24, DP-29, DP-31, DP-36 | `[DECISION-EQUIPO]` |
| RN-47 | Todo registro editable guarda **quién lo modificó por última vez y cuándo**. Los campos de identidad de `PERSONA` — cédula, nombre, apellido, teléfonos — llevan además **bitácora completa de cambios**, porque una edición equivocada rompe en silencio la identidad y el deduplicado | DP-25 | `[DECISION-EQUIPO]` |
| RN-48 | La actividad **se crea antes** de registrar participaciones, y lleva estado `PLANIFICADA` / `REALIZADA` / `CANCELADA`. Sin el estado no se distingue una actividad planificada sin asistentes de una cancelada — y hay caso real: el terremoto de julio-2026 suspendió actividades | DP-26; `02` §2.1 | `[DECISION-EQUIPO]` |
| RN-49 | A una actividad se agregan, **desde la misma pantalla**, tanto personas ya registradas (miembros, amigos de la escuela, asistentes previos) como personas nuevas. La búsqueda es por nombre, cédula o teléfono | DP-27 | `[DECISION-EQUIPO]` |
| RN-50 | **Todo usuario es antes una persona de la escuela**, con rol vigente. No existen cuentas anónimas ni compartidas — el guardia de la puerta tiene la suya porque es miembro y la puerta es su voluntariado | DP-28, DP-34; RN-27 | `[DECISION-EQUIPO]` |
| RN-51 | Al crear una persona se avisa si **la cédula** o **algún teléfono normalizado** ya existe. Dos niveles: cédula igual es casi con seguridad la misma persona; teléfono igual puede ser un familiar (P08). Ninguno impide guardar, y la fusión nunca es automática | DP-29; ID-6 | `[DECISION-EQUIPO]` |
| RN-52 | El interés declarado vigente es **el último por línea** (`FILOSOFIA`, `CULTURA`, `VOLUNTARIADO`), no el último en absoluto: declarar interés en un concierto no borra el interés en voluntariado | DP-30; *"hay gente que solo le interesa el voluntariado"* (30-jul) | `[DECISION-EQUIPO]` |
| RN-53 | El alta exige **nombre y teléfono**. Todo lo demás es opcional, salvo la cédula en la inscripción a curso | DP-24, DP-31 | `[DECISION-EQUIPO]` |
| RN-54 | Los permisos se **otorgan explícitamente**; el sistema los sugiere desde el rol vigente y, **al cerrar un rol**, marca para revisión los permisos asociados. Sin esto, el rol caduca y el acceso no | DP-35; *"cada usuario tendría su grupo de permisos"* (30-jul) | `[DECISION-EQUIPO]` |
| RN-55 | Toda marca de tiempo se almacena en **UTC**, y **todo corte de periodo se calcula en la zona horaria de la sede**. Las actividades son vespertinas: una charla el día 31 a las 20:00 local es el día 1 en UTC, y el informe descuadraría por uno | DP-25b; `01-contexto` §5.1; RN-31 | `[DECISION-EQUIPO]` |

---

## 7. Consultas que el modelo debe soportar

Todas provienen de una necesidad citada, no de un supuesto.

1. Buscar una persona por nombre **o** por cédula y ver su ficha completa con las actividades en que
   participó (02-jul, 18-jul).
2. Cumpleañeros de hoy y del mes (02-jul, 18-jul).
3. De un evento: cuántos asistieron, cuántos internos y cuántos externos (18-jul, 10-jul#1).
4. Cuántos asistentes pasaron a probacionistas en un mes o semestre (30-jul).
5. Cuántas personas invitó cada quien, y qué medio trajo más gente (30-jul, 02-jul).
6. Qué charlas y qué temas atrajeron más asistentes (18-jul).
7. A quién invitar al próximo concierto: lista por interés declarado (30-jul).
8. Quién le escribió a esta persona, cuándo y con qué resultado (30-jul), en una **bitácora única** que
   mezcla notas libres, contactos y cambios de estado (decisión 2026-08-17).
9. Estado del embudo por periodo: cuántos entraron, cuántos inscritos, activos, inactivos (18-jul, 30-jul).
10. Los inactivos con su último estatus y el punto donde quedaron (30-jul).
11. Personas de mi área con su estado (30-jul).
12. Los totales del informe OINA de un mes cualquiera, exportables y cuadrados (18-jul).

---

## 8. Puntos de extensión

No se diseñan. Se declara qué debe prever el núcleo para no rehacerlo después.

| Módulo | Qué debe prever el núcleo | Ancla |
|---|---|---|
| **Escolástica** (asistencia por clase, control académico) | `GRUPO` con día/hora/profesor y `INSCRIPCION` estables; una `SESION_DE_CLASE` colgará de `GRUPO` y la asistencia de `INSCRIPCION`. Milagros ya menciona *"también la asistencia a las clases"* | 10-jul#2, 18-jul |
| **Economía / pagos** | `PERSONA` e `INSCRIPCION` como sujetos de cobro; la ficha debe poder mostrar *"Javier está al día con la mensualidad"*. Todo monto necesitará **moneda y fecha explícitas** (contexto inflacionario) | 18-jul, `01-contexto` §7 |
| **Descuento por estatus** | El estado vigente de la persona condiciona el precio de actividades: *"los que están inscritos en el curso también tienen descuentos especiales… en el taichí, en el yoga"* | 10-jul#2 |
| **Biblioteca / librería** | `PERSONA` como prestatario: *"en la ficha de Javier sale que debe un libro"*; inventario y ventas hoy en el Excel de Karina | 30-jul, 18-jul |
| **Café** | Actividad con cobro de entrada; ya existe como tipo de actividad | 10-jul#1, 18-jul |
| **Inventario de sede** | Área técnica; numeración física ya existente en mesas y sillas. Sin relación con `PERSONA` salvo el responsable | 30-jul |
| **Mensajería automática** | `INTERES_DECLARADO` + `CONSENTIMIENTO_CONTACTO` + `INTERACCION` son la base; el envío masivo se conecta después. Diferido explícitamente | 30-jul |
| **OCR de planillas en papel** | El reconocimiento de la hoja de Manuelita debe escribir en esta misma base: *"eso es una función del sistema… no es el sistema"* | 18-jul |
| **Publicaciones, colecciones de arte y museo** | Campos del informe OINA que hoy la sede no usa (*"nosotros no tenemos todavía"*). El modelo del informe debe tolerar secciones vacías | 18-jul |

---

## 9. Riesgos de dominio registrados

| Riesgo | Evidencia |
|---|---|
| **Bus factor 1** | *"eso lo manejo yo… más nadie tiene nada"* (02-jul); *"si uno se va y no sabe cómo se hace… quedamos igual punchados"* (18-jul) |
| **Pérdida de datos ya ocurrida** | *"el Excel grande… ahora sí se borró completamente"* (30-jul) |
| **Esfuerzo paralelo** | El OCR de Marielys debe apuntar a la misma base, decidido por Milagros (18-jul) |
| **Migración pesada** | Varios Excel más listas de WhatsApp: *"ese es otro trabajo importante… hay que pasar"* (30-jul) |
| **Semántica perdida en formato** | El estado hoy vive en el color de la celda (rojo salió / verde activo, 02-jul); no sobrevive a la importación (P14) |
| **Datos sensibles** | Creencias, participación y menores potenciales; percepción pública dividida (`01-contexto` §9) |
| **El papel sobrevive a la fase 1** | Sin autorregistro (DP-23), la transcripción manual sigue siendo el cuello de botella en eventos grandes. Se asume a conciencia; el riesgo es que se lea como promesa incumplida |
| **RN-02 modificada sin la sede** | DP-24 suaviza la obligatoriedad de la cédula, que Milagros había afirmado el 30-jul. Si lo rechaza, cambia el flujo de la puerta |
| **Permiso huérfano al cambiar de rol** | Mitigado por RN-54, pero depende de que alguien atienda la marca de revisión. Caso vivo: el relevo de Milagros por Isdrey (DP-16) |
