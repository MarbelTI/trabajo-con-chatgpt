# Línea de tiempo y colisión QWF de requisitos — Nueva Acrópolis

**Análisis de descubrimiento** · Sede San Cristóbal / Táriba · Elaborado 2026-08-17
Fuentes: 2 documentos, 1 libro Excel (2 hojas, datos reales), 5 transcripciones de reunión.

> Este documento **no** es la especificación de dominio ni el diccionario de datos: esos son los
> entregables A–D, ya generados en `03`, `04`, `05` y `06`. Este es el paso previo — qué se dijo, cuándo,
> quién lo dijo, y qué requisitos se refuerzan entre sí al superponerlos.

---

## 1. Notación

Cada punto de cada fuente se marca con tres ejes:

| Eje | Qué mide | Valores |
|---|---|---|
| **BULLET POINTS** | La afirmación concreta, en las palabras de la fuente | texto + cita |
| **REACH** | Hasta dónde alcanza la consecuencia del punto | `PERSONA` (una ficha) · `SEDE` (una filial) · `MULTISEDE` (varias filiales) · `INTERNACIONAL` (informe a OINA) |
| **TEMP** | Temperatura: presión real que ejerce hoy sobre la operación | `ARDIENTE` (dolor diario, bloquea) · `CALIENTE` (dolor frecuente) · `TIBIO` (deseado, no urgente) · `FRÍO` (diferido explícitamente a otra fase) |

Confianza (regla del prompt): `[CONFIRMADO]` lo afirmó Milagros · `[DATO]` está en el Excel o la planilla
física · `[HIPÓTESIS]` lo propuso el entrevistador · `[PENDIENTE]` requiere confirmación.
El asentimiento conversacional ("claro", "exacto") **no** cuenta como confirmación de diseño.

---

## 2. Línea de tiempo

### 2.1 Hechos del dominio (lo que pasó en la escuela)

```
2024-04  Milagros asume Relaciones Públicas. Antes: Claudia y otros, "en papelitos".
         Arranca el Excel desde cero → "está desde el 2024". Táriba recién abierta:
         "está muy nuevita la escuela", primer probacionismo inicia en abril.
2024-04-09  Charla "NADA CAMBIA SI TU NO CAMBIAS" — 14 asistentes registrados (Biblioteca Táriba).
2024-04-23  Misma charla, 1 asistente más.
2024-04-30  "ETICA" — 5.
2024-05-07  "7 PLANOS DEL CUERPO" — 1.
2024-05-21  "LA VIDA DESPUÉS DE LA MUERTE" — 1.
2024-05-29  "MITO DE LA CAVERNA" — 11, de los cuales 9 llegan vía ROTARY (bloque externo).
2024-06-11  "SABIDURIA DEL TIBET" — 2.
2024-08-20  "ARISTÓTELES" — 1.
2024-09-21  "LIDERAZGO" — 3, vía SPINNING BIKE. Se abre 2ª hoja "SABADOS SPINNING BIKE".
2024-09-28  "ESTOICISMO" — 7 filas, solo 2 con nombre. El registro se degrada aquí.
            (Última fecha con datos en el libro; el archivo llega hasta filas fantasma sin persona.)
2026-07     Terremoto / "la tragedia": se suspenden actividades culturales. Donación a centro de
            rehabilitación mental sostenida "porque nos habíamos comprometido antes".
2026-07-24  Cumpleaños de Milagros (mencionado en la reunión del 18 como caso de uso).
```

### 2.2 Descubrimiento (las 5 reuniones) y artefactos del repo

```
2026-07-02  meetings/milagro_02_julio_meeting.txt   Reunión 1 — apertura del problema.
2026-07-10  milagro_10_julio_audio_1.txt            Nota de voz — flujo de ingreso a eventos.
2026-07-10  milagro_10_julio_audio_2.txt            Nota de voz — flujo de curso y estatus.
2026-07-18  milagro_18_julio_meeting.txt            Reunión 2 — planillas físicas + informe OINA + círculos.
2026-07-30  milagro_30_julio_meeting.txt            Reunión 3 — máquina de estados + fases + multi-sede.
2026-07-30  photo_2026-07-30_17-22-50.jpg (x2)      Planillas 1 y 2 fotografiadas (ver planillas_inscripcion.md).
2026-08-16  photo_2026-08-16_16-41-10.jpg           Planilla 3 (asistencia a charlas, formato detallado).
2026-08-16  docs/01-contexto-organizacional.md      v1.0 — contexto de fuentes públicas.
2026-08-16  docs/REGISTRO PARTICIPANTES TARIBA (1).xlsx  copiado al repo (contenido de 2024).
2026-08-19  El .xlsx se RETIRA del repo por contener datos personales de 41 personas,
            dos de ellas menores de edad. Custodiado fuera. Ver el aviso en 06 §1.
2026-08-16  docs/planillas_inscripcion.md           transcripción de las 3 planillas.
2026-08-16  commit 54d9b2a "Initialize project with workflows and foundational documentation".
2026-08-17  prompt.md (sin versionar) — encuadre de esta sesión de análisis.
```

**Ordenación de autoridad**: 30-jul > 18-jul > 10-jul > 02-jul. Los documentos `docs/*.md` del 16-ago son
**secundarios** (fuentes públicas y transcripción de fotos), no corrigen a Milagros.

---

## 3. Punto de vista por fuente

### 3.1 `docs/01-contexto-organizacional.md` — la mirada externa (16-ago-2026)

- **BULLET POINTS**
  - Embudo canónico: actividad cultural → curso introductorio → socio → voluntariado. `[DATO]`
  - El objeto central es "persona con vínculo que evoluciona", con **roles acumulables**, no estado único.
  - Venezuela = 4 sedes: San Cristóbal, Táriba, Ejido, Mérida.
  - Curso introductorio es prerrequisito de membresía y de avanzados; el voluntariado no exige membresía.
  - Datos sensibles: no exponer listados de personas ni su nivel de vínculo.
- **REACH**: `INTERNACIONAL` — fija la estructura de tres niveles (OINA → nacional → sede).
- **TEMP**: `TIBIO`. Es marco, no dolor. Aporta vocabulario y advertencias, no requisitos.
- **Nota**: usa "socio" y "alumno"; Milagros **nunca** usa esas palabras. Su vocabulario real es
  *contacto, asistente, probacionista, miembro, fuerza viva, celador, colaborador, amigo de la escuela*.
  El glosario debe ser el de ella. `[CONFIRMADO por contraste de fuentes]`

### 3.2 `docs/planillas_inscripcion.md` — el formulario que ya existe en papel

- **BULLET POINTS**
  - Tres planillas distintas, no una: **inscripción formal** (con cédula, firma, encargado, días/horarios),
    **contacto/feedback de evento** (corta, sin cédula, con satisfacción y consentimiento SI/NO),
    **asistencia a charla** (exhaustiva: dos teléfonos, ocupación, redes desglosadas, medio de difusión,
    referido con nombre + dos teléfonos, y el recuadro "¿está interesado en hacer el curso? SI/NO").
  - La planilla corta **pregunta consentimiento explícito**: "¿Te gustaría recibir más información…? SI/NO".
    Ninguna reunión lo menciona. Es el único soporte de la base legal de contacto. `[DATO]` → `[PENDIENTE]`
  - La planilla corta pide **Instagram** como campo propio; la detallada separa Facebook / Instagram / otros.
  - "Encargado" y "Firma" en la planilla formal = precursor en papel de la auditoría de quién registra.
- **REACH**: `PERSONA` / `SEDE`.
- **TEMP**: `ARDIENTE`. Es el formulario que hoy se transcribe a mano, dos y tres veces.

### 3.3 `REGISTRO PARTICIPANTES TARIBA (1).xlsx` — los datos reales

> **El archivo ya no está en el repositorio** (retirado el 2026-08-19 por contener datos personales
> identificados, incluidos dos menores). Lo que sigue son conclusiones cerradas sobre su contenido y no
> requieren el archivo. El aviso completo, con qué se puede y qué no se puede seguir haciendo, está en
> `06-calidad-de-datos.md` §1.

Estructura: 20 columnas iguales en ambas hojas. Hoja = **lugar + día recurrente**
(`MARTES TÁRIBA BILBIOTECA`, `SABADOS SPINNING BIKE`), no periodo ni curso.

- **BULLET POINTS (lo que los datos dicen, no la estructura)**
  - 44 filas con nombre → **41 personas distintas**. 3 personas duplicadas *entre hojas* con cédula y
    teléfono idénticos (José Gregorio Wover Cedeño, Luisana Mazzei Ramírez, Wilmer David Rincón,
    todos del 21-sep-2024): la misma persona registrada dos veces porque asistió a un evento que cae
    en dos hojas. **La hoja no es una entidad; el evento sí.**
  - Vocabularios controlados observados (validación de datos real del archivo):
    - `POR CUAL MEDIO DE DIFUSION SE ENTERO` — lista cerrada de 9:
      `RADIO, LIBRERIA, TV, FACEBOOK, INSTAGRAM, AFICHE, YOUTUBE, INVITADO , WHATSAPP`
      (nótese el espacio final en `INVITADO `). Frecuencias sobre las **44 filas con nombre**:
      `INVITADO` 28, `INSTAGRAM` 9, `FACEBOOK` 3, `LIBRERIA` 2, `AFICHE` 1, `WHATSAPP` 1 — sin huecos.
      (Sobre las 61 filas con algún dato, `INSTAGRAM` sube a 14 porque 5 filas fantasma lo traen sin
      persona, y quedan 12 sin medio.) **RADIO, TV y YOUTUBE nunca se usaron.**
    - `INTERESADO` — lista de 4: `SI, NO, INSCRITO , NO RESPONDIO`. Sobre las 44 filas con nombre:
      `SI` 14, `INSCRITO ` 7, `NO RESPONDIO` 6, sin dato 17. (Sobre las 61 filas con algún dato:
      24 / 8 / 12 / 17.) `NO` nunca se usó.
    - `LLAMADAS/ MENSAJES` — lista `0..5`. Real: 33 filas con `1`, 2 con `3`, 1 con `4`. El seguimiento
      real es de un solo toque. Coincide con "esto sí ya casi no lo hago" (02-jul).
  - `OCUPACION` es texto libre: 20 valores distintos en 39 filas, con `BIBLIOTECA` y `ROTARIA` que no son
    ocupaciones sino **procedencia institucional** → la columna mezcla dos conceptos.
  - `NOMBRE` (columna K, "invitado por") mezcla personas (`ALEJANDRO` 4, `YRAIMA` 2, `MILAGRO ELENA`,
    `LUIS CORTES`, `CARLOS NADAL`, `OSCAR IZARRA`, `MANUEL MEDINA`) con **instituciones**
    (`ROTARY` 9, `SPINNING BIKE` 4, `BIBLIOTECA` 1) y con la propia escuela (`NUEVA ACROPOILIS`, con typo).
    Dos relaciones distintas en una columna: *referido por persona* y *captado vía alianza*.
  - Conversión medible por tema (hoja 1): las **6 filas `INSCRITO` están todas en la charla inaugural
    "NADA CAMBIA SI TU NO CAMBIAS"**. `MITO DE LA CAVERNA` (11 asistentes vía Rotary) tiene la columna
    `INTERESADO` **vacía en las 11 filas**: no es conversión cero, es **dato ausente**. `[PENDIENTE]`
  - Patologías que serán casos de prueba de importación:
    | # | Patología | Evidencia |
    |---|---|---|
    | P1 | Cédula y teléfono almacenados como **float** | 100% de las filas: `27634020.0` |
    | P2 | Teléfono fuera de formato | `573152993750` (12 díg., prefijo Colombia) y `414718` (6 díg., truncado) |
    | P3 | Cédula vacía en fila con nombre | `FREDDY EDUARDO ORTIZ ACEVEDO` |
    | P4 | Duplicación de persona entre hojas | 3 casos, cédula idéntica |
    | P5 | Email inválido (falta `@`) | `fmpadilla4380gmail.com` |
    | P6 | Email compartido por dos personas | `jempresarymc@gmail.com` → José Gutiérrez y Jhoan Morian |
    | P7 | Email con espacio final | `lyndahadgialy@gmail.com ` |
    | P8 | Teléfono compartido por dos personas | dos pares (madre/hija, hermanas) → **legítimo**: el teléfono no puede ser clave |
    | P9 | Fecha de nacimiento = fecha del evento | `JHOAN MORIAN` → `2024-04-05` (dato basura) |
    | P10 | Fecha de nacimiento incoherente con cédula | `IRAIDA MONCADA`, cédula 18.019.467 con nacimiento 1937 |
    | P11 | 17 filas fantasma en hoja 2 | sin nombre, solo valores de validación (`1`, `SI`, `NO RESPONDIO`) |
    | P12 | Misma variable en columna distinta según hoja | conteo de llamadas: validado en `N` en hoja 1, en `O` (columna rotulada "COMENTARIOS") en hoja 2 |
    | P13 | Validación que no cubre los datos | `INTERESADO` validado `T2:T23`, hay datos hasta `T40` |
    | P14 | **Semántica en el color, no en el valor** | relleno rojo en `O27:O31` (celdas vacías), naranja en `O32,O33,O35`, amarillo en `A38:A40`, azul en `A25:A34` (bloque Rotary). El 02-jul confirma la convención: *"los que están en rojo… se salieron; los que están en verde son los que están activos"*. Al importar, esto se pierde. |
    | P15 | Concepto triple en un enum | `INTERESADO` mezcla interés (`SI`/`NO`), estado del embudo (`INSCRITO`) y resultado del contacto (`NO RESPONDIO`) |
- **REACH**: `SEDE` (Táriba), pero el mismo formato se usa en San Cristóbal, Mérida y Ejido → `MULTISEDE`.
- **TEMP**: `ARDIENTE`. Es el sistema actual. Y el 30-jul: *"el Excel grande… ahora sí se borró
  completamente"* — **ya se perdió un archivo sin respaldo**.

### 3.4 Reunión 02-jul-2026 — el problema se nombra

- **BULLET POINTS**
  - Función del área: tejer relaciones "hacia afuera" (empresas, espacios, medios, protección civil,
    bomberos — a los que llama **"fuerzas vivas de la ciudad"**) y "hacia adentro" (comunicación entre
    miembros y grupos). `[CONFIRMADO]`
  - Ella es **el único punto de acceso**: *"todo eso lo manejo yo… llegas a mí"*, *"más nadie tiene nada"*,
    *"no tiene acceso solamente yo"*. Es a la vez la queja y una decisión de confidencialidad deliberada.
  - Hay **al menos tres Excel distintos**: el suyo de contactos, el de asistencia, el de Manuelita.
    *"no es el Excel de asistencia que yo tengo acceso, es otro Excel"*.
  - *"como la escuela ha crecido, se me está haciendo más pesado llevar eso"* → el disparador es escala.
  - Pide, textual: formulario rápido en la app *"si alguien está ahí, le preguntas los datos y se guardó"*;
    **alarma de cumpleaños**; historial de actividades por persona; selector de "invitado por";
    estadísticas gráficas ("yo selecciono la columna y me da la estadística"); acceso de consulta para
    los consejeros (*"que si yo busco Javier Bastidas… número de teléfono, cédula"*).
  - Reconoce que dejó de hacer seguimiento: *"llamadas y mensajes… esto sí ya casi no lo hago"*.
  - Admite que el archivo está **"desactualizadísimo"**.
- **REACH**: `SEDE` con dependencia crítica en `PERSONA` única (ella).
- **TEMP**: `ARDIENTE` — riesgo de bus factor = 1.
- **Contaminación a vigilar**: casi todas las soluciones de esta reunión (formulario rápido, estadísticas,
  selector) las **propone el entrevistador**; ella responde "sí, exacto". `[HIPÓTESIS]` hasta el 18-jul,
  donde ella las reformula por iniciativa propia → recién ahí suben a `[CONFIRMADO]`.

### 3.5 Nota de voz 10-jul #1 — el flujo de ingreso, contado por ella sin intervención

Fuente más limpia del corpus: monólogo, cero contaminación del entrevistador.

- **BULLET POINTS**
  - **Tres capas de registro, con datos crecientes**:
    1. **Puerta / seguridad**: nombre, apellido, teléfono. *"el primer paso es anotado en la puerta por
       seguridad… ahí queda como el primer registro"*.
    2. **Actividad externa** (conciertos, café, arteterapia): nombre, apellido, **cédula**, actividad a la
       que asiste, teléfono, ¿le interesa volver? y **a cuál actividad**, y cómo se enteró
       (Instagram / Facebook / invitación de un amigo / **invitación de un acropolitano**).
    3. **Economía**: quién pagó la entrada, quiénes participaron.
  - Métrica que ya calculan a mano: *"¿cuáles de esos que asistieron son **acropolitanos** y cuántos son
    **externos**"*. Es una clasificación binaria interno/externo exigida por el informe. `[CONFIRMADO]`
  - La actividad se distingue por **tipo**: arteterapia / charla / concierto.
- **REACH**: `SEDE`.
- **TEMP**: `CALIENTE`. Ocurre en cada evento.
- **Ojo**: aquí dice que en actividades externas **sí** se pide cédula. Contradice la lectura del 18-jul
  ("los de eventos no se la piden") y el 30-jul ("es más difícil"). Ver §6, colisión D1.

### 3.6 Nota de voz 10-jul #2 — el flujo de curso y el primer mapa de estatus

- **BULLET POINTS**
  - Inscripción a curso: se piden **todos** los datos — nombre, apellido, cédula, **día y hora de clase
    "para distinguir como los grupos"**, profesor/encargado del curso, fecha de nacimiento, correo,
    Instagram y otra red, ubicación/dirección, teléfono, a qué se dedica, a quién quiere invitar,
    por dónde se enteró y **quién lo invitó**, y qué tema le gustaría.
  - **Beneficio cruzado**: *"los que están inscritos en el curso también tienen descuentos especiales en
    las actividades externas, culturales, en el taichí, en el yoga"* → el estatus condiciona precio.
    `[CONFIRMADO]` — implicación económica que ninguna otra fuente menciona.
  - Transiciones, en sus palabras: *"algunos cambian de estatus… inscritos pasan, algunos se retiran,
    quedan como no inscritos, quedan como **amigos de la escuela**, o se salen de la escuela"*;
    *"cuando ya dejan de ser **probacionistas**, pasan a ser **miembros**, eso es como otro estatus"*.
  - **Roles simultáneos**: *"yo estoy haciendo el curso de instructores, estoy encargada del área de
    relaciones públicas… hay otros que son **fuerzas vivas**, tienen como otros roles dentro de la misma
    escuela"*. Confirma roles acumulables sobre un estatus único.
  - **Petición explícita, en sus palabras**: *"la idea es como unificar un poco más ese proceso"*.
- **REACH**: `PERSONA` + `SEDE`.
- **TEMP**: `CALIENTE`.
- **Alerta de glosario**: **"fuerza viva"** aparece con dos sentidos incompatibles — instituciones de la
  ciudad (02-jul) y grado interno de la escuela (10-jul, 18-jul, 30-jul). Homónimo, no sinónimo. `[PENDIENTE]`

### 3.7 Reunión 18-jul-2026 — la reunión estructural

La más densa. Aporta tres cosas que ninguna otra fuente tiene: el informe internacional, los círculos y
la exigencia de cuadre numérico.

- **BULLET POINTS**
  - **Cédula como identificador**: el entrevistador lo plantea, ella lo acepta y lo reformula —
    *"sí, sería bueno igual tenerlo"* → *"como su ID… que eso sea lo fundamental que nos conecte a todos"*.
    `[CONFIRMADO]`
  - **Alta sin fricción y desde el teléfono**: *"lo soñado sería que yo lo pudiese hacer desde el celular…
    y que cualquiera lo pueda hacer, desde seguridad hasta desde la secretaría"*. Web, no atada a un
    equipo. `[CONFIRMADO]`
  - **Formulario progresivo**: una planilla básica siempre disponible para cualquier actividad, y al
    inscribirse a curso *"un botón o algo que le despliegue estos demás campos y que lo pase a estado
    inscrito"*. `[CONFIRMADO]`
  - **El informe a la internacional es el verdadero cliente del modelo**: *"todas las sedes tenemos el
    deber de pasar toda esta información a la grande"*; se llena **mensual** y se reporta **semestral**.
    Campos que exige (leídos en voz alta de la planilla): miembros del año anterior, **altas** y **bajas**
    (con corte de antigüedad **más / menos de 2 años**), **altas por traslado de filiales** (una persona se
    traslada a una filial de otro país), miembros presentes, número de grupos, total de instructores
    activos, secretarías, dirigentes, reuniones de instructores, cursos de instructores,
    **reuniones de consejo**, probacionistas del año/semestre/mes, asistentes a presentaciones de
    probacionismo, media de asistencia, **altas de probacionistas después de la tercera clase**,
    probacionistas que pasaron a miembros, redes sociales y anuncios (ingresos por internet, propaganda,
    contacto personal, **actividades de tercer círculo**), biblioteca (libros vendidos / donados /
    recibidos), publicaciones, difusión (seguidores por red, inversión en anuncios), actividades culturales
    con asistentes **de la escuela vs externos**, voluntariado, colecciones arqueológicas y de arte,
    economía. `[DATO + CONFIRMADO]`
  - **La exigencia dura es el cuadre**: *"si uno se pela por uno, de una vez le devuelven esa vaina"*.
    Los totales del informe deben reconciliar exactamente con el detalle. → *"si el sistema me da la
    totalización es más fácil"*, *"hasta se podría exportar"*. `[CONFIRMADO]`
  - **Los tres círculos** (modelo propio de la escuela, dibujado en la reunión):
    - 3.º círculo = **cultura** (arteterapia, charlas inaugurales, probacionismo inicial) — "están nuevitos".
    - 2.º círculo = **filosofía** — "aquí ya entran los miembros"; se pasa al terminar el probacionismo,
      con **acto de graduación**, y la membresía sirve para asistir a clases **en otro país**.
    - 1.º círculo (centro) = **voluntariado** — asume un área, un ejercicio fijo; *"la celaduría es un
      ejercicio de voluntariado"*.
    - **Fuerzas vivas** = grado aparte que exige otro curso (instructores). En Táriba: *"no tenemos nada de
      eso porque está muy nuevita la escuela"*; en San Cristóbal *"solamente FB es Claudia y Jesús"*.
    - Frontera de "interno": *"¿se considera alguien interno cuando pasó el segundo módulo?"* → **"No,
      cuando está inscrito en filosofía"**. `[CONFIRMADO]` — define el binario interno/externo del informe.
  - **Contradicción interna en la numeración**: describe 3.º=cultura, 2.º=filosofía, 1.º=voluntariado, y
    minutos después, leyendo la planilla: *"uno, que es miembros; dos, que es probacionismo; y tres, que es
    fuerza viva"*. Dos numeraciones distintas para "círculo". `[PENDIENTE bloqueante de enum]`
  - **Etiquetas en vez de taxonomía rígida**: el entrevistador propone etiquetas; ella las adopta con
    razón propia — *"me suena como la idea de etiquetas más que clasificarlos, porque es como misceláneo…
    pueden tener varias cosas a la vez, día de la tierra más algo de arte"*. Etiquetas creables por el
    usuario, filtrables por año, **y la actividad debe tener fecha** porque *"esto se hace en varios meses"*.
    `[CONFIRMADO por adopción argumentada]`
  - **Ficha 360 de la persona**: *"que eso sea tu ficha, tu cédula: Javier está al día con la mensualidad,
    las asistencias, está al día con escolástica, y tiene a cargo la celadoría del curso tal"*.
  - **Cumpleaños**: pestaña de cumpleañeros del día/mes al entrar. `[CONFIRMADO]`
  - **Auditoría**: la firma de la planilla física se traduce en *"¿quién lo registró? Milagro. ¿Quién lo
    registró? Alejandro"* → **registrado_por, y métrica de cuántas personas registró cada quien**. `[CONFIRMADO]`
  - **Multi-sede**: un solo sistema, no uno por sede. *"el profe puede ver todas, es el director del país"*;
    Manuelita consolida todas las sedes hacia la internacional; una persona con acceso a dos sucursales
    debe **elegir sede en el formulario**; quien solo pertenece a una no ve las otras. `[CONFIRMADO]`
  - **Fragmentación del conocimiento**: *"tengo que preguntarle a Manuelita, me tiene que preguntar a mí,
    le tiene que preguntar a Karina… entre las tres responder"*. Y el riesgo de continuidad:
    *"si uno se va y no sabe cómo se hace… quedamos igual punchados"*.
  - **Módulos adyacentes ya identificados y postergados**: escolástica (asistencia + pago), economía,
    biblioteca (inventario y ventas, hoy otro Excel de Karina), café. *"primero resolver lo más urgente,
    que es relaciones públicas"*. `[CONFIRMADO]`
  - **Riesgo de esfuerzo paralelo**: Marielys está construyendo OCR con IA para digitalizar las anotaciones
    de Manuelita. Decisión de Milagros: *"vamos a hacerlo juntos… que quede uno solo unificado"*; eso es
    **una función del sistema, no el sistema**. `[CONFIRMADO]`
- **REACH**: `INTERNACIONAL`.
- **TEMP**: `ARDIENTE` (el cuadre del informe) + `CALIENTE` (todo lo demás).

### 3.8 Reunión 30-jul-2026 — la máquina de estados y el orden de fases

- **BULLET POINTS**
  - **Estados consolidados**, validados uno por uno con ella:
    - **contacto** — solo teléfono, llegó por WhatsApp/Instagram, no ha venido.
      *"a esa persona tú no le vas a pedir cédula ni cuándo nació"*. Vive hoy en una lista aparte y en
      WhatsApp; *"lo que hago es que reenvío, reenvío, reenvío"*.
    - **asistente** — vino a algo (evento, arteterapia, una charla suelta, una clase suelta) pero no está
      inscrito. *"si vino a la escuela e hizo parte de algo, hizo contacto"*. Desde aquí **sí** se puede
      pedir cédula: *"el guardia de seguridad sí pide cédula para registrar"*.
    - **probacionista** — inscrito en el curso.
    - **miembro** — después del probacionismo. Cambio de estatus **sobre la misma ficha**:
      *"no le va a pedir otra vez todos los datos… solamente un estatus dentro de la misma ficha"*.
    - **inactivo** — se salió. Se le sigue haciendo seguimiento e invitando: *"hasta que no nos bloquees"*.
      Existen grupos de WhatsApp de "amigos de la escuela".
    - Y para el inactivo, un requisito específico: guardar **hasta dónde llegó** — *"ay, yo quiero volver…
      pero yo no me acuerdo dónde iba esa persona"* → **último estatus alcanzado + hasta qué tema**.
  - **Roles como subcategoría, no como estatus**: *"mi estatus es probacionista, pero dentro de mí podría
    ver que está colaborando en tal área"*. Roles nombrados: **colaborador**, **encargado de área**
    (antes "consejero"), **instructor**, **celador**. Caso de uso: *"Carlos ve una lista de los que
    pertenecemos y dice: tengo cuatro miembros y dos probacionistas"*.
  - **Contactos-enlace = categoría aparte con permiso restringido**: contactos de radio, TV, medios,
    músicos, filoartistas, danza, teatro, gente de gobierno. *"eso es otra categoría… no podrían ser
    contactos porque eso tiene más importancia"*, *"tienen que tener acceso precisamente los encargados de
    área"*, *"Carlos, como encargado de difusión, solo ve sus contactos de difusión"*. Y son convertibles:
    *"también son contactos que pueden convertirse en los demás"*. `[CONFIRMADO]`
  - **La causa raíz, dicha por ella**: *"se pide como a veces hasta tres veces la información a la misma
    persona"* → *"si tú le pides es porque algo literal faltó, pero no volver a pedirle lo mismo"*.
  - **Bitácora de seguimiento**: *"entras a la ficha de Javier y hoy le escribí"*, porque hoy
    *"Manuelita le envía mensaje, yo le envío mensaje, el profe le envía mensaje, Claudia le envía mensaje
    y todo el mundo"*. `[CONFIRMADO]`
  - **Sello temporal de registro**: *"si se registra alguien queda ahí tal cual la fecha y la hora"*.
  - **Vocabulario de medios extensible**: *"tú puedes crear medios también"* — por si aparece otra red
    social en unos años. Enum **abierto**. `[CONFIRMADO]`
  - **Orden de fases, dicho por ella y por Manuelita**: *"las personas son la base de todo"* →
    fase 1 personas/RRPP; después módulos de economía, biblioteca (incluye **préstamos de libros**:
    *"Javier se llevó tal libro… en la ficha de Javier sale que debe un libro"*), escolástica, inventario.
  - **Automatización de mensajería**: un tercer participante empuja *"¿por qué no automatizar ese
    proceso?"*; Milagros no lo niega pero lo **difiere**: *"claro, pero por fases"*. Se cierra con
    *"el dolor que debemos apaciguar ahorita es este [la base]"*.
  - **Multi-sede por etapas**: empezar con San Cristóbal + Táriba, luego Mérida y Ejido, y las filiales
    que se abran. Manuelita = secretaria privada, ve todo y reporta a la internacional; el profe =
    director nacional, acceso total.
  - **Adiós al Excel**: *"¿ya no se va a hacer por Excel?" — "Exacto"*.
  - **Pérdida de datos ya ocurrida**: *"el Excel grande… ahora sí se borró completamente"*.
  - **Legitimidad del requisito**: *"nació de ti el requerimiento" — "sí, exacto… porque yo soy la que
    tengo la información"*.
  - **Decisión técnica, diferida**: el entrevistador declara "una base de datos SQL relacional".
    `[HIPÓTESIS del entrevistador]` — no es requisito de negocio y **no se descarta**: la elección de motor
    y stack se decide en fase posterior (DP-19). El modelo de dominio se mantiene independiente de motor.
  - **Cambio organizativo en curso**: se incorpora una nueva jefa de área (nombre corrupto en la
    transcripción: "Drake"/"Drac"; el nombre real es **Isdrey**, confirmado el 2026-08-17). Milagros
    empieza a delegar. Faltan sus permisos y su área.
- **REACH**: `MULTISEDE`.
- **TEMP**: `ARDIENTE`.

---

## 4. Modelo de colisión QWF (explícito y reproducible)

No es física: es una **heurística determinista** para separar lo que varias fuentes independientes
refuerzan de lo que una sola voz sostiene o de lo que las fuentes se cancelan entre sí. Se declara
completa para que cualquiera recalcule y discuta los pesos.

A cada requisito **R** se le asigna una amplitud por fuente *f*:

```
ψ_f(R) = c_f · r_R · e^{iφ_f}

c_f  (confianza de la fuente)     CONFIRMADO (Milagros) = 1.0
                                  DATO (Excel / planilla) = 0.8
                                  HIPÓTESIS (entrevistador) = 0.5

r_R  (peso del REACH)             PERSONA 0.6 · SEDE 0.8 · MULTISEDE 1.0 · INTERNACIONAL 1.2

φ_f  (fase)                       afirma       → 0      (interfiere en fase)
                                  contradice   → π      (cancela)
                                  solo asiente → π/2    (ortogonal: no suma ni resta)

I(R)      = |Σ_f ψ_f|²            intensidad coherente (con interferencia)
I_inc(R)  = Σ_f |ψ_f|²            suma incoherente (sin interferencia)
G(R)      = I / I_inc             ganancia. G > 1.15 constructiva · G < 0.85 destructiva
```

La fase `π/2` es la que hace el trabajo fino: el asentimiento conversacional ("claro", "exacto") **no
aporta intensidad**, exactamente como pide el método del prompt.

### Resultado

| REQ | REACH | Fuentes | I | I_inc | G | Interferencia | TEMP |
|---|---|---|---:|---:|---:|---|---|
| R06 Atribución de captación (medio + invitado por) | SEDE | 6 | **20.07** | 3.38 | 5.94 | CONSTRUCTIVA | CALIENTE |
| R01 Base única de personas | MULTISEDE | 4 | **16.00** | 4.00 | 4.00 | CONSTRUCTIVA | ARDIENTE |
| R05 Estados + historial de transiciones | MULTISEDE | 4 | **14.44** | 3.64 | 3.97 | CONSTRUCTIVA | ARDIENTE |
| R08 Totalización que cuadre con el informe OINA | INTERNACIONAL | 3 | **11.29** | 3.80 | 2.97 | CONSTRUCTIVA | ARDIENTE |
| R16 Interés declarado por línea (filosofía/cultura/voluntariado) | SEDE | 4 | 8.29 | 2.10 | 3.95 | CONSTRUCTIVA | CALIENTE |
| R10 Multi-sede + rollup central | MULTISEDE | 3 | 7.84 | 2.64 | 2.97 | CONSTRUCTIVA | CALIENTE |
| R03 Alta móvil/web sin fricción | SEDE | 3 | 5.02 | 1.69 | 2.97 | CONSTRUCTIVA | ARDIENTE |
| R12 Bitácora de seguimiento (quién contactó y cuándo) | SEDE | 3 | 5.02 | 1.69 | 2.97 | CONSTRUCTIVA | CALIENTE |
| R15 Módulos futuros como puntos de extensión | SEDE | 3 | 5.02 | 1.69 | 2.97 | CONSTRUCTIVA | FRÍO |
| R07 Etiquetas libres con fecha | INTERNACIONAL | 2 | 3.24 | 1.80 | 1.80 | CONSTRUCTIVA | CALIENTE |
| R02 Cédula como ID único | MULTISEDE | 4 | 3.24 | 3.64 | **0.89** | NEUTRA (cancelación parcial) | CALIENTE |
| R04 Formulario progresivo | PERSONA | 3 | 2.82 | 0.95 | 2.97 | CONSTRUCTIVA | CALIENTE |
| R11 Auditoría de quién registró | SEDE | 2 | 2.07 | 1.05 | 1.98 | CONSTRUCTIVA | TIBIO |
| R09 Cumpleaños / avisos | PERSONA | 2 | 1.44 | 0.72 | 2.00 | CONSTRUCTIVA | TIBIO |
| R14 Automatización de mensajería masiva | SEDE | 2 | 0.80 | 0.80 | 1.00 | NEUTRA (diferida) | FRÍO |
| R13 Contactos-enlace restringidos por área | SEDE | 3 | **0.64** | 1.92 | **0.33** | DESTRUCTIVA | CALIENTE |

Cálculo reproducible en `qwf.py` (scratchpad de la sesión); los 4 parámetros de arriba son toda la
configuración.

**Lectura**: los cuatro picos (R06, R01, R05, R08) son el núcleo del sistema y ninguno depende de una sola
voz. Los dos casos anómalos —R02 neutra y R13 destructiva— **no son requisitos débiles: son requisitos mal
formulados**, y se arreglan al acotar su dominio (§6).

---

## 5. Interferencia constructiva → bucles de retroalimentación positiva

Un bucle cuenta como positivo si es un ciclo cerrado donde cada arista aumenta la magnitud de la
siguiente. Cinco sobreviven al filtro; los cinco se anclan en cita **y** en dato medido.

### Bucle A — Atribución de captación (el más fuerte: R06, I=20.07)

```mermaid
flowchart LR
  A1[Alta en sitio<br/>móvil, 4 campos] --> A2[Se captura<br/>medio + invitado por]
  A2 --> A3[Ranking de quién invita<br/>y qué canal convierte]
  A3 --> A4[Se reconoce y se repite<br/>lo que funciona]
  A4 --> A5[Más invitados<br/>por persona y por alianza]
  A5 --> A1
```

- **Evidencia medida**: el ranking ya existe y es desigual — `ROTARY` 9, `ALEJANDRO` 4, `SPINNING BIKE` 4,
  `YRAIMA` 2, el resto 1. Y ella ya lo lee así: *"cada vez que aparece el nombre de una persona, esa
  persona fue la que invitó más… Rotary 9, Alejandro 4"* (30-jul).
- **Ganancia**: 28 de 44 filas (64%) llegaron por `INVITADO`. El canal dominante es el que hoy se registra
  peor: la columna mezcla persona con institución (P-columna K).
- **Condición para que el bucle cierre**: separar **referido por persona** (FK a persona) de
  **captado vía alianza** (FK a organización aliada), y hacer del campo un selector, no texto libre.
- **Lo que hoy lo rompe**: `NUEVA ACROPOILIS` con typo, `ROTARY` como si fuera una persona, y 12 filas sin
  medio registrado.

### Bucle B — Base única y fin del re-preguntar (R01 + R12 + R03)

```mermaid
flowchart LR
  B1[Una sola base<br/>consultable por todos] --> B2[Cada área ve estado completo:<br/>pago, asistencia, seguimiento]
  B2 --> B3[Se deja de pedir<br/>el mismo dato 3 veces]
  B3 --> B4[La gente responde más<br/>y el dato queda limpio]
  B4 --> B5[Más confianza en la base]
  B5 --> B6[Más áreas la adoptan:<br/>economía, biblioteca, escolástica]
  B6 --> B1
```

- **Evidencia**: *"se pide a veces hasta tres veces la información a la misma persona"* (30-jul);
  *"tengo que preguntarle a Manuelita, me tiene que preguntar a mí, le tiene que preguntar a Karina…
  entre las tres responder"* (18-jul); *"yo no sé si usted está al día en la mensualidad… no tengo forma
  de saberlo"* (18-jul).
- **Ganancia negativa medida hoy**: 33 de 36 filas con seguimiento tienen exactamente **1** llamada. El
  bucle está abierto: sin memoria del contacto, nadie hace el segundo toque, y a la vez todos escriben a la
  vez sin saberlo (*"Manuelita le envía mensaje, yo le envío mensaje, el profe le envía mensaje"*).
- **Condición**: la bitácora de interacción debe ser barata de registrar (un toque) o no se registrará —
  el Excel lo demuestra.

### Bucle C — Cuadre del informe internacional (R08 + R07 + R11)

```mermaid
flowchart LR
  C1[Registro granular<br/>persona · actividad · etiqueta · fecha] --> C2[Totalización automática]
  C2 --> C3[El informe mensual cuadra<br/>y no se devuelve]
  C3 --> C4[Menos trabajo manual<br/>de reconstrucción]
  C4 --> C5[Más incentivo a registrar<br/>en el momento, no después]
  C5 --> C1
```

- **Evidencia**: *"si uno se pela por uno, de una vez le devuelven esa vaina"* / *"si el sistema me da la
  totalización es más fácil… hasta se podría exportar"* (18-jul).
- **Por qué el bucle hoy va al revés**: *"si yo lo tengo en físico… ni se acuerda a veces de qué
  actividades hizo en tantas que hace el mes"*. La reconstrucción tardía produce descuadre, el descuadre
  produce devolución, la devolución consume el tiempo que haría falta para registrar a tiempo.
- **Condición**: la etiqueta y la fecha de la actividad son el eje del conteo. Y el informe pide
  **asistentes de la escuela vs externos** por actividad → el binario interno/externo (inscrito en
  filosofía o no) debe ser derivable, no capturado a mano.

### Bucle D — Segmentación por interés declarado (R16)

```mermaid
flowchart LR
  D1[Se pregunta qué actividad<br/>le interesa volver a ver] --> D2[Invitación segmentada<br/>por línea: cultura · filosofía · voluntariado]
  D2 --> D3[Mayor tasa de asistencia<br/>por invitación]
  D3 --> D4[Más señal de interés<br/>y de tema preferido]
  D4 --> D1
```

- **Evidencia**: *"se reenvía la invitación al próximo concierto… porque es lo que le interesa"*,
  *"hay gente que solo le interesa el voluntariado"* (30-jul); *"¿está interesado en asistir nuevamente a
  alguna otra actividad y cuál?"* (10-jul #1); las tres planillas preguntan tema o actividad deseada.
- **Estado real del bucle: casi abierto**. `TEMAS SUGERIDOS` está lleno en solo **11 de 44** filas (25%), y la
  columna de interés (`INTERESADO`) mezcla tres conceptos (P15) y está vacía en 17 filas. La señal existe
  en el papel y se pierde en la digitalización.
- **Condición**: separar `interés en el curso` (SI/NO), `estado del embudo` y `resultado del contacto` en
  tres campos distintos, y volver `temas sugeridos` un vocabulario que crezca con el uso.

### Bucle E — Embudo por círculos (R05 + R07 + R08)

```mermaid
flowchart LR
  E1[Actividad de 3.º círculo<br/>etiquetada, con tema y fecha] --> E2[Conversión medida:<br/>asistente → probacionista]
  E2 --> E3[Se sabe qué charla<br/>y qué título convierten]
  E3 --> E4[Se programa más<br/>de lo que convierte]
  E4 --> E5[Más probacionistas → más miembros]
  E5 --> E6[Más celadores y fuerzas vivas]
  E6 --> E1
```

- **Evidencia**: *"precisamente ponía la charla para ver de esas charlas cuáles son las que más llaman la
  atención"* y *"las charlas del principio tienen un título más llamativo… ese título sería bueno
  incluirlo"* (18-jul); *"¿cuántos asistentes pasaron a probacionista en tal mes / tal semestre?"* (30-jul);
  el informe OINA pide literalmente *ingresos por actividades de tercer círculo* y *altas de
  probacionistas después de la tercera clase*.
- **Evidencia medida, con su límite**: las **6** filas `INSCRITO` de la hoja 1 están **todas** en la charla
  inaugural `NADA CAMBIA SI TU NO CAMBIAS` (6 de 15 asistentes, 40%); la hoja 2 aporta una séptima
  (`FREDDY ORTIZ`, `ESTOICISMO`). `MITO DE LA CAVERNA` aportó 11
  asistentes vía Rotary y tiene `INTERESADO` **vacío en las 11 filas** — **no se puede afirmar que no
  convirtió**; el dato falta. `[PENDIENTE]`
- **Condición**: el corte de la tercera/cuarta clase debe existir como evento del sistema —
  *"si llevan más de cuatro clases se inscriben"* (18-jul) vs *"altas de probacionistas después de la
  tercera clase"* (planilla OINA). Dos umbrales distintos. `[PENDIENTE]`
- **Cierre del bucle E con el A**: el 4.º círculo de facto son las **alianzas** (Rotary, Spinning Bike,
  Biblioteca Táriba): 14 de 44 filas —12 personas distintas— llegaron por una institución, no por una
  persona. Nadie lo
  nombró como categoría. `[INFERIDO → PENDIENTE]`

### Acoplamiento entre bucles

```mermaid
flowchart TD
  A[A · Atribución] -->|alimenta el conteo de origen| C[C · Cuadre OINA]
  B[B · Base única] -->|hace barato registrar| A
  B -->|da memoria al seguimiento| D[D · Segmentación]
  D -->|más asistentes a 3.º círculo| E[E · Embudo por círculos]
  E -->|más miembros y celadores| B
  C -->|el informe deja de consumir el mes| B
```

**B es el bucle raíz**: los otros cuatro solo tienen ganancia si B existe. Coincide con lo que ella y
Manuelita dijeron sin que nadie lo propusiera: *"las personas son la base de todo"*, *"de ahí parte todo"*.

---

## 6. Interferencia destructiva — contradicciones reales y su resolución

| # | Colisión | Fuente A | Fuente B (más reciente gana) | Resolución propuesta |
|---|---|---|---|---|
| **D1** | ¿Se pide cédula en eventos? | 10-jul #1: en actividad externa se pide *"nombre, apellido, número de cédula"*. 18-jul: *"en los eventos no se la piden… sería bueno igual tenerlo"* | **30-jul**: para **contacto** no (*"no le vas a pedir cédula ni cuándo nació"*); desde **asistente** sí (*"el guardia de seguridad sí pide cédula"*) | Cédula **obligatoria desde `asistente`**, **prohibida como requisito** en `contacto`. Identidad de `contacto` = teléfono. Cambio de criterio registrado. |
| **D2** | ¿Alta sin permisos o accesos restringidos? | 18-jul: *"que casi no tenga permisología… que cualquiera pueda agregar una persona"* | **30-jul**: *"esos contactos tienen que tener acceso precisamente los encargados de área"*; 02-jul: *"esa base no es para que la maneje todo el mundo"* | No es contradicción sino **asimetría**: escritura de alta casi abierta / **lectura restringida por área y por sede**. Los contactos-enlace son una categoría con ACL propia. Esto explica el G=0.33 de R13: el requisito estaba mal enunciado, no en disputa. |
| **D3** | Numeración de los círculos | 18-jul: 3.º cultura, 2.º filosofía, 1.º voluntariado | 18-jul (misma reunión, leyendo la planilla OINA): *"uno, miembros; dos, probacionismo; tres, fuerza viva"* | ✅ **Resuelta 2026-08-17: son dos ejes distintos.** `CIRCULO_ACTIVIDAD` (proximidad, sobre la actividad) y `CATEGORIA_OINA` (grado de la persona, derivado). No se colapsan. Ver DP-01 en `05`. |
| **D4** | Umbral de "se inscribió de verdad" | 18-jul: *"si llevan más de cuatro clases se inscriben"* | Planilla OINA: *"altas de probacionistas **después de la tercera clase**"* | `[PENDIENTE]`. Probablemente 3 = corte del informe y 4 = criterio local. No se asume. |
| **D5** | "Fuerza viva" | 02-jul: *"las fuerzas vivas de la ciudad, protección civil, bomberos"* | 10-jul/18-jul/30-jul: grado interno con curso propio | Homónimo. Dos términos distintos en el glosario: `fuerza_viva` (grado) y `institución_aliada`. `[CONFIRMADO por contraste]` |
| **D6** | ¿Automatizar mensajería ya? | 30-jul, tercer participante: *"¿por qué no automatizar ese proceso?"* | **30-jul, Milagros**: *"claro, pero por fases… el dolor que debemos apaciguar ahorita es este"* | Fase posterior. Es lo correcto que su G quede en 1.00: hay demanda pero no de la dueña del requisito. |
| **D7** | Vocabulario de roles | `01-contexto` (16-ago): socio, alumno, egresado, benefactor | Las 5 reuniones: contacto, asistente, probacionista, miembro, fuerza viva, celador, colaborador, encargado de área, amigo de la escuela | Gana el vocabulario de la sede. El documento de contexto queda como mapeo hacia afuera, no como glosario. |
| **D8** | "Consejero" vs "encargado de área" | 02-jul: *"que los consejeros tengan acceso"* | 30-jul: *"encargado de área tal"*, y *"las reuniones de las áreas se llama consejo"* | `consejo` = la reunión del área; `encargado de área` = el rol. "Consejero" queda como sinónimo informal. `[INFERIDO]` |

---

## 7. Superposición no colapsada — estado al 2026-08-17

Ordenado por impacto estructural. **Las doce quedaron colapsadas** en la sesión de decisiones del 17 de agosto;
se conservan con su resolución para trazabilidad. **Todo cerrado al 2026-08-17**: DP-01 a DP-21 en `05`.
Solo sobrevive un `[PENDIENTE]` menor de redacción en DP-01 (la lectura de la numeración 1/2/3 de la
planilla OINA) y DP-22, que es carga de datos y no decisión de modelo.

| # | Punto | Estado |
|---|---|---|
| 1 | Numeración de los círculos (D3) | ✅ **Dos ejes distintos**: `CIRCULO_ACTIVIDAD` y `CATEGORIA_OINA` |
| 2 | Identidad de `contacto` sin cédula | ✅ **Teléfono + nombre**, clave débil asumida; fusión asistida |
| 3 | Umbral de inscripción firme, 3 o 4 clases (D4) | ✅ **Ninguno dispara nada**: la inscripción es manual; 3 y 4 son corte de reporte |
| 4 | ¿"4.º círculo" de alianzas? 14 filas / 12 personas vía Rotary, Spinning Bike, Biblioteca | ✅ **`ORGANIZACION_ALIADA` es entidad**; no es un círculo |
| 5 | Consentimiento de contacto (SI/NO de la planilla) | ✅ **Informativo**: se registra, no bloquea envíos |
| 6 | Retención y borrado — *"hasta que no nos bloquees"* | ✅ **El bloqueo se registra como marca con fecha; nunca se borra a nadie.** Además, nuevo requisito: **notas libres fechadas** en la ficha |
| 7 | "Amigo de la escuela" vs `inactivo` | ✅ **Es `INACTIVO`**; la diferencia es un atributo de invitación |
| 8 | Traslado entre filiales | ✅ **Un vínculo activo con historial**; el acceso a dos sedes es permiso de usuario |
| 9 | Descuento por estatus | ✅ **Va al módulo de economía**, no a fase 1 |
| 10 | Nombre de la nueva jefa de área | ✅ **Isdrey**; faltan sus permisos y su área |
| 11 | Menores de edad en el registro | ✅ **Se registra al representante** (nombre, teléfono, parentesco) |
| 12 | Temas canónicos de las 8 charlas de 2024 | ✅ **No bloquea**: es carga de datos posterior; el título se importa y el tema queda nulo |

---

## 8. Lo que este documento no decide

- No define entidades, atributos, cardinalidades ni enums finales: eso es el entregable **A/B**, bloqueado
  por el CHECKPOINT del prompt.
- No adopta motor de base de datos **en esta fase**. La mención de "SQL relacional" del 30-jul sigue viva
  como hipótesis por defecto y se decide más adelante (DP-19); el modelo de dominio queda independiente de
  motor para no prejuzgarla.
  **Actualización 2026-08-19: DP-19 ya está resuelta** en `05` — PWA responsive, PostgreSQL, UUIDv7,
  almacenamiento en UTC. La hipótesis relacional del 30-jul se confirmó. Este documento no se rehace: se
  deja tal como estaba el 17 de agosto, porque es el registro del descubrimiento, no de la arquitectura.
- No propone reglas de saneamiento del Excel; las 15 patologías quedan listadas como insumo del
  entregable **D**.
