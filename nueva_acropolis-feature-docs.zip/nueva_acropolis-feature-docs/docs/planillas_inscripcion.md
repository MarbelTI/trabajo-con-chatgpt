### 1. Ficha de Inscripción (Cursos y Actividades Formales)

Esta planilla (`photo_2026-07-30_17-22-50 (2).jpg`) es el registro formal para quienes ya decidieron inscribirse en una actividad o curso específico.

**Campos solicitados:**

* **Fecha en que se inscribe:**
* **Nombre y apellido:**
* **Número de teléfono:**
* **Número de cédula:**
* **Domicilio:**
* **Red social:**
* **Correo electrónico:**
* **Labores:**
* **Fecha de nacimiento:**
* **Actividad en la que se inscribe:**
* **Días de asistencia:**
* **Horarios:**
* **Encargado:**
* **Firma:**

---

### 2. Planilla de Contacto y Feedback de Eventos (Formato Corto)

Este formato (`photo_2026-07-30_17-22-50.jpg`) es más sencillo y rápido de llenar. Está diseñado para captar los datos básicos de un asistente a un evento, medir su satisfacción inicial y abrir la puerta a futuras comunicaciones.

**Campos solicitados:**

* **Nombre y Apellido:**
* **Telf.:** (Teléfono)
* **Correo Electrónico:**
* **Instagram:**
* **¿Cómo te pareció el evento?**
* **¿Cómo te enteraste del evento?** (Ofrece opciones para completar: *Invitado por: / Redes sociales / otro*)
* **¿Te gustaría recibir más información de nuestras actividades?** (Opciones: *SI / NO*)
* **¿Qué actividad cultural te gustaría que se realizara en este espacio?**

---

### 3. Planilla de Asistencia a Charlas (Formato Detallado)

Esta versión (`photo_2026-08-16_16-41-10.jpg`) es mucho más exhaustiva. Se utiliza en charlas introductorias para obtener un perfil demográfico más completo del asistente, evaluar a fondo los canales de difusión y, de manera crucial, identificar prospectos directos para el curso de filosofía y obtener referidos.

**Campos solicitados:**

* **Fecha:**
* **Tema de la Charla:**
* **Nombres y Apellidos:**
* **C.I.:** (Cédula de Identidad)
* **N° de Teléfonos:** (Espacio para dos números)
* **Ocupación:**
* **F. Nacimiento:** (Fecha de Nacimiento)
* **Tus redes/e-mail:**
* **Facebook:**
* **Instagram:**
* **Otros:**
* **¿Por cuál medio de Difusión te enteraste?:** (Ofrece opciones: *Invitado por: / Librería / Redes: Radio, TV, YouTube, Facebook, Instagram, Afiche*)
* **Te agradecemos nos compartas tu experiencia en la charla:**
* **¿Te gustaría que se aborde algún tema en particular?**
* **¿Te gustaría invitar a vivir la experiencia algún conocido? Nombre:**
* **N° de Teléfonos:** (Del referido, espacio para dos números)
* **Recuadro final de interés:** *¿Está interesado en hacer el curso?* (Opciones: *SI / NO*)