# Contexto Organizacional — Nueva Acrópolis

**Documento base del proyecto** · Sede San Cristóbal, Estado Táchira, Venezuela
Versión 1.0 · 2026-08-16 · Elaborado a partir de fuentes públicas oficiales y de terceros.

> Propósito: fijar el contexto de la organización antes de planear el producto. No define aún alcance
> técnico ni arquitectura. Todo lo marcado como **[VALIDAR]** requiere confirmación con la sede local.

---

## 1. Resumen ejecutivo

Nueva Acrópolis es una escuela de filosofía práctica, de alcance internacional, organizada como
federación de asociaciones civiles sin fines de lucro. Opera en tres líneas: **Filosofía** (cursos),
**Cultura** (actividades abiertas al público) y **Voluntariado** (acción social y ambiental).

Su funcionamiento local descansa en un embudo bastante estable:
actividad cultural abierta → curso introductorio de filosofía → membresía como socio → voluntariado
y roles de colaboración. El sostén económico son las cuotas de curso, las cuotas mensuales de socios,
la venta de material y las donaciones, con equipo administrativo mínimo y trabajo voluntario.

Consecuencia para el sistema: el objeto central no es "alumno" ni "cliente", sino **persona con un
vínculo que evoluciona en el tiempo** y que puede tener varios roles simultáneos (socio + voluntario +
alumno de curso avanzado). El modelo de datos debe soportar roles múltiples y trazabilidad del vínculo,
no un estado único.

---

## 2. Identidad y propósito

- **Definición oficial:** "Escuela de Filosofía que promueve la cultura y practica el voluntariado."
- **Filosofía "a la manera clásica":** conocimiento aplicable a la vida diaria, no filosofía académica.
- **Los tres principios fundacionales** (constantes en todas las sedes nacionales):
  1. **Fraternidad** — reunir personas de todas las creencias, razas y condiciones sociales en torno a
     un ideal de fraternidad universal, basado en la dignidad humana.
  2. **Conocimiento** — despertar una visión global mediante el estudio comparado de filosofías,
     religiones, ciencias y artes.
  3. **Desarrollo** — desarrollar las capacidades del individuo, integrándolo con la naturaleza y con
     su propia personalidad.
- **Independencia declarada:** de intereses políticos, religiosos y financieros. No se define como
  religión ni exige adhesión confesional.

---

## 3. Historia y gobierno

| Hito | Dato |
|---|---|
| Fundación | 1957, Buenos Aires, Argentina |
| Fundador | Jorge Ángel Livraga Rizzi (1930–1991) |
| Constitución internacional | 1981 — Organización Internacional Nueva Acrópolis (OINA) |
| Sede internacional | Bruselas, Bélgica |
| Estatus legal | Asociación internacional sin fines de lucro, Real Decreto 12-feb-1990, Registro Internacional de Asociaciones (Bélgica) |
| Dirección internacional 1992–2020 | Delia Steinberg Guzmán (hoy presidenta de honor) |
| Presidencia actual | Carlos Adelantado Puchal (desde 2020) |
| Presencia | 50+ países, 400+ sedes (cifra declarada por la organización) |

---

## 4. Estructura organizativa

Tres niveles. El sistema a construir vive en el tercero.

**Internacional (OINA)**
- Asamblea General: un representante por asociación nacional federada; se reúne anualmente.
- Junta Directiva: electa entre miembros de la Asamblea; coordina la ejecución de acuerdos.
- Fija Carta Fundacional, principios y el programa de estudios común.

**Nacional (Asociación Nueva Acrópolis Venezuela)**
- Asociación civil autónoma, responsable ante las autoridades venezolanas, adherida a la Carta
  Fundacional. Autonomía administrativa y financiera respecto a las demás.
- Venezuela: **4 sedes** — San Cristóbal, Táriba (Táchira), Ejido y Mérida (Mérida).

**Sede local (San Cristóbal)**
- Unidad operativa: dicta cursos, organiza actividades culturales y coordina voluntariado.
- Define localmente el monto de cuotas ("cada sede establece la cuantía de las cuotas, dependiendo de
  la situación de la sede").
- Roles operativos típicos: dirección de sede, tutores/profesores de curso, coordinadores de área
  (cultura, voluntariado, biblioteca), colaboradores administrativos. **[VALIDAR]** organigrama real y
  nombres de los roles usados en San Cristóbal.

---

## 5. Líneas de acción

### 5.1 Filosofía — la Escuela
Actividad central. Estructura en dos etapas:

- **Curso introductorio** ("Filosofía a la manera clásica" / "Filosofía para vivir"). Abierto a
  cualquier persona, sin requisitos previos ni nivel educativo mínimo. Recorrido por sistemas de
  pensamiento de Oriente y Occidente (Sócrates, Platón, Aristóteles, Buda, Confucio, Cicerón, Marco
  Aurelio, Giordano Bruno). Material de apoyo entregado por clase.
  - **Duración: varía por país** — 36 h / 4 meses (Argentina), 48 h / 4 meses (Chile-Arica),
    50 h / 6 meses (España). Constante: **~1 clase semanal de 2 h, horario vespertino**.
    **[VALIDAR]** duración y carga horaria en San Cristóbal.
  - Es el **requisito de entrada a la membresía formal**: quien quiere ser socio debe completarlo.
- **Cursos avanzados** (tras el introductorio): Psicología, Sabiduría de Oriente y Occidente (2
  niveles), Simbología, Filosofía Aplicada y Ética, Sociopolítica, Oratoria (2 niveles), Historia de la
  Filosofía (4 niveles), Historia de las Religiones, Antropogénesis, Cosmogénesis, Astrología,
  Filosofía de la Ciencia, Estética Metafísica.

Implicación: el catálogo es **multi-curso, multi-nivel, por cohortes con fecha de inicio**, con
prerrequisitos entre cursos y clases recurrentes semanales (base natural para control de asistencia).

### 5.2 Cultura
Actividades abiertas al público, principal fuente de captación. En Venezuela se documentan:
conferencias y talleres, festivales culturales y educativos, homenajes (p. ej. a Simón Díaz),
semanas temáticas (Semana de China), café cultural, arteterapia, danzaterapia, yoga, caminatas
filosóficas, festivales de lectura infantil. Frecuentemente en alianza con instituciones locales
(IPASME, bibliotecas, universidades).

Implicación: eventos de asistencia libre, sin inscripción previa formal → captura de asistentes en
sitio, con datos mínimos y consentimiento explícito para contactarles después.

### 5.3 Voluntariado
"Forma práctica de encarnar la filosofía." Dos frentes:
- **Ambiental:** limpiezas ecológicas, reforestación, huertos y bosques urbanos, reciclaje,
  protección animal, campamentos, campañas globales ("Plantemos por el planeta", Día de la Madre Tierra).
- **Humanitario/social:** recolectas de alimentos, ropa y material escolar, asistencia en emergencias
  (en Venezuela se reporta apoyo tras inundaciones), programas culturales en hogares de ancianos e
  infantiles, formación de voluntarios.

No exige ser socio: "se puede participar libremente en los programas de voluntariado".

Implicación: el voluntariado es una **vía de entrada paralela** al curso, no posterior. Requiere
registrar jornadas, horas y participantes por actividad.

---

## 6. Personas y vínculos (taxonomía base para el sistema)

Categorías derivadas del funcionamiento real. Son **roles acumulables**, no estados excluyentes.

| Rol | Definición | Origen típico |
|---|---|---|
| **Contacto / lead** | Persona que pidió información o dejó datos; sin actividad aún | Redes, WhatsApp, referido, sede |
| **Asistente a actividad** | Asistió a charla/evento cultural abierto | Actividad de Cultura |
| **Inscrito** | Se inscribió a un curso; puede no haber pagado ni empezado | Curso introductorio |
| **Alumno** | Cursa activamente; genera asistencia y pagos | Curso intro o avanzado |
| **Egresado** | Completó el curso introductorio; habilitado para membresía y avanzados | — |
| **Socio** | Miembro formal; aporta cuota mensual; accede a toda la red | Post-curso introductorio |
| **Voluntario** | Participa en jornadas de voluntariado | Puede entrar sin ser socio |
| **Colaborador / tutor** | Sostiene la operación: dicta clases, coordina áreas | Socios con trayectoria |
| **Amigo / benefactor** | Vínculo cercano o donante, sin membresía | Variado |

**Ciclo de vida canónico (el embudo a instrumentar):**

```
Interés  →  Actividad cultural  →  Curso introductorio  →  Egreso  →  Socio  →  Voluntario/Colaborador
  ↑              ↑                        ↑
  └── redes, referidos, visita a sede, WhatsApp ──┘
                       (entrada directa a voluntariado también posible)
```

El **seguimiento** ("trackeo") vive en las transiciones: quién asistió y no se inscribió, quién se
inscribió y no pagó, quién se ausentó dos clases seguidas, quién egresó y no se asoció, quién dejó de
pagar la cuota. Ahí está el valor del sistema.

---

## 7. Modelo económico

Cuatro pilares declarados, descentralizados por sede:

1. **Cursos** — matrícula/cuota de formación y venta de material cultural (libros, revistas, apuntes).
2. **Cuotas de socios** — aporte mensual, monto fijado por cada sede.
3. **Voluntariado** — mano de obra no remunerada; equipo administrativo mínimo.
4. **Donaciones y patrocinios** — instituciones y empresas privadas.

Implicaciones para el módulo de pagos:
- Al menos **tres flujos distintos**: pago de curso (único o en cuotas), cuota mensual recurrente de
  socio, venta de libros/material. Más donaciones puntuales.
- **[VALIDAR]** monedas en uso (Bs / USD), medios de pago reales (Pago Móvil, Zelle, efectivo,
  transferencia), si se emiten recibos y con qué formato, y si existe contabilidad formal a la que el
  sistema deba alimentar.

---

## 8. Contexto local — San Cristóbal, Táchira

- **Dirección referida:** Carrera 14 entre calles 9 y 10, Barrio Obrero, San Cristóbal, Táchira.
  **[VALIDAR]** — dato de directorio de terceros, no de fuente oficial.
- **Teléfono referido:** 0426-6378287. **[VALIDAR]**
- **Horario referido:** lunes a sábado 10:00–19:00; domingo 09:00–12:00. **[VALIDAR]**
- **Canales digitales:** Facebook `nuevaacropolissc`, sitio nacional `nuevaacropolisve.com`
  (nota: el certificado TLS del sitio nacional falla en verificación al momento de este documento).
- Sede vecina en **Táriba**, misma región: posible necesidad de multi-sede en el modelo desde el inicio.

Condicionantes operativos del entorno **[VALIDAR con la sede]**:
- WhatsApp es el canal dominante de comunicación y captación en Venezuela.
- Conectividad y electricidad intermitentes → conviene tolerancia a operación offline o degradada.
- Inflación/multimoneda → los montos requieren moneda explícita y fecha, nunca un número suelto.

---

## 9. Consideraciones de datos sensibles y reputación

- El sistema manejará datos personales de menores potenciales, creencias y participación en una
  organización filosófica. Debe tratarse como **dato sensible**: consentimiento explícito para el
  contacto, acceso por rol, y borrado a solicitud.
- Existe **percepción pública dividida**: además de su presentación oficial, la organización ha sido
  objeto de señalamientos por parte de comisiones parlamentarias y organismos europeos (Parlamento
  Europeo 1984, Asamblea Nacional francesa 1995, MIVILUDES) y de literatura crítica que la califica
  como movimiento sectario. Se consigna como contexto factual, no como juicio.
- Consecuencia de diseño, independientemente de la valoración: **evitar exponer públicamente listados
  de personas, su nivel de vínculo o su historial**; minimizar los datos recolectados; no compartir
  la base con terceros.

---

## 10. Implicaciones directas para el sistema (insumo para la fase de planeación)

Entidades candidatas que se desprenden del contexto:

- **Persona** (única, con roles múltiples y línea de tiempo de vínculo)
- **Sede** (multi-sede desde el diseño: San Cristóbal, Táriba, …)
- **Curso** → **Cohorte/Edición** (fecha inicio, horario, tutor) → **Inscripción** → **Sesión de clase**
  → **Asistencia**
- **Actividad cultural** (evento abierto) → **Asistencia a evento**
- **Membresía** (socio, con periodo y cuota vigente)
- **Jornada de voluntariado** → **Participación** (horas)
- **Pago** (curso, cuota de socio, material, donación) con moneda y método
- **Producto/Libro** e inventario básico
- **Interacción de seguimiento** (llamada, WhatsApp, visita) con responsable y resultado

Reglas de negocio ya identificadas:
- El curso introductorio es prerrequisito de la membresía formal y de los cursos avanzados.
- Los cursos avanzados tienen prerrequisitos y niveles secuenciales.
- El voluntariado no exige membresía.
- Las cuotas las fija cada sede → montos configurables por sede, no globales.

---

## 11. Preguntas abiertas para la sede (bloqueantes de la fase de planeación)

1. Organigrama y roles reales de la sede; quién usará el sistema y con qué permisos.
2. Duración, carga horaria, calendario y cupo del curso introductorio en San Cristóbal.
3. Catálogo real de cursos avanzados que se dictan localmente.
4. Montos, monedas y medios de pago; existencia de becas o exoneraciones.
5. Herramientas actuales (cuadernos, Excel, WhatsApp, Google Forms) y volumen de personas registradas.
6. Definición local de "amigo", "simpatizante" y demás términos que usan a diario — el sistema debe
   hablar su vocabulario, no uno inventado.
7. Requisitos de reporte hacia la asociación nacional / OINA.

---

## 12. Fuentes

Oficiales de la organización:
- [Qué es Nueva Acrópolis — OINA](https://www.acropolis.org/es/que-es-nueva-acropolis)
- [Preguntas frecuentes — OINA](https://www.acropolis.org/es/preguntas-frecuentes)
- [Voluntariado — OINA](https://www.acropolis.org/es/voluntariado/)
- [Organización — Nueva Acrópolis Costa Rica](https://acropoliscr.org/organizacion/)
- [Qué es Nueva Acrópolis — España](https://nueva-acropolis.es/que-es-nueva-acropolis/)
- [Programa de estudios — Colombia](https://acropoliscolombia.org/programa-de-estudios/)
- [Curso de Filosofía — Argentina](https://nueva-acropolis.org.ar/filosofia/)
- [Curso Filosofía a la manera clásica — Chile (Arica)](https://www.nueva-acropolis.cl/arica/curso-filosofia/)
- [Sobre nosotros — Nueva Acrópolis Venezuela](https://nuevaacropolisve.com/que-es-nueva-acropolis-venezuela/)
- [Actividades de Venezuela — Acropolis News](https://news.acropolis.org/author/oinav/)
- [Nueva Acrópolis San Cristóbal — Facebook](https://www.facebook.com/nuevaacropolissc/)

Terceros:
- [Nueva Acrópolis — Wikipedia (es)](https://es.wikipedia.org/wiki/Nueva_Acr%C3%B3polis)
- [Ficha de directorio — vymaps (datos de contacto San Cristóbal)](https://vymaps.com/VE/Nueva-Acropolis-San-Cristobal-Venezuela-323789981309114/)
