# B. Diccionario de datos — Fase 1

**Nueva Acrópolis** · 2026-08-17 · Complemento de `03-especificacion-de-dominio.md`.
**Revisión 2026-08-19**: incorpora DP-19 y DP-23 a DP-36 de `05-decisiones-pendientes.md`.
Tipos conceptuales (`texto`, `entero`, `fecha`, `fecha_hora`, `booleano`, `enum`, `ref`), no tipos de un
motor concreto. `Ob.` = obligatoriedad.

Cambios de la revisión: `PERSONA_CONTACTO` (§1b) y `MARCA_REVISION` (§21b) entran; `REFERIDO` (§18) sale;
`SEDE.zona_horaria`, `ACTIVIDAD.estado`, credenciales en `USUARIO`, vigencia en los permisos y auditoría
de modificación transversal se añaden. Enums nuevos E-20, E-21, E-22; reglas de formato nuevas F-8 a F-11.
Balance de entidades: 22 → 23.

Denominador de todas las frecuencias del Excel: **44 filas con nombre** (39 en `MARTES TÁRIBA BILBIOTECA`
+ 5 en `SABADOS SPINNING BIKE`) → **41 personas distintas**. Cuando una cifra usa el total de 61 filas con
algún dato (incluidas las 17 filas fantasma) se indica explícitamente.

---

## 1. PERSONA

| Campo | Tipo | Ob. | Formato / máscara | Validación | Default | Notas y traza |
|---|---|---|---|---|---|---|
| `id` | ref | sí | — | — | — | Identificador interno, nunca visible |
| `cedula_tipo` | enum E-19 | **condicional** | `V` \| `E` | Requerido si hay cédula | `V` | Confirmado 2026-08-17: se guarda el prefijo. El Excel solo trae el número |
| `cedula` | texto | **no** | `7–8` dígitos, sin puntos ni guiones; se presenta como `V-12345678` | Única por `cedula_tipo` + número **cuando existe**. Prohibido exigirla en `CONTACTO`; se pide y se avisa desde `ASISTENTE`; **obligatoria solo en la inscripción a curso**. Si falta → `MARCA_REVISION` tipo `CEDULA_FALTANTE` | — | RN-02 **modificada** por DP-24 (`[POR-VALIDAR]`), ID-1, RN-46. Observado: 7–8 dígitos (mín. `1524974`, máx. `32785762`) |
| `nombre` | texto | sí | Capitalización normalizada | ≥2 caracteres | — | P16: el Excel guarda nombre y apellido en una sola columna |
| `apellido` | texto | **no** | idem | Se pide y **no bloquea**; si falta → `MARCA_REVISION` tipo `APELLIDO_FALTANTE` | — | DP-31 (2026-08-19). `MELANY VALENTINA` no tiene apellido distinguible (P16) |
| ~~`telefono_principal`~~ · ~~`telefono_secundario`~~ · ~~`telefono_internacional`~~ · ~~`correo`~~ | — | — | — | **Movidos a `PERSONA_CONTACTO`** (§1b) | — | DP-33 (2026-08-19): RN-39 pide buscar por teléfono e ID-6 deduplicar por teléfono normalizado; con tres columnas eso son tres comparaciones por par de fichas |
| `fecha_nacimiento` | fecha | no | `AAAA-MM-DD` | Entre 1900 y hoy; no puede ser igual a la fecha del evento | — | RN-35 (cumpleaños). Rango observado 1937-10-20 … 2009-05-06. Un valor basura: `2024-04-05` (P09) |
| `es_menor_de_edad` | booleano | derivado | — | Calculado a la **fecha de registro**, no a hoy | — | **Dos menores reales en los datos de 2024** (nacidos 2008 y 2009) |
| `representante_nombre` | texto | **condicional** | — | Requerido si `es_menor_de_edad` | — | RN-37, decisión 2026-08-17 |
| `representante_telefono` | texto | **condicional** | `0XXX-XXXXXXX` | Requerido si `es_menor_de_edad` | — | RN-37 |
| `representante_parentesco` | texto | no | — | — | — | Madre, padre, tutor. RN-37 |
| `ocupacion` | texto | no | Texto libre con catálogo sugerido | — | — | Enum abierto E-07. La columna del Excel mezcla ocupación con procedencia (P19) |
| `direccion` | texto | no | — | — | — | *"se le pide ubicación, dónde vive, dirección"* (10-jul#2) |
| ~~`instagram`~~ · ~~`facebook`~~ · ~~`otras_redes`~~ | — | — | — | **Movidos a `PERSONA_CONTACTO`** (§1b) | — | DP-33. Mismo motivo: una sola tabla de valores de contacto |
| `estado_vigente` | enum E-01 | derivado | — | Debe existir un registro abierto en `ESTADO_PERSONA_HIST` | `CONTACTO` | RN-01 |
| `ultimo_estado_alcanzado` | enum E-01 | derivado | — | — | — | RN-11: *"el último estatus dentro de la escuela"* (30-jul) |
| `punto_de_salida` | texto | no | — | — | — | *"llegó hasta el tema tal"* (30-jul) |
| `es_interno` | booleano | derivado | — | Estado `PROBACIONISTA`/`MIEMBRO` **o** cualquier rol vigente | — | RN-10, precisado 2026-08-17 |
| `contacto_bloqueado` | booleano | no | — | — | `falso` | RN-42: la persona bloqueó el contacto. Marca informativa; la ficha se conserva |
| `contacto_bloqueado_en` | fecha | no | — | Requerido si `contacto_bloqueado` | — | RN-42 |
| `archivada` | booleano | sí | — | — | `falso` | RN-41: **no existe borrado**; solo archivar |
| `categoria_oina` | enum E-06b | derivado | — | Del estado vigente y de los roles | — | Dimensión del informe internacional (DP-01 resuelta): 1 miembros · 2 probacionismo · 3 fuerza viva |
| `sede_vigente` | ref SEDE | derivado | — | Del vínculo abierto en `PERSONA_SEDE` | — | RN-07 |
| `registrado_por` | ref USUARIO | sí | — | — | — | RN-06: *"¿quién lo registró? Milagro"* (18-jul) |
| `registrado_en` | fecha_hora | sí | — | — | ahora | *"queda ahí tal cual la fecha y la hora en que se registró"* (30-jul) |
| `modificado_por` | ref USUARIO | no | — | — | — | RN-47 (DP-25): último que editó la ficha |
| `modificado_en` | fecha_hora | no | — | ≥ `registrado_en` | — | RN-47 |
| `fusionada_en` | ref PERSONA | no | — | — | — | ID-7: rastro de deduplicación |

**Bitácora de cambios de identidad (RN-47).** Los campos `cedula`, `cedula_tipo`, `nombre`, `apellido` y
los valores de `PERSONA_CONTACTO` de tipo teléfono llevan además historial completo de cambios — valor
anterior, valor nuevo, usuario y fecha. El resto se conforma con `modificado_por` / `modificado_en`. Motivo:
son los únicos campos donde una edición equivocada rompe en silencio la identidad (ID-1) y el deduplicado
(ID-6).

---

## 1b. PERSONA_CONTACTO  ·  nueva (DP-33, 2026-08-19)

Teléfonos, correos y redes como filas. Sustituye siete columnas de `PERSONA`.

| Campo | Tipo | Ob. | Formato / máscara | Validación | Notas |
|---|---|---|---|---|---|
| `persona_id` | ref | sí | — | — | |
| `tipo` | enum E-22 | sí | — | — | `TELEFONO`, `TELEFONO_INTL`, `CORREO`, `INSTAGRAM`, `FACEBOOK`, `OTRA_RED` |
| `valor` | texto | sí | Tal como se captura | Sin espacios al inicio ni al final (F-1) | Se conserva el original sin transformar, incluso si es inválido (IMP-04) |
| `valor_normalizado` | texto | sí | Ver F-3 y F-8 | **Indexado** | Teléfono venezolano a 11 dígitos con el `0`; internacional en E.164; correo en minúsculas. Es la clave de búsqueda (RN-39) y de deduplicado (ID-6, RN-51) |
| `es_principal` | booleano | sí | — | **Uno solo verdadero por `(persona, tipo)`** | El "teléfono principal" de la ficha |
| `es_valido` | booleano | derivado | — | — | `falso` genera `MARCA_REVISION` tipo `TELEFONO_INVALIDO`. Observado: `414718`, 6 dígitos truncados (P02) |
| `registrado_por` / `registrado_en` | ref / fecha_hora | sí | — | — | RN-06 |

**No hay unicidad global sobre `valor_normalizado`.** Es deliberado: hay dos casos reales de teléfono
compartido entre personas distintas (P08) y uno de correo compartido (P06). Se avisa, no se impide
(ID-4, ID-5, RN-51).

---

## 2. SEDE

| Campo | Tipo | Ob. | Validación | Default | Notas |
|---|---|---|---|---|---|
| `id` | ref | sí | — | — | |
| `codigo` | enum E-08 (abierto) | sí | Único | — | `SAN_CRISTOBAL`, `TARIBA`, `EJIDO`, `MERIDA` + *"las que se abran"* (30-jul) |
| `nombre` | texto | sí | — | — | |
| `es_central` | booleano | sí | Solo una verdadera | `falso` | *"todos le reportan a la central"* (18-jul) |
| `pais` | texto | sí | — | `Venezuela` | El traslado de filiales puede cruzar países (OINA) |
| `zona_horaria` | texto | sí | IANA (`America/Caracas`) | `America/Caracas` | RN-55 (DP-25b): **todo corte de periodo se calcula en esta zona**, no en UTC. Las actividades son vespertinas: el día 31 a las 20:00 local es el día 1 en UTC |

## 3. PERSONA_SEDE

| Campo | Tipo | Ob. | Validación | Notas |
|---|---|---|---|---|
| `persona_id` / `sede_id` | ref | sí | — | |
| `desde` | fecha | sí | ≤ hoy | |
| `hasta` | fecha | no | > `desde` | `null` = vínculo vigente |
| `motivo_fin` | enum E-09 | no | — | `TRASLADO_FILIAL`, `BAJA`, `OTRO`. RN-34 |
| `es_principal` | booleano | sí | **Un solo vínculo vigente por persona** | DP-03 resuelta: el acceso de Milagros a San Cristóbal y Táriba es `PERMISO_SEDE` del usuario, no doble pertenencia de la persona |

## 4. ESTADO_PERSONA_HIST

| Campo | Tipo | Ob. | Validación | Notas |
|---|---|---|---|---|
| `persona_id` | ref | sí | — | |
| `estado` | enum E-01 | sí | Transición válida según §5 de A | |
| `desde` / `hasta` | fecha | sí / no | Sin solapamiento por persona | Append-only. Insumo de altas y bajas (RN-33) |
| `disparador` | texto | no | — | Inscripción, graduación, retiro, reingreso |
| `es_automatico` | booleano | sí | — | Solo `CONTACTO → ASISTENTE` es automático |
| `registrado_por` | ref USUARIO | sí | — | RN-06 |

## 5. ROL_ASIGNADO

| Campo | Tipo | Ob. | Validación | Notas |
|---|---|---|---|---|
| `persona_id` | ref | sí | — | |
| `rol` | enum E-04 | sí | — | RN-08: acumulables |
| `area_id` | ref AREA | condicional | Requerido para `COLABORADOR` y `ENCARGADO_AREA` | RN-09 |
| `desde` / `hasta` | fecha | sí / no | — | **Con historial** (DP-12 resuelta 2026-08-17): se guarda entre qué fechas alguien tuvo el rol. El informe cuenta instructores y dirigentes **activos** |
| `grupo_id` | ref GRUPO | no | — | Para `CELADOR`: *"tiene a cargo la celadoría del curso tal"* (18-jul) |

## 6. AREA

| Campo | Tipo | Ob. | Notas |
|---|---|---|---|
| `codigo` | enum E-05 (abierto) | sí | `RELACIONES_PUBLICAS`, `DIFUSION`, `ESCOLASTICA`, `ECONOMIA`, `BIBLIOTECA`, `INTEGRACION`, `TECNICA` (30-jul) |
| `nombre` | texto | sí | |
| `sede_id` | ref SEDE | sí | El área existe por sede |

---

## 7. ACTIVIDAD

| Campo | Tipo | Ob. | Formato | Validación | Default | Notas |
|---|---|---|---|---|---|---|
| `id` | ref | sí | — | — | — | |
| `sede_id` | ref | sí | — | — | — | P22: el Excel lo esconde en el nombre de la hoja |
| `tipo` | enum E-03 (abierto) | sí | — | — | — | Charla, concierto, arteterapia, campamento, jornada… |
| `linea` | enum E-02 | sí | — | — | — | `FILOSOFIA`, `CULTURA`, `VOLUNTARIADO` — *"son tres líneas"* (18-jul) |
| `circulo_actividad` | enum E-06 | sí | — | — | — | Eje de proximidad: 3.º cultura · 2.º filosofía · 1.º voluntariado. DP-01 resuelta |
| `titulo` | texto | sí | — | — | — | Título de convocatoria: `NADA CAMBIA SI TU NO CAMBIAS` |
| `tema` | texto | no | — | — | — | Tema canónico, distinto del título: *"en realidad el tema se llama filosofía natural"* (18-jul). Confirmado 2026-08-17: las charlas iniciales llevan un título atractivo distinto del tema. RN-16 |
| `inicio` | fecha_hora | sí | `AAAA-MM-DD HH:MM` | ≥ fecha de creación de la sede | — | RN-14: *"tiene que tener fecha"* |
| `fin` | fecha_hora | no | — | > `inicio` | — | Campamentos y semanas temáticas |
| `lugar` | texto | no | — | — | — | `Biblioteca Táriba`, `Spinning Bike` |
| `organizacion_aliada_id` | ref | no | — | — | — | Cuando la actividad se hace en alianza (DP-04 resuelta) |
| `grupo_id` | ref GRUPO | no | — | — | — | RN-38: una clase suelta es actividad **y** pertenece al grupo del curso (DP-06 resuelta) |
| `es_gratuita` | booleano | no | — | — | — | *"las actividades son hasta gratuitas"* (18-jul) |
| `cupo` | entero | no | — | > 0 | — | RN-43 (DP-13 y DP-21 resueltas 2026-08-17): algunas actividades sí tienen cupo. Si está definido, el sistema **avisa** al alcanzarlo; **nunca bloquea** el registro |
| `estado` | enum E-20 | sí | — | — | `PLANIFICADA` | RN-48 (DP-26): la actividad **se crea antes** de registrar participaciones. Sin este campo no se distingue una planificada sin asistentes de una cancelada — y el terremoto de julio-2026 suspendió actividades (`02` §2.1) |
| `registrado_por` / `registrado_en` | ref / fecha_hora | sí | — | — | — | RN-06 |
| `modificado_por` / `modificado_en` | ref / fecha_hora | no | — | — | — | RN-47 |

## 8. ETIQUETA y ACTIVIDAD_ETIQUETA

| Campo | Tipo | Ob. | Validación | Notas |
|---|---|---|---|---|
| `etiqueta.nombre` | texto | sí | Único, normalizado sin espacios sobrantes | RN-15: **la crea el usuario** (18-jul) |
| `etiqueta.creada_por` | ref USUARIO | sí | — | |
| `actividad_etiqueta` | ref + ref | sí | Par único | N:M: *"día de la tierra más algo de arte"* |

Etiquetas nombradas en las fuentes, como semilla, no como enum cerrado: `DIA_DE_LA_TIERRA`,
`DIA_INTERNACIONAL_FILOSOFIA` (FILOART), `DIA_INTERNACIONAL_DEL_ARTE`, `PROTECCION_CIVIL`,
`ECOLOGICA`, `REFORESTACION`, `AYUDA_SOCIAL`, `NINOS`, `ANCIANOS`, `DEPORTE`, `SALUD`, `ANIVERSARIO`,
`CAMPAMENTO` (18-jul, 30-jul).

## 9. CURSO y GRUPO

| Campo | Entidad | Tipo | Ob. | Notas |
|---|---|---|---|---|
| `nombre` | CURSO | texto | sí | Filosofía introductorio (probacionismo), avanzados, curso de instructores |
| `nivel` | CURSO | entero | no | Los avanzados son secuenciales (`01-contexto` §5.1) |
| `curso_prerequisito_id` | CURSO | ref | no | RN-19 |
| `es_probacionismo` | CURSO | booleano | sí | Marca el curso que define "interno" (RN-10) |
| `curso_id` / `sede_id` | GRUPO | ref | sí | |
| `dia_semana` | GRUPO | enum | sí | *"el curso de los lunes"* (18-jul); las hojas del Excel se llaman `MARTES…` y `SABADOS…` |
| `hora` | GRUPO | hora | sí | RN-18 |
| `profesor_persona_id` | GRUPO | ref PERSONA | sí | *"el profesor, el encargado del curso"* (10-jul#2) |
| `fecha_inicio` | GRUPO | fecha | sí | *"nosotros iniciamos en abril"* (18-jul) |
| `fecha_fin` | GRUPO | fecha | no | |

## 10. INSCRIPCION

| Campo | Tipo | Ob. | Validación | Default | Notas |
|---|---|---|---|---|---|
| `persona_id` / `grupo_id` | ref | sí | Par único por edición | — | |
| `estado` | enum E-10 | sí | — | `INSCRITO` | `INSCRITO`, `NO_INSCRITO`, `RETIRADO` (10-jul#2) |
| `fecha_inscripcion` | fecha | sí | — | — | *"la fecha en que se inscribe"* (planilla formal) |
| `fecha_retiro` | fecha | no | > inscripción | — | |
| `clases_asistidas_al_corte` | entero | derivado | ≥ 0 | — | **Solo insumo del informe** (línea "altas de probacionistas después de la tercera clase"). **No dispara** el cambio de estado: la inscripción es siempre manual (DP-05 resuelta). Se calcula contando participaciones en actividades ligadas al grupo (RN-38) |
| `dias_asistencia` / `horarios` | texto | no | — | — | Campos literales de la planilla formal |
| `encargado_persona_id` | ref | no | — | — | Campo "Encargado" de la planilla formal |
| `registrado_por` / `registrado_en` | ref / fecha_hora | sí | — | — | RN-06 |

## 11. PARTICIPACION

| Campo | Tipo | Ob. | Validación | Default | Notas |
|---|---|---|---|---|---|
| `persona_id` / `actividad_id` | ref | sí | **Par único** | — | Evita el duplicado que hoy produce el Excel (P04) |
| `asistio` | booleano | sí | — | `verdadero` | Registro presencial |
| `es_interno_en_la_fecha` | booleano | derivado | — | — | RN-17: congelado a la fecha de la actividad, no recalculado hoy |
| `pago_entrada` | booleano | no | — | — | Punto de extensión: *"se cobra la entrada, eso queda en el registro de economía"* (10-jul#1) |
| `comentario_experiencia` | texto | no | — | — | Columna `COMENTARIO EXPERIENCIA CHARLA` del Excel; presente en 38 de 44 filas (86%) |
| `registrado_por` / `registrado_en` | ref / fecha_hora | sí | — | — | RN-06 |

## 12. ATRIBUCION_CAPTACION

| Campo | Tipo | Ob. | Validación | Notas |
|---|---|---|---|---|
| `persona_id` | ref | sí | — | |
| `actividad_id` | ref | no | — | Se captura por evento: el Excel guarda el medio en cada fila de asistencia |
| `medio_difusion` | enum E-11 (**abierto**) | sí | — | RN-20, RN-21: *"tú puedes crear medios también"* (30-jul) |
| `invitado_por_persona_id` | ref PERSONA | condicional | Requerido si `medio = INVITADO_POR_PERSONA` | **Selector, no texto libre** (30-jul). RN-22 |
| `organizacion_aliada_id` | ref | condicional | Requerido si `medio = ALIANZA` | DP-04 resuelta: la alianza se identifica como entidad propia |
| `es_primera_captacion` | booleano | derivado | Una sola verdadera por persona | La que cuenta para el informe OINA |
| `invitado_por_interno` | booleano | derivado | Del estado de quien invita a esa fecha | RN-44 (DP-18 resuelta): distingue *invitado por un amigo* de *invitado por un acropolitano* sin campo extra |
| `fecha` | fecha | sí | — | |

## 13. ORGANIZACION_ALIADA  ·  confirmada (DP-04, 2026-08-17)

| Campo | Tipo | Ob. | Notas |
|---|---|---|---|
| `nombre` | texto | sí | Observados: `ROTARY` (9), `SPINNING BIKE` (4), `BIBLIOTECA` (1) → **14 de 44 filas** |
| `tipo` | enum E-12 | no | `CLUB_SERVICIO`, `COMERCIO`, `BIBLIOTECA_PUBLICA`, `MEDIO`, `INSTITUCION_PUBLICA` — `[INFERIDO]` |
| `area_custodia_id` | ref AREA | no | Relaciones públicas por defecto |

## 14. CONTACTO_ENLACE  ·  confirmada (DP-08, 2026-08-17) — es la misma `PERSONA`, con permisos aparte

| Campo | Tipo | Ob. | Notas |
|---|---|---|---|
| `persona_id` | ref | sí | Reutiliza `PERSONA`: *"también son contactos que pueden convertirse en los demás"* (30-jul) |
| `area_custodia_id` | ref AREA | sí | RN-28: *"Carlos, como encargado de difusión, solo ve sus contactos de difusión"* |
| `tipo_enlace` | enum E-13 (abierto) | sí | `MEDIO_RADIO`, `MEDIO_TV`, `MEDIO_PRENSA`, `MUSICO`, `FILOARTISTA`, `DANZA`, `TEATRO`, `INSTITUCION_PUBLICA`, `PROVEEDOR` (02-jul, 30-jul) |
| `organizacion` | texto | no | Nombre del medio o agrupación |
| `es_restringido` | booleano | sí | `verdadero` por defecto: *"hay gente del gobierno… no todo el mundo debe tener acceso"* (30-jul) |

## 15. NOTA_FICHA  ·  nueva (decisión 2026-08-17)

Chatter de la ficha: anotación libre, sin canal ni resultado. Convive con `INTERACCION` y ambas se
muestran en una sola bitácora, junto con los cambios de estado.

| Campo | Tipo | Ob. | Validación | Notas |
|---|---|---|---|---|
| `persona_id` | ref | sí | — | |
| `usuario_id` | ref | sí | — | Autor; queda firmado (RN-06) |
| `escrita_en` | fecha_hora | sí | ≤ ahora | Default: ahora |
| `texto` | texto | sí | ≥1 carácter | **Append-only**: no se edita ni se borra (RN-40). Ejemplos dados: *"último seguimiento"*, *"esta persona me bloqueó pero está interesada"* |
| — | — | — | Visibilidad | **Sin notas privadas** (DP-20): las ve cualquier usuario con acceso a la ficha |

## 16. INTERACCION

| Campo | Tipo | Ob. | Validación | Notas |
|---|---|---|---|---|
| `persona_id` | ref | sí | — | |
| `usuario_id` | ref | sí | — | RN-24: quién contactó |
| `canal` | enum E-14 | sí | — | `LLAMADA`, `WHATSAPP`, `MENSAJE_REDES`, `CORREO`, `VISITA` |
| `ocurrio_en` | fecha_hora | sí | ≤ ahora | |
| `resultado` | enum E-15 | no | — | Reemplaza el uso mezclado de `INTERESADO` (P15) |
| `nota` | texto | no | — | Observados: `NO PUEDE POR EL HORARIO`, `FALTA DE TIEMPO` |

Coste de registro: hoy 33 de 36 filas con seguimiento tienen exactamente **1** contacto. Si registrar
cuesta más de un toque, no se registrará.

## 17. INTERES_DECLARADO

| Campo | Tipo | Ob. | Notas |
|---|---|---|---|
| `persona_id` | ref | sí | |
| `linea` | enum E-02 | no | RN-25: *"cultural para allá y filosofía para otro lado"* (30-jul) |
| `tipo_actividad` | enum E-03 | no | *"¿cuál es la que le interesa?"* (10-jul#1) |
| `tema_sugerido` | texto | no | Solo 11 de 44 filas del Excel lo tienen (25%) |
| `interes_curso` | enum E-16 | no | `SI` / `NO` / `SIN_DATO` — recuadro final de la planilla detallada |
| `declarado_en` | fecha | sí | |

**Vigencia (RN-52, DP-30).** El interés vigente es **el último declarado por línea**, no el último en
absoluto. Declarar interés en un concierto no borra el interés en voluntariado — `03` §6 cita *"hay gente
que solo le interesa el voluntariado"* (30-jul). La consulta 7 filtra por el último registro de cada
`(persona, linea)`.

## 18. ~~REFERIDO~~  ·  **entidad eliminada** (DP-32, 2026-08-19)

Un referido **nace como `PERSONA` en estado `CONTACTO`** en el momento en que alguien lo sugiere. No hay
entidad intermedia ni paso de conversión (ID-9 reescrita, RN-23 reescrita).

| Lo que guardaba `REFERIDO` | Dónde vive ahora |
|---|---|
| `nombre` | `PERSONA.nombre` |
| `telefono_1`, `telefono_2` | `PERSONA_CONTACTO` (§1b) |
| `persona_referente_id` | `ATRIBUCION_CAPTACION.invitado_por_persona_id`, con `medio = INVITADO_POR_PERSONA` |
| `persona_creada_id` | Innecesario: la persona ya existe desde el principio |
| `estado_contacto` (un solo enum) | `INTERACCION` — bitácora completa con canal, fecha y resultado |

Motivo: era la entidad con el anclaje más débil del modelo (`[DATO]` de la planilla; nadie la pidió) y un
`CONTACTO` sin cédula **ya es** exactamente nombre + teléfono (ID-3). Colapsarlas le da al referido la misma
bitácora de seguimiento que a todo lo demás, en vez de un enum degenerado sin historial.

Datos observados que se cargarán así: `LEONARDO TORRES`, `KARLA GOMEZ`, `MARIO RICARDO CARRERO`,
`AILE MURILLO` (este último sin teléfono).

## 19. CONSENTIMIENTO_CONTACTO  ·  confirmada (DP-09, 2026-08-17) — **informativo, no bloquea envíos**

| Campo | Tipo | Ob. | Notas |
|---|---|---|---|
| `persona_id` | ref | sí | |
| `acepta` | booleano | sí | *"¿Te gustaría recibir más información de nuestras actividades? SI / NO"* (planilla corta). **Se registra pero no filtra**: RN-12 |
| `otorgado_por_representante` | booleano | sí | Verdadero cuando la persona es menor de edad (RN-37) |
| `fecha` | fecha | sí | |
| `origen` | texto | sí | Planilla de evento, alta en puerta, verbal |
| `revocado_en` | fecha | no | *"hasta que no nos bloquees"* (30-jul) |

## 20. USUARIO, PERMISO_SEDE, PERMISO_AREA

| Campo | Entidad | Tipo | Ob. | Notas |
|---|---|---|---|---|
| `persona_id` | USUARIO | ref | sí | **Todo usuario es antes una persona de la escuela** (RN-50). El guardia de la puerta tiene el suyo porque es miembro y la puerta es su voluntariado (DP-34) |
| `correo` | USUARIO | texto | sí | Único. Vía de acceso base y canal de recuperación de contraseña |
| `hash_contrasena` | USUARIO | texto | condicional | Requerido si no hay `google_sub`. Nunca se almacena la contraseña en claro |
| `google_sub` | USUARIO | texto | no | Identificador de cuenta Google, **atajo opcional** sobre la misma cuenta, enlazado por correo verificado (DP-28). Google **no** puede ser la única vía: excluiría a quien no tenga Gmail y pondría el acceso a los datos de la escuela en manos de un tercero |
| `acceso_global` | USUARIO | booleano | sí | Director nacional y secretaria privada (RN-29) |
| `activo` | USUARIO | booleano | sí | |
| `sede_id` + `nivel` | PERMISO_SEDE | ref + enum E-17 | sí | `LECTURA`, `ESCRITURA`. Milagros necesita Táriba y San Cristóbal (18-jul) |
| `area_id` + `nivel` | PERMISO_AREA | ref + enum E-17 | sí | Habilita ver los contactos-enlace del área (RN-28) |

**Vigencia de los permisos (RN-54, DP-35).** `PERMISO_SEDE` y `PERMISO_AREA` ganan `desde` / `hasta`. El
permiso se sigue otorgando explícitamente — *"cada usuario tendría su grupo de permisos"* (30-jul) — pero el
sistema lo **sugiere** a partir del rol vigente y, **al cerrar un rol**, marca para revisión los permisos
asociados. Sin esto el rol caduca y el acceso no: caso vivo, el relevo de Milagros por Isdrey en relaciones
públicas de San Cristóbal (DP-16).

Regla transversal RN-27: el **alta** de personas es casi universal; la **lectura** es restringida.
DP-08 resuelta: los contactos-enlace se restringen **por área** — Carlos ve los de difusión, Milagros los de relaciones públicas.

## 21. PERIODO_REPORTE  ·  confirmada (DP-10, 2026-08-17) — totales congelados al cerrar

| Campo | Tipo | Ob. | Notas |
|---|---|---|---|
| `sede_id` | ref | sí | Cada sede llena el suyo; Manuelita consolida (30-jul) |
| `anio` / `mes` | entero | sí | Mensual (18-jul) |
| `es_cierre_semestral` | booleano | sí | El reporte se sube semestral |
| `estado` | enum | sí | `ABIERTO`, `CERRADO`, `ENVIADO`, `DEVUELTO` — *"de una vez le devuelven esa vaina"* |
| `totales` | estructura | sí | **Congelados al cerrar el periodo** (DP-10). El informe enviado es reproducible tal como se envió |

---

## 21b. MARCA_REVISION  ·  nueva (DP-36, 2026-08-19)

Guardar nunca se bloquea (RN-46). Lo que falta, es inválido o resulta sospechoso genera una marca
resoluble. Unifica en un solo mecanismo las banderas que `06-calidad-de-datos.md` había inventado solo
para la importación (`TELEFONO_INVALIDO`, `DATO_SOSPECHOSO`, *"cédula pendiente y bandera"*, *"cola de
revisión"*) con las del uso diario del formulario.

| Campo | Tipo | Ob. | Validación | Notas |
|---|---|---|---|---|
| `tipo` | enum E-21 | sí | — | Qué falta o qué se sospecha |
| `persona_id` | ref | condicional | — | Exactamente **una** de las tres referencias debe estar presente |
| `actividad_id` | ref | condicional | — | idem |
| `participacion_id` | ref | condicional | — | idem |
| `detalle` | texto | no | — | Valor original sin transformar cuando aplica: *"el valor original se conserva"* (IMP-04) |
| `origen` | enum | sí | `FORMULARIO`, `IMPORTACION` | Distingue el alta manual de la carga histórica |
| `creada_en` | fecha_hora | sí | ≤ ahora | |
| `creada_por` | ref USUARIO | no | — | Nulo cuando la genera la importación |
| `resuelta_en` | fecha_hora | no | > `creada_en` | `null` = pendiente. **Es la bandeja de pendientes** |
| `resuelta_por` | ref USUARIO | condicional | Requerido si `resuelta_en` | RN-06 |

**Por qué es entidad y no un booleano.** Sin ella, "avisa, no bloquea" es un mensaje que se pierde al
guardar. Con ella es una bandeja de trabajo — que es justo la mitad del formulario que hoy queda vacía: en
el Excel las columnas de intención y seguimiento tienen entre 11% y 25% de llenado.

**Nunca se borra una marca.** Se resuelve. Coherente con RN-41.

---

## 22. Vocabularios controlados

Cada enum: **código estable** (invariable), **etiqueta en español** (visible), y el **valor observado en el
Excel o en las planillas** que mapea a él. `Cerrado` = solo el sistema puede ampliarlo. `Abierto` = el
usuario puede crear valores.

### E-01 · ESTADO_PERSONA — **cerrado**

| Código | Etiqueta | Valor observado que mapea | Traza |
|---|---|---|---|
| `CONTACTO` | Contacto | — (vive hoy en una lista aparte y en WhatsApp) | 30-jul |
| `ASISTENTE` | Asistente | Filas del Excel sin `INSCRITO`; registro de puerta | 30-jul, 10-jul#1 |
| `PROBACIONISTA` | Probacionista | `INTERESADO = INSCRITO ` (7 filas con nombre) | 30-jul |
| `MIEMBRO` | Miembro | — (el Excel no llega a miembro) | 18-jul, 30-jul |
| `INACTIVO` | Inactivo | Relleno **rojo** de celda: *"los que están en rojo… se salieron"* (P14) | 02-jul, 30-jul |

DP-07 resuelta (2026-08-17): `AMIGO_DE_LA_ESCUELA` y `NO_INSCRITO` **no son estados propios** — son `INACTIVO`.
La diferencia operativa (a quién se le sigue invitando) es un atributo, no un estado.

### E-02 · LINEA_ACTIVIDAD — **cerrado**

| Código | Etiqueta | Traza |
|---|---|---|
| `FILOSOFIA` | Filosofía | *"por eso son tres líneas: cultura, filosofía y voluntariado"* (18-jul) |
| `CULTURA` | Cultura | idem |
| `VOLUNTARIADO` | Voluntariado | idem |

### E-03 · TIPO_ACTIVIDAD — **abierto**

| Código | Etiqueta | Valor observado | Traza |
|---|---|---|---|
| `CHARLA` | Charla | 10 eventos del Excel, 8 temas distintos | xlsx, 10-jul#1 |
| `CONFERENCIA` | Conferencia | `EXCELENTE CONFERENCIA` en un comentario | xlsx, OINA |
| `TALLER` | Taller | *"talleres, cursos, seminarios"* | 18-jul |
| `SEMINARIO` | Seminario | idem | 18-jul |
| `CURSO` | Curso | Probacionismo, avanzados, instructores | 10-jul#2 |
| `CONCIERTO` | Concierto | *"en el caso de los conciertos"* | 10-jul#1, 30-jul |
| `ARTETERAPIA` | Arteterapia | *"la arteterapia casi no asiste gente de aquí"* | 02-jul, 18-jul, 30-jul |
| `DANZATERAPIA` | Danzaterapia | — | `01-contexto` |
| `YOGA` | Yoga | *"en el taichí, en el yoga"* | 10-jul#2 |
| `TAICHI` | Taichí | idem | 10-jul#2 |
| `CAFE_CULTURAL` | Café cultural | *"lo del café, lo cultural"* | 18-jul |
| `CAMPAMENTO` | Campamento | *"para nosotros es muy importante el campamento"* | 02-jul, 30-jul |
| `FILOART` | FILOART / Día de la filosofía | *"el día internacional de la filosofía que es el filoar"* — nombre correcto confirmado 2026-08-17 | 18-jul |
| `ANIVERSARIO` | Aniversario | *"el evento de aniversario de Táriba… asistieron 13 personas"* | 30-jul |
| `CAMINATA` | Caminata filosófica | *"el día de la tierra se hizo una caminata"* | 18-jul |
| `JORNADA_VOLUNTARIADO` | Jornada de voluntariado | Donación al centro psiquiátrico, julio | 02-jul, 18-jul |
| `FORMACION_VOLUNTARIOS` | Formación de voluntarios | Campo del informe | OINA |
| `REUNION_CONSEJO` | Reunión de consejo | *"las reuniones de las áreas se llama consejo"* | 18-jul |
| `REUNION_INSTRUCTORES` | Reunión de instructores | Campo del informe | OINA |
| `OTRO` | Otra actividad | *"y otras actividades, si se hacen otras cosas"* | 18-jul |

### E-04 · ROL — **cerrado, ampliable por el sistema**

| Código | Etiqueta | Traza |
|---|---|---|
| `COLABORADOR` | Colaborador | *"tú eres colaborador, yo soy colaboradora"* (30-jul) |
| `ENCARGADO_AREA` | Encargado de área | 30-jul (antes "consejero", 02-jul) |
| `INSTRUCTOR` | Instructor | *"el profe es instructor"* (18-jul, 30-jul) |
| `JEFE_INSTRUCTOR` | Jefe instructor | *"jefe instructor y los demás son miembros"* (30-jul) |
| `CELADOR` | Celador | *"la celaduría es un ejercicio de voluntariado"* (18-jul) |
| `FUERZA_VIVA` | Fuerza viva | Grado con curso propio (10-jul#2, 18-jul) |
| `SECRETARIA` | Secretaría | Campo del informe; Manuelita = secretaria privada (18-jul, 30-jul) |
| `DIRIGENTE` | Dirigente | Campo del informe: *"secretarías, dirigentes, pero esos son como grados"* (18-jul) |
| `DIRECTOR_NACIONAL` | Director nacional | *"el profe puede ver todas, es el director del país"* (18-jul) |

### E-05 · AREA — **abierto**

`RELACIONES_PUBLICAS`, `DIFUSION`, `ESCOLASTICA`, `ECONOMIA`, `BIBLIOTECA`, `INTEGRACION`, `TECNICA`.
Traza: *"condensar todas las áreas: escolástica, integración, relaciones públicas, economía"* (30-jul),
*"el inventario le corresponde al área técnica"* (30-jul), difusión (Carlos, 30-jul).

### E-06 · CIRCULO_ACTIVIDAD — **cerrado** · resuelto en DP-01 (2026-08-17)

Eje de **proximidad**: dónde ocurre la actividad respecto al centro. Aplica a `ACTIVIDAD`; en la persona se
deriva, no se captura.

| Código | N.º | Etiqueta | Qué incluye | Traza |
|---|---:|---|---|---|
| `TERCER_CIRCULO` | 3 | Tercer círculo — cultura | Arteterapia, conciertos, café, charlas inaugurales, probacionismo inicial. *"están nuevitos"* | 18-jul |
| `SEGUNDO_CIRCULO` | 2 | Segundo círculo — filosofía | Curso de filosofía; *"aquí ya entran los miembros"* | 18-jul |
| `PRIMER_CIRCULO` | 1 | Primer círculo — voluntariado | El centro: asume un área, ejercicio fijo de voluntariado, celaduría | 18-jul |

El informe OINA cuenta ingresos por **"actividades de tercer círculo"** usando **este** eje.

### E-06b · CATEGORIA_OINA — **cerrado** · resuelto en DP-01 (2026-08-17)

Eje de **grado de la persona** para el informe internacional. **Se deriva** del estado vigente y de los
roles; no se captura a mano.

| Código | N.º | Etiqueta | Derivación | Traza |
|---|---:|---|---|---|
| `MIEMBROS` | 1 | Miembros | `estado = MIEMBRO` | 18-jul, leyendo la planilla |
| `PROBACIONISMO` | 2 | Probacionismo | `estado = PROBACIONISTA` | idem |
| `FUERZA_VIVA` | 3 | Fuerza viva | rol `FUERZA_VIVA` vigente | idem |

Los dos ejes **no se colapsan**: una actividad de tercer círculo puede tener asistentes de las tres
categorías OINA, y esa es justamente la cifra que pide el informe.
`[PENDIENTE]` menor (DP-01): confirmar con Milagros que la numeración 1/2/3 de la planilla corresponde a
esta categoría y no a otra lectura de los círculos.

### E-07 · OCUPACION — **abierto con catálogo** · DP-17 resuelta (2026-08-17)

Lista de opciones frecuentes más `OTRO` con texto libre, no texto libre puro. El catálogo semilla son los
**19 valores reales** del Excel que sí son ocupaciones (los 2 institucionales salen, ver P19).
21 valores distintos en 44 filas. Frecuencias observadas:

| Valor | Frec. | | Valor | Frec. |
|---|---:|---|---|---:|
| `DOCENTE` | 7 | | `ARQUITECTO` | 1 |
| `ESTUDIANTE` | 5 | | `ASISTENTE` | 1 |
| `JUBILADA` | 5 | | `GASTROENTEROLOGA` | 1 |
| `ABOGADO` | 2 | | `DISEÑADOR` | 1 |
| `COMERCIANTE` | 3 | | `ODONTOLOGO` | 1 |
| `HOGAR` | 2 | | `INSTRUCTORA` | 1 |
| `BIBLIOTECA` ⚠ | 2 | | `GERENTE` | 1 |
| `TRABAJADORA` | 1 | | `PROFESOR DE YOGA` | 1 |
| `CAJERA` | 1 | | `CULTOR` | 1 |
| `GANADERO` | 1 | | `ROTARIA` ⚠ | 1 |
| sin dato | 2 | | | |

⚠ `BIBLIOTECA` y `ROTARIA` **no son ocupaciones**: son procedencia institucional (P19). Al migrar van a
`ORGANIZACION_ALIADA`, no a `ocupacion`. Se conserva género gramatical tal como lo escribe la sede
(`JUBILADA`, `INSTRUCTORA`); normalizar el género es una decisión de negocio, no de datos.

### E-08 · SEDE — **abierto**

`SAN_CRISTOBAL`, `TARIBA`, `EJIDO`, `MERIDA`. *"la idea es que usted abra una filial"* (30-jul).

### E-09 · MOTIVO_FIN_VINCULO — **cerrado**

`TRASLADO_FILIAL` (*"yo puedo trasladar una persona a una filial de otro país"*, 18-jul), `BAJA`, `OTRO`.

### E-10 · ESTADO_INSCRIPCION — **cerrado**

| Código | Etiqueta | Observado | Traza |
|---|---|---|---|
| `INSCRITO` | Inscrito | `INSCRITO ` (con espacio final) | 10-jul#2 |
| `NO_INSCRITO` | No inscrito | — | *"algunos se retiran, quedan como no inscritos"* (10-jul#2) |
| `RETIRADO` | Retirado | Relleno rojo (P14) | 10-jul#2, 02-jul |

### E-11 · MEDIO_DIFUSION — **abierto** `[CONFIRMADO]` que es abierto (30-jul)

Los 9 valores de la validación real del Excel, más los que aparecen en las planillas y en el informe:

| Código | Etiqueta | Valor observado | Frec. (44 filas con nombre) |
|---|---|---|---:|
| `INVITADO_POR_PERSONA` | Invitado por alguien | `INVITADO ` | 28 † |
| `INSTAGRAM` | Instagram | `INSTAGRAM` | 9 ‡ |
| `FACEBOOK` | Facebook | `FACEBOOK` | 3 |
| `LIBRERIA` | Librería / sede | `LIBRERIA` | 2 |
| `AFICHE` | Afiche | `AFICHE` | 1 |
| `WHATSAPP` | WhatsApp | `WHATSAPP` | 1 |
| `RADIO` | Radio | `RADIO` | 0 |
| `TV` | Televisión | `TV` | 0 |
| `YOUTUBE` | YouTube | `YOUTUBE` | 0 |
| `PAGINA_WEB` | Página web | Campo del informe OINA | — |
| `PROPAGANDA` | Propaganda / anuncio pagado | idem | — |
| `ACTIVIDAD_TERCER_CIRCULO` | Actividad de tercer círculo | idem; *"tú ingresaste por una charla de tercer círculo"* | — |
| `ALIANZA` | Vía organización aliada | Registrado hoy dentro de `INVITADO ` + `ROTARY` / `SPINNING BIKE` / `BIBLIOTECA` | 14 † |
| `VALLA_FACHADA` | Vio la sede y entró | *"vio la valla, la pared y entró a preguntar qué era"* (18-jul) | — |
| `OTRO` | Otro | — | — |

† Las 14 filas con `ALIANZA` están **dentro** de las 28 de `INVITADO `: hoy no se distinguen (P20).
‡ Sobre las 61 filas con algún dato serían 14, porque 5 filas fantasma traen `INSTAGRAM` sin persona (P11).

DP-18 resuelta (2026-08-17): la distinción del 10-jul#1 entre *"invitación personal de un amigo"* y
*"invitación de un acropolitano"* **se deriva** del estado de quien invita (`invitado_por_interno`), sin
campo adicional.

### E-12 · TIPO_ORGANIZACION_ALIADA — **abierto** · confirmado en DP-04 (2026-08-17)

`CLUB_SERVICIO` (`ROTARY`, 9 personas), `COMERCIO` (`SPINNING BIKE`, 4), `BIBLIOTECA_PUBLICA`
(`BIBLIOTECA` Táriba, 1), `MEDIO`, `INSTITUCION_PUBLICA`.

### E-13 · TIPO_ENLACE — **abierto**

`MEDIO_RADIO`, `MEDIO_TV`, `MEDIO_PRENSA`, `MUSICO`, `FILOARTISTA`, `DANZA`, `TEATRO`,
`INSTITUCION_PUBLICA`, `PROVEEDOR`.
Traza: *"los contactos de los filoartistas, los de las danzas, teatro… de radio, televisión, de medios"*
(30-jul); *"protección civil, bomberos"* (02-jul).

### E-14 · CANAL_INTERACCION — **cerrado**

`LLAMADA`, `WHATSAPP`, `MENSAJE_REDES`, `CORREO`, `VISITA`.
Traza: *"llamadas y mensajes, ¿cuántas llamadas le hemos hecho?"* (02-jul); *"yo le he enviado flyer y
cosas"* (30-jul).

### E-15 · RESULTADO_CONTACTO — **cerrado**

| Código | Etiqueta | Observado | Frec. |
|---|---|---|---:|
| `INTERESADO` | Interesado | `SI` | 14 |
| `NO_INTERESADO` | No interesado | `NO` (en la validación, **nunca usado**) | 0 |
| `NO_RESPONDIO` | No respondió | `NO RESPONDIO` | 6 |
| `SIN_CONTACTAR` | Sin contactar | celda vacía | 17 |

⚠ La columna `INTERESADO` del Excel mezcla este enum con `E-10` (`INSCRITO `, 7 filas) y con el interés en
el curso. Al migrar se descompone en tres campos (RN-26, P15). **La celda vacía significa "sin dato", no
"no interesado"**: las 11 filas de `MITO DE LA CAVERNA` están vacías y no puede concluirse que no
convirtieron.

### E-16 · INTERES_CURSO — **cerrado**

`SI`, `NO`, `SIN_DATO`. Origen: recuadro final de la planilla detallada
(*"¿Está interesado en hacer el curso? SI / NO"*).

### E-19 · TIPO_CEDULA — **cerrado**

`V` (venezolana), `E` (extranjera). Confirmado 2026-08-17. El Excel no lo trae: al importar se asume `V` y se marca el supuesto.

### E-17 · NIVEL_PERMISO — **cerrado**

`LECTURA`, `ESCRITURA`. **No existe nivel de borrado** porque no existe borrado (RN-41). La fusión de fichas
requiere `ESCRITURA` más acceso a las dos sedes involucradas.

### E-18 · CONTADOR_SEGUIMIENTO — **cerrado, heredado**

Valores `0..5` de la validación del Excel en `LLAMADAS/ MENSAJES`. **No se migra como enum**: se
reemplaza por el conteo real de registros en `INTERACCION`. Se documenta porque explica los datos de
origen (33 filas con `1`, 2 con `3`, 1 con `4`).

### E-20 · ESTADO_ACTIVIDAD — **cerrado** · nuevo en DP-26 (2026-08-19)

| Código | Etiqueta | Notas |
|---|---|---|
| `PLANIFICADA` | Planificada | Valor por defecto: la actividad se crea **antes** de que ocurra (RN-48) |
| `REALIZADA` | Realizada | Ocurrió. Es el estado que cuenta para el informe |
| `CANCELADA` | Cancelada | Caso real: el terremoto de julio-2026 suspendió actividades culturales (`02` §2.1). Sin este valor, una cancelada es indistinguible de una planificada sin asistentes |

### E-21 · TIPO_MARCA_REVISION — **abierto** · nuevo en DP-36 (2026-08-19)

Abierto porque cada regla de saneamiento nueva puede añadir un tipo. Semilla, con su origen:

| Código | Qué señala | Origen |
|---|---|---|
| `CEDULA_FALTANTE` | Persona en `ASISTENTE` o más allá sin cédula | DP-24 · P03 (`FREDDY ORTIZ`) |
| `APELLIDO_FALTANTE` | Sin apellido distinguible | DP-31 · P16 (`MELANY VALENTINA`) |
| `TELEFONO_INVALIDO` | Menos de 10 dígitos o formato no reconocido | P02 (`414718`) |
| `CORREO_INVALIDO` | Sin `@` o con espacios | P05 (`fmpadilla4380gmail.com`), P07 |
| `POSIBLE_DUPLICADO` | Cédula o teléfono normalizado ya existente | DP-29, RN-51 · P04, P08 |
| `DATO_SOSPECHOSO` | Valor incoherente, no corregible automáticamente | P09 (nacimiento = fecha del evento), P10 (cédula/fecha incompatibles) |
| `MENOR_SIN_REPRESENTANTE` | Menor de edad a la fecha de registro sin representante capturado | RN-37 · P25, IMP-13 |
| `PERMISO_SIN_ROL_VIGENTE` | Rol cerrado con permisos aún abiertos | RN-54, DP-35 · caso Milagros → Isdrey (DP-16) |
| `VALOR_FUERA_DE_ENUM` | Valor no reconocido, importado sin rechazar la fila | P13, IMP-28 |
| `REFERENTE_AMBIGUO` | Más de un referente en el mismo campo | P20 (`MILAGRO Y ALEJANDRO`), IMP-18 |

### E-22 · TIPO_CONTACTO_PERSONA — **cerrado, ampliable por el sistema** · nuevo en DP-33 (2026-08-19)

| Código | Etiqueta | Normalización | Traza |
|---|---|---|---|
| `TELEFONO` | Teléfono | 11 dígitos con el `0` inicial (F-3) | Códigos observados: 412, 414, 416, 424, 426 |
| `TELEFONO_INTL` | Teléfono internacional | E.164 con prefijo de país | `+573152993750` (P02) |
| `CORREO` | Correo electrónico | Minúsculas, recortado | 70% de llenado en el Excel |
| `INSTAGRAM` | Instagram | `@usuario` en minúsculas | Campo propio en las tres planillas |
| `FACEBOOK` | Facebook | — | Separado de Instagram en la planilla detallada |
| `OTRA_RED` | Otra red | — | Columna `OTRAS REDES` del Excel, 41% de llenado |

---

## 23. Reglas de formato transversales

| Regla | Contenido |
|---|---|
| **F-1** | Texto sin espacios al inicio ni al final, y sin dobles espacios internos. El Excel los tiene incluso en los valores del enum (`INVITADO `, `INSCRITO `) — P17 |
| **F-2** | Cédula y teléfono son **texto**, nunca numérico: el Excel los guarda como decimal y perdió el cero inicial del teléfono (P01) |
| **F-3** | Teléfono venezolano se almacena normalizado a 11 dígitos con el `0` inicial; los internacionales en E.164 con prefijo de país (P02) |
| **F-4** | Fechas siempre completas (`AAAA-MM-DD`); nunca solo el año |
| **F-5** | Nombres en mayúsculas y minúsculas normalizadas para presentación; la comparación de duplicados ignora acentos, mayúsculas y espacios |
| **F-6** | Todo monto — cuando llegue el módulo de economía — lleva moneda y fecha explícitas. Nunca un número suelto |
| **F-7** | Ningún estado ni clasificación se representa por color: el color del Excel es dato perdido (P14) |
| **F-8** | El valor de contacto se guarda **dos veces**: `valor` tal como se capturó y `valor_normalizado` para buscar y deduplicar. El original nunca se transforma, ni cuando es inválido (IMP-04) |
| **F-9** | Toda marca de tiempo se almacena en **UTC**. La presentación y **todo corte de periodo** usan `SEDE.zona_horaria`, nunca UTC (RN-55, DP-25b) |
| **F-10** | Clave primaria **UUIDv7** en todas las entidades (DP-19): ordenada por tiempo, no filtra conteos, segura de exponer, y soporta fusionar datos de dos sedes o cargas posteriores |
| **F-11** | Toda tabla editable lleva `registrado_por`/`registrado_en` y `modificado_por`/`modificado_en`. Los campos de identidad de `PERSONA` llevan además bitácora completa de cambios (RN-47, DP-25) |
