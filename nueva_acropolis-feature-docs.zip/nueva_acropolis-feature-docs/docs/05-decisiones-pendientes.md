# C. Decisiones pendientes

**Nueva Acrópolis** · 2026-08-17 · Ordenadas por **impacto estructural** en el modelo.
Cada decisión trae la pregunta tal como se le puede hacer a Milagros, por qué importa, las opciones con su
implicación, el **supuesto provisional** adoptado para no bloquear el diseño, y qué habría que rehacer si
la respuesta difiere del supuesto.

Todo lo marcado `[PENDIENTE]` en los documentos A y B aparece aquí.

**Estado al 2026-08-17: DP-01 a DP-21 resueltas.** DP-22 no es una decisión de modelo sino carga de datos.

**Estado al 2026-08-19: DP-19 resuelta y DP-23 a DP-36 añadidas y resueltas** (sesión de modelado,
formulario y stack — ver sección final). Sobreviven dos `[PENDIENTE]`:

1. DP-01, menor: confirmar con Milagros que la numeración 1/2/3 de la planilla OINA corresponde a la
   categoría del informe y no a otra lectura de los círculos.
2. DP-24, nuevo y **no menor**: la obligatoriedad de la cédula desde `ASISTENTE` (RN-02, que Milagros
   afirmó el 30-jul) queda suavizada por decisión de equipo. Requiere que ella lo valide.

Nada abierto condiciona la estructura ni la importación.

---

## DP-01 · Numeración y naturaleza de los círculos — ✅ **RESUELTA (2026-08-17)**

> **Resolución:** **son dos ejes distintos** (opción B, el supuesto provisional). Se mantiene el registro
> de la pregunta y de las opciones para trazabilidad; ya no bloquea el modelo.
> Consecuencia: dos enums separados en el documento B — `E-06 CIRCULO_ACTIVIDAD` (proximidad: 3.º cultura,
> 2.º filosofía, 1.º voluntariado) y `E-06b CATEGORIA_OINA` (1 miembros, 2 probacionismo, 3 fuerza viva).
> Queda `[PENDIENTE]` menor con Milagros: confirmar que el enunciado "1 miembros / 2 probacionismo /
> 3 fuerza viva" del 18-jul es efectivamente la categoría del informe y no otra lectura de los círculos.

> **Pregunta original para Milagros:** cuando dices "tercer círculo" para las charlas y la arteterapia, y la planilla
> de la internacional dice "1 miembros, 2 probacionismo, 3 fuerza viva" — ¿son la misma cosa numerada al
> revés, o son dos clasificaciones distintas que conviven?

**Por qué importa.** El círculo es un eje transversal: clasifica actividades (para contar ingresos por
"actividades de tercer círculo") y también personas (grado de proximidad). Si son dos ejes distintos, son
dos campos; si es uno, la numeración debe fijarse antes de crear cualquier actividad, porque queda grabada
en todo el histórico.

**Evidencia del conflicto** — misma reunión, 18 de julio:
- *"este tercer círculo es cultural… el segundo círculo es filosofía… el primero, el centro, el voluntariado"*
- *"Uno, que es miembros; dos, que es probacionismo; y tres, que es fuerza viva"*

| Opción | Implicación en el modelo |
|---|---|
| **A. Un solo eje, numeración 3→1 hacia el centro** | `ACTIVIDAD.circulo` y `PERSONA.circulo` derivado del estado. Enum de 3 valores |
| **B. Dos ejes distintos** | `ACTIVIDAD.circulo` (proximidad: cultura/filosofía/voluntariado) + `CATEGORIA_OINA` (miembros/probacionismo/fuerza viva) como dimensión del informe. Dos enums, dos conteos |
| **C. El círculo es solo de actividades** | La persona no lleva círculo; se deriva del estado. Enum único, más simple |

**Decisión adoptada: opción B** — confirmada el 2026-08-17. El texto de la planilla y el dibujo de la
reunión responden a preguntas distintas: dónde ocurre la actividad frente a qué grado tiene la persona.

**Efecto en el modelo.** `ACTIVIDAD.circulo_actividad` (eje de proximidad, obligatorio desde ahora) y
`categoria_oina` como dimensión del informe, derivada del estado y del rol de la persona. Ninguna de las
dos se colapsa en la otra, y el conteo de "ingresos por actividades de tercer círculo" del informe usa el
**primer** eje, no el segundo.

---

## DP-02 · Identidad de un contacto sin cédula — ✅ **RESUELTA (2026-08-17)**

> **Resolución:** **Opción A.** No se pide cédula en el estado `CONTACTO`. La identidad descansa en **teléfono + nombre**, y ambos deben servir para buscar a la persona después. Se asume a conciencia que es una clave débil: la fusión de fichas nunca es automática, se propone al usuario (ID-6, ID-7).

> Se conserva abajo el planteamiento original para trazabilidad.

> **Pregunta:** un contacto que solo dejó su teléfono por WhatsApp — si mañana viene a una charla y da su
> cédula, ¿es la misma ficha que actualizamos, o se crea una nueva y luego las unimos? Y si dos personas
> comparten el mismo teléfono (madre e hija, por ejemplo), ¿cómo las distingues hoy?

**Por qué importa.** Define la regla de deduplicación completa. La cédula es la clave declarada
(*"como su ID"*, 18-jul), pero está prohibida en el estado `CONTACTO` (*"a esa persona no le vas a pedir
cédula"*, 30-jul). Sin clave alternativa, la lista de contactos genera duplicados en cada evento.

**Evidencia.** En el Excel hay **dos casos reales de teléfono compartido** entre personas distintas
(`4244394613` → Martha Hernández y Melany Valentina; `4247086411` → Mery Oliva Useche y Belkys Cortés
Useche) y **un correo compartido** por dos personas.

| Opción | Implicación |
|---|---|
| **A. Teléfono como clave débil + fusión asistida** | `CONTACTO` se identifica por teléfono normalizado; al aparecer la cédula se enriquece la ficha. Requiere pantalla de candidatos a duplicado |
| **B. Sin clave: siempre ficha nueva, dedup posterior** | Más simple al registrar, más basura acumulada. Contradice *"no volver a pedirle lo mismo"* |
| **C. Teléfono + nombre como clave compuesta** | Falla con los dos casos reales de teléfono compartido si el nombre está mal escrito |

**Supuesto provisional: opción A.** El teléfono es la única señal disponible en `CONTACTO`, y la fusión
nunca es automática: se propone al usuario (ID-6, ID-7).

**Qué habría que rehacer si difiere.** Si se descarta la fusión asistida, hay que rehacer el flujo de alta
y el proceso de importación de las listas de WhatsApp. Impacto medio; no toca el modelo de entidades.

---

## DP-03 · La sede: atributo de la persona o vínculo con historial — ✅ **RESUELTA (2026-08-17)**

> **Resolución:** **Opción A.** Un solo vínculo activo por persona, con historial. El caso citado —Milagros con acceso a San Cristóbal **y** a Táriba— es un **permiso de usuario** (`PERMISO_SEDE`), no una doble pertenencia de la persona registrada. El traslado cierra un vínculo y abre otro, y así alimenta la línea *altas por traslado de filiales* del informe.

> Se conserva abajo el planteamiento original para trazabilidad.

> **Pregunta:** cuando alguien se traslada de Táriba a San Cristóbal, o a una filial de otro país, ¿deja de
> pertenecer a la sede anterior o queda en las dos? ¿Y en el informe cuenta como baja aquí y alta allá?

**Por qué importa.** Determina la cardinalidad `PERSONA ↔ SEDE` y cómo se cuentan altas y bajas. El informe
OINA tiene una línea específica: *"altas traslado de filiales"*.

| Opción | Implicación |
|---|---|
| **A. `PERSONA_SEDE` con historial, un vínculo activo** | Traslado = cerrar vínculo + abrir otro. El informe deriva las altas por traslado. Permite historia completa |
| **B. `PERSONA.sede_id` plano** | Más simple; **pierde** la historia y hace imposible distinguir traslado de ingreso nuevo |
| **C. Varios vínculos activos simultáneos** | Necesario si alguien pertenece de verdad a dos sedes. Complica todo conteo: hay que evitar doble conteo en el informe consolidado |

**Supuesto provisional: opción A.** Milagros trabaja con dos sedes (*"yo aquí de Táriba tengo que
reportarle… pero tú sí podrías escribir personas en Táriba o San Cristóbal"*, 18-jul), pero eso es un
permiso de **usuario**, no una doble pertenencia de la **persona registrada**.

**Qué habría que rehacer si difiere.** Si es C, hay que revisar todos los conteos del informe para evitar
doble conteo entre sedes, y el rollup de Manuelita cambia de suma simple a suma con deduplicación.
Impacto alto en reportes.

---

## DP-04 · ¿La organización aliada es una entidad? — ✅ **RESUELTA (2026-08-17)**

> **Resolución:** **Opción A.** `ORGANIZACION_ALIADA` existe como entidad propia: debe poder identificarse quién es Rotary, Spinning Bike o la Biblioteca de Táriba, separado de las personas que invitan.

> Se conserva abajo el planteamiento original para trazabilidad.

> **Pregunta:** cuando la gente llega por Rotary, por Spinning Bike o por la biblioteca de Táriba, hoy
> escribes ese nombre en la casilla de "invitado por". ¿Quieres poder contar esas alianzas por separado de
> las personas que invitan?

**Por qué importa.** Es el 32% de la captación real y hoy es indistinguible de una invitación personal.
Sin esta separación, el bucle de atribución (documento `02`, bucle A) no cierra: no se puede saber qué
alianza rinde.

**Evidencia.** De 44 filas con nombre, **14** (→ 12 personas distintas, tras deduplicar las repetidas entre
hojas) tienen una institución en la columna de "invitado por": `ROTARY` 9, `SPINNING BIKE` 4, `BIBLIOTECA` 1. Y en la columna de ocupación aparecen `ROTARIA` y
`BIBLIOTECA` como si fueran oficios (P19).

| Opción | Implicación |
|---|---|
| **A. `ORGANIZACION_ALIADA` como entidad + medio `ALIANZA`** | Se puede medir rendimiento por alianza y ligarla a la actividad. Una entidad más y una migración de 14 filas |
| **B. Una etiqueta de actividad** | Barato, pero no permite contar personas captadas por alianza ni guardar contacto de la institución |
| **C. Reutilizar `CONTACTO_ENLACE`** | Coherente con los contactos de medios, pero mezcla "con quién hablo" y "de dónde vino la gente" |

**Supuesto provisional: opción A**, con la entidad marcada como pendiente y sin diseñar sus atributos
secundarios.

**Qué habría que rehacer si difiere.** Si es B, se elimina la entidad y las 14 filas se remapean a
etiquetas; se pierde la métrica por alianza. Impacto medio, contenido en la atribución.

---

## DP-05 · Umbral de la inscripción firme: 3 o 4 clases — ✅ **RESUELTA (2026-08-17)**

> **Resolución:** **Ninguna de las tres opciones tal como estaban planteadas.** La inscripción **no es automática por número de clases**: ocurre cuando la persona decide y alguien de la escuela la inscribe. El cambio de estado `ASISTENTE → PROBACIONISTA` es siempre **manual**.
> Las cifras de 3 clases (planilla OINA) y 4 clases (18-jul) quedan solo como **corte de reporte**: el contador `clases_asistidas_al_corte` se deriva de las asistencias y sirve para llenar la línea del informe, sin disparar nada.

> Se conserva abajo el planteamiento original para trazabilidad.

> **Pregunta:** para contar a alguien como probacionista de verdad, ¿son tres clases o cuatro? La planilla
> de la internacional habla de "altas después de la tercera clase" y tú me dijiste que "si llevan más de
> cuatro clases se inscriben".

**Por qué importa.** Es el disparador de la transición `ASISTENTE → PROBACIONISTA` y define el corte que
se reporta. Si el sistema usa un umbral distinto al del informe, los números no cuadran — y el descuadre
es justamente lo que hace que devuelvan el informe (RN-31).

| Opción | Implicación |
|---|---|
| **A. Umbral único = 3** | Coincide con el informe; puede adelantar el estado respecto al criterio local |
| **B. Umbral único = 4** | Coincide con el criterio local; el informe necesita un cálculo aparte al corte de la 3.ª clase |
| **C. Dos indicadores: estado local (4) + marca de corte OINA (3)** | Ambos números salen del mismo detalle sin contradecirse. Requiere registrar asistencia por clase — es decir, tocar el borde de escolástica |

**Supuesto provisional: opción C**, registrando solo el contador `clases_asistidas_al_corte` en
`INSCRIPCION`, sin modelar la sesión de clase (que es extensión).

**Qué habría que rehacer si difiere.** Si basta un umbral único, se elimina un campo. Impacto bajo en
estructura, **alto en la credibilidad del informe** si se elige mal.

---

## DP-06 · Granularidad de actividad frente a curso, grupo y sesión — ✅ **RESUELTA (2026-08-17)**

> **Resolución:** **Opción A ampliada.** Las clases sueltas **son actividades** y a la vez **pertenecen al curso**: `ACTIVIDAD.grupo_id` opcional (RN-38). Así se registra a quien asiste sin estar inscrito, y esa asistencia alimenta el corte del informe de DP-05 sin necesidad de modelar todavía la escolástica.

> Se conserva abajo el planteamiento original para trazabilidad.

> **Pregunta:** una clase suelta del curso a la que alguien viene "de prueba" — ¿es una actividad como una
> charla, o es una clase del curso? Lo pregunto porque me dijiste que algunos *"vienen y pagan solo
> clases"* y no están inscritos.

**Por qué importa.** Decide si `PARTICIPACION` cuelga solo de `ACTIVIDAD` o también de una futura
`SESION_DE_CLASE`. Es la frontera exacta entre esta fase y el módulo de escolástica.

| Opción | Implicación |
|---|---|
| **A. Toda asistencia es a una `ACTIVIDAD`; la clase se representa como actividad de línea filosofía** | Un solo camino de asistencia; escolástica luego añade notas y control. Riesgo: muchas actividades repetidas semanales |
| **B. Dos caminos: `ACTIVIDAD` para eventos y `SESION_DE_CLASE` para el curso** | Más limpio a futuro; obliga a decidir ahora algo que pertenece a escolástica |
| **C. Solo eventos en fase 1; la clase suelta se registra como participación en la charla inaugural** | Mínimo esfuerzo; **pierde** el rastro de quien asistió a clases sin inscribirse, que es un caso que ella nombró explícitamente |

**Supuesto provisional: opción A.** No inventa la entidad de escolástica y conserva el caso del asistente
no inscrito.

**Qué habría que rehacer si difiere.** Si es B, se parte `PARTICIPACION` en dos relaciones y se migran las
asistencias de clase. Impacto medio, y crece con el tiempo: conviene resolverlo antes de cargar un semestre
de asistencias.

---

## DP-07 · "Amigo de la escuela" y "no inscrito": ¿estados propios? — ✅ **RESUELTA (2026-08-17)**

> **Resolución:** **Opción A.** Un solo estado `INACTIVO`. "Amigo de la escuela" y "no inscrito" no son estados: la diferencia operativa —a quién se le sigue invitando— es un atributo.

> Se conserva abajo el planteamiento original para trazabilidad.

> **Pregunta:** cuando alguien se retira, tú dijiste que "queda como no inscrito, queda como amigo de la
> escuela". ¿Son dos situaciones distintas para ti, o las dos son simplemente "inactivo"?

**Por qué importa.** Cambia el número de estados de la máquina y, sobre todo, **a quién se le sigue
invitando**. Un "amigo de la escuela" es alguien a quien se invita activamente; un inactivo puede ser
alguien que simplemente dejó de venir.

**Evidencia del conflicto.** 10-jul#2: *"algunos se retiran, quedan como no inscritos, quedan como amigos
de la escuela, o se salen de la escuela"* — tres destinos distintos. 30-jul: los trata casi como
sinónimos de inactivo, y menciona los grupos de WhatsApp de "amigos de la escuela".

| Opción | Implicación |
|---|---|
| **A. Un solo estado `INACTIVO` + atributo "sigue en lista de invitación"** | 5 estados; la diferencia se vuelve un booleano que además conecta con el consentimiento |
| **B. `AMIGO_DE_LA_ESCUELA` como estado propio** | 6 estados; refleja el vocabulario real pero duplica la lógica de invitación |
| **C. Tres estados de salida (`NO_INSCRITO`, `AMIGO`, `RETIRADO`)** | Fiel al 10-jul; probablemente más granular de lo que se usará |

**Supuesto provisional: opción A.** El 30-jul (más reciente) los fusiona, y el criterio de invitación —
lo único que cambia el comportamiento del sistema — se resuelve con un atributo.

**Qué habría que rehacer si difiere.** Añadir estados es barato ahora y caro después: cada estado nuevo
obliga a reclasificar el histórico ya cargado. Impacto medio.

---

## DP-08 · Contactos-enlace: ¿misma entidad Persona o entidad separada? — ✅ **RESUELTA (2026-08-17)**

> **Resolución:** **Opción A.** Es la **misma `PERSONA`**, con marca de enlace y área custodia; así puede convertirse en asistente sin duplicar la ficha.
> **Visibilidad: por área**, confirmado 2026-08-17. Se mantiene lo que dijo Milagros el 30-jul: los ve el
> encargado del área que los custodia (Carlos los de difusión, Milagros los de relaciones públicas) más los
> accesos globales.

> Se conserva abajo el planteamiento original para trazabilidad.

> **Pregunta:** los contactos de radio, de televisión, los músicos, la gente de gobierno — ¿alguna vez
> alguno de ellos ha terminado entrando a la escuela como alumno? Porque si eso pasa, conviene que sean la
> misma ficha.

**Por qué importa.** Ella afirmó las dos cosas en la misma reunión: que son *"otra categoría… tiene más
importancia"* y que *"también son contactos que pueden convertirse en los demás"*, e incluso
*"sí, ya lo he hecho"*. Si son entidades separadas, esa conversión implica duplicar la ficha.

| Opción | Implicación |
|---|---|
| **A. `PERSONA` + registro `CONTACTO_ENLACE` con área custodia y restricción de lectura** | Una sola ficha, convertible. La restricción es de permisos, no de estructura. Es la única compatible con las dos afirmaciones |
| **B. Entidad separada `ENLACE`** | Aísla mejor los datos sensibles (gobierno, medios), pero rompe la conversión y duplica el seguimiento |
| **C. Solo una etiqueta sobre la persona** | Simple, pero la etiqueta no lleva permisos: expondría contactos que ella quiere restringidos |

**Supuesto provisional: opción A.**

**Qué habría que rehacer si difiere.** Si por razones de confidencialidad debe ser B, hay que separar
tablas y decidir qué pasa con el historial de quien se convierte. Impacto medio-alto en permisos.

---

## DP-09 · Consentimiento, menores y borrado — ✅ **RESUELTA por completo (2026-08-17)**

> **Resolución:** tres respuestas.
> **Menores:** si la persona es menor de edad a la fecha de registro se registra **quién es su representante**
> (nombre, teléfono, parentesco) y el consentimiento lo otorga el representante (RN-37).
> **Consentimiento:** se registra pero es **solo informativo** — no bloquea el envío de invitaciones (RN-12).
> **Borrado:** **no se permite borrar a nadie definitivamente** (RN-41). Solo archivar. El bloqueo por parte
> de la persona se registra con fecha como marca informativa (RN-42).
> Nota honesta: esto entra en tensión con la recomendación de `01-contexto` §9 (*borrado a solicitud* para
> datos sensibles). Queda registrado como decisión consciente, no como omisión.

> Se conserva abajo el planteamiento original para trazabilidad.

> **Preguntas (tres, van juntas):**
> 1. La planilla corta pregunta "¿te gustaría recibir más información? SI/NO". Cuando alguien marca NO,
>    ¿se le sigue invitando o no?
> 2. Cuando alguien te bloquea en WhatsApp, ¿eso se anota en algún lado?
> 3. Hay menores de edad en los registros. ¿Se pide autorización de un representante?

**Por qué importa.** Es la base legal y reputacional de todo el seguimiento, que es el corazón del sistema.
Y hay un hecho concreto: en los datos de 2024 hay **dos personas menores de edad al momento del registro**
(nacidas en 2008 y 2009), en una organización que además maneja creencias y participación —
`01-contexto` §9 lo marca como dato sensible.

| Opción | Implicación |
|---|---|
| **A. Consentimiento obligatorio desde `ASISTENTE`, bloquea las listas de invitación** | El campo se vuelve requerido y filtra todo envío. Puede reducir la lista utilizable de golpe |
| **B. Consentimiento informativo, no bloqueante** | No cambia la operación actual; deja el riesgo intacto |
| **C. Obligatorio solo para nuevos registros; los históricos entran como "sin dato"** | Realista para migrar sin frenar la operación; exige un estado `SIN_DATO` explícito |

**Supuesto provisional: opción C**, más un campo `revocado_en` para el bloqueo y una marca de menor de edad
derivada de la fecha de nacimiento. **Ningún dato histórico se asume consentido.**

**Qué habría que rehacer si difiere.** Si es A, hay que capturar consentimiento de los 41 registros
históricos antes de usarlos. Impacto operativo alto, estructural bajo.

---

## DP-10 · Informe OINA: totales congelados o recalculados — ✅ **RESUELTA (2026-08-17)**

> **Resolución:** **Opción A.** Snapshot congelado al cerrar el periodo. El informe enviado es reproducible tal como se envió.

> Se conserva abajo el planteamiento original para trazabilidad.

> **Pregunta:** el informe de un mes que ya enviaste — si después se corrige un dato de ese mes, ¿el informe
> debe seguir mostrando lo que enviaste, o actualizarse?

**Por qué importa.** El requisito duro es el cuadre (*"si uno se pela por uno, de una vez le devuelven esa
vaina"*). Si los totales se recalculan siempre, un dato corregido después hace que el informe ya enviado
deje de coincidir con lo que revisó la internacional.

| Opción | Implicación |
|---|---|
| **A. Snapshot congelado al cerrar el periodo** | El informe enviado es inmutable y auditable; requiere `PERIODO_REPORTE` con totales almacenados y un flujo de cierre |
| **B. Recálculo permanente desde el detalle** | Siempre "verdadero"; imposible reproducir lo que se envió en su momento |
| **C. Snapshot + informe de diferencias** | Lo mejor de ambos; más trabajo |

**Supuesto provisional: opción A**, con el estado del periodo (`ABIERTO`, `CERRADO`, `ENVIADO`,
`DEVUELTO`) y los totales guardados al cerrar.

**Qué habría que rehacer si difiere.** Si es B, desaparece `PERIODO_REPORTE` y los reportes se vuelven
consultas puras. Impacto medio, aislado en el módulo de reportes.

---

## Decisiones de segundo orden

Menos impacto estructural, pero deben resolverse antes de construir la pantalla correspondiente.

| # | Pregunta | Supuesto provisional |
|---|---|---|
| ~~**DP-11**~~ ✅ | ¿El descuento por estatus se marca en fase 1 o espera a economía? | **Resuelto 2026-08-17: espera al módulo de economía.** Fase 1 solo garantiza que el estado vigente sea consultable en la fecha del cobro |
| ~~**DP-12**~~ ✅ | ¿El rol tiene vigencia con historial? | **Sí, con fechas** (2026-08-17). El informe cuenta instructores y dirigentes **activos** |
| ~~**DP-13**~~ ✅ | ¿Las actividades tienen cupo? | **Sí, algunas** (2026-08-17). Campo opcional; el sistema avisa al alcanzarlo. Si además **bloquea** el registro no está decidido (RN-43) |
| ~~**DP-14**~~ ✅ | ¿"Interno/externo" se deriva o se captura? | **Siempre derivado** (2026-08-17): estado `PROBACIONISTA`/`MIEMBRO` **o** cualquier rol vigente. No hay caso donde se marque a mano |
| ~~**DP-15**~~ ✅ | Nombre del evento y significado de "FB" | **Resuelto 2026-08-17: el evento es `FILOART`; "FB" era `FV` = fuerza viva** (Claudia y Jesús son las dos fuerzas vivas de San Cristóbal) |
| ~~**DP-16**~~ ✅ parcial | Nombre de la nueva jefa de área (transcrito "Drake"/"Drac", 30-jul) | **Resuelto 2026-08-17: se llama Isdrey.** Queda pendiente qué permisos y qué área asume |
| ~~**DP-17**~~ ✅ | ¿Ocupación cerrada o libre? | **Lista de frecuentes + "otro"** (2026-08-17). Catálogo semilla: los 19 valores reales del Excel que sí son ocupaciones; los 2 institucionales van a organización aliada |
| ~~**DP-18**~~ ✅ | ¿Importa distinguir *invitado por un amigo* de *invitado por un acropolitano*? | **No como campo**: el sistema mira si quien invitó pertenece a la escuela (RN-44) |
| ~~**DP-20**~~ ✅ | Notas libres en la ficha (chatter): ¿alguna privada? | **Todas visibles** para quien tenga acceso a la ficha (2026-08-17). Append-only, sin edición ni borrado (RN-40) |
| ~~**DP-21**~~ ✅ | El cupo, ¿avisa o bloquea? | **Solo avisa** (2026-08-17). Nunca impide registrar a alguien que llegó (RN-43) |
| **DP-22** | Isdrey asume relaciones públicas de San Cristóbal. ¿Necesita ver Táriba también? | No por ahora. **Carga de datos, no decisión de modelo** |
| ~~**DP-19**~~ ✅ | **Motor de persistencia y stack.** El 30-jul se mencionó "una base de datos SQL relacional" | **Resuelta 2026-08-19: PWA responsive, PostgreSQL, UUIDv7, marcas de tiempo en UTC.** Detalle abajo |

---

## Resumen de urgencia

| Prioridad | Decisiones | Motivo |
|---|---|---|
| ~~Antes de fijar cualquier enum~~ | ~~DP-01~~ ✅ | Dos ejes distintos, confirmado 2026-08-17 |
| **Antes de importar el Excel y las listas de WhatsApp** | ~~DP-02~~ ✅ · ~~DP-04~~ ✅ · **DP-09 parcial** · **DP-17** | Determinan cómo se transforman los datos históricos |
| ~~Antes de construir el alta de personas~~ | ~~DP-03, DP-07~~ ✅ | Un vínculo activo; cinco estados |
| ~~Antes de registrar asistencias en volumen~~ | ~~DP-05, DP-06~~ ✅ | Inscripción manual; la clase suelta es actividad ligada al grupo |
| **Antes del módulo de reportes** | ~~DP-10~~ ✅ · **DP-14** | Definen si el informe es reproducible |
| **Cuando toque cada pantalla** | DP-08, DP-11 a DP-18 | Contenidas en su módulo |
| ~~Fase posterior, fuera de análisis~~ | ~~DP-19~~ ✅ | Resuelta 2026-08-19 |
| **Antes de construir el formulario** | ~~DP-23 a DP-36~~ ✅ | Resueltas 2026-08-19. Solo DP-24 espera validación de Milagros |

---

# Sesión 2026-08-19 — modelado, formulario y stack

Origen: sesión de exploración sobre qué faltaba aclarar para poder modelar la base de datos, una vez
descartado por ahora el informe OINA y el importador del Excel.

**Autoría y confianza.** Las respuestas de esta sesión son del equipo técnico (Javier), no de Milagros.
Se marcan así:

- `[DECISION-EQUIPO]` — el equipo la decide y no necesita a la sede: es técnica, o describe operación ya
  conocida sin contradecir ninguna fuente.
- `[POR-VALIDAR]` — **modifica un requisito que Milagros afirmó**. Vale como supuesto de trabajo, pero
  tiene que confirmarlo ella antes de que se cargue el histórico.

Se aplican los mismos criterios del resto del documento: nada se da por confirmado por plausibilidad.

---

## DP-19 · Motor de persistencia y stack — ✅ **RESUELTA (2026-08-19)** `[DECISION-EQUIPO]`

> **Resolución:** aplicación web **responsive / PWA**, servidor autoritativo, **PostgreSQL** gestionado,
> claves primarias **UUIDv7**, marcas de tiempo en **UTC**.

**Contexto que la desbloqueó.** Uso móvil primero y también de escritorio. La intermitencia de luz e
internet **no** es un condicionante real: se usa desde el teléfono cuando se necesita, con conexión. Eso
elimina la necesidad de operación offline y de sincronización — que era el argumento más fuerte para una
arquitectura local-first.

| Decisión | Por qué, en concreto |
|---|---|
| **PWA responsive**, sin app nativa | Móvil y escritorio con un solo desarrollo. Sin offline, la PWA basta |
| **PostgreSQL** | `03` §1 exige *"consultable por varias personas a la vez"*: Milagros, Manuelita, Carlos e Isdrey en simultáneo. El volumen es irrelevante (41 personas hoy, miles en años); la decisión es por escrituras concurrentes y por las consultas derivadas |
| **Tecnología aburrida y conocida** | El riesgo #1 registrado en `03` §9 es bus factor 1. Un segundo desarrollador tiene que poder retomarlo |
| **UUIDv7** como PK | Habrá fusión de datos: traslado entre filiales, consolidación de Manuelita, cargas de Excel posteriores. Ordenado por tiempo (indexa como entero), no filtra conteos, seguro en URL. El `bigint` secuencial también serviría; el UUID evita un dolor que este caso sí tiene |
| **UTC en almacenamiento** | Ver DP-25b abajo: no es cosmético, afecta el cuadre del informe |

**Fuera de alcance de esta decisión.** Framework, hosting concreto y ORM. No condicionan el modelo.

---

## DP-23 · ¿Existe autorregistro de la persona? — ✅ **RESUELTA (2026-08-19)** `[DECISION-EQUIPO]`

> **Pregunta:** ¿la propia persona puede llenar su formulario (QR en la puerta, enlace de WhatsApp), o
> siempre lo llena un usuario de la escuela?
>
> **Resolución: no existe autorregistro.** Un usuario de Nueva Acrópolis llena el formulario para
> ingresar personas nuevas.

**Por qué importa.** RN-06 exige `registrado_por` en todo registro. Con autorregistro ese campo no podría
ser obligatorio y haría falta una cola de moderación.

**Efecto en el modelo.** Ninguno: `registrado_por` sigue siendo obligatorio en todas las tablas. Nueva
regla **RN-45**.

**Consecuencia operativa que se asume a conciencia.** Sin autorregistro, toda la carga de "ingreso
sencillo" recae en la pantalla de DP-27. Y **la planilla de papel no desaparece**: en un evento de 40
personas alguien teclea en vivo o se transcribe después. El sistema sustituye el **Excel**, no el papel.
El OCR sigue siendo punto de extensión (`03` §8).

---

## DP-24 · Obligatoriedad de la cédula en el alta — ✅ **RESUELTA (2026-08-19)** `[POR-VALIDAR]`

> **Resolución:** el sistema **avisa, no bloquea**. La cédula no impide guardar en ningún estado. Es
> obligatoria **solo en la inscripción a curso**, que es donde la planilla formal la pide.

**Por qué importa y por qué está `[POR-VALIDAR]`.** RN-02 dice hoy *"la cédula es obligatoria desde
`ASISTENTE`"*, y está marcada `[CONFIRMADO]` con el 30-jul (*"el guardia de seguridad sí pide cédula"*).
Esta decisión la **suaviza**, y eso es un cambio de criterio, no una precisión.

**Evidencia a favor del cambio.** La planilla corta (formato 2 de `planillas_inscripcion.md`) **no pide
cédula** y produce un asistente. En los datos reales, `FREDDY EDUARDO ORTIZ ACEVEDO` es asistente sin
cédula (P03), y `06-calidad-de-datos.md` ya lo trata blando: *"importar como `ASISTENTE` con cédula
pendiente y bandera de dato faltante; no bloquear la carga"*.

**Efecto en el modelo.** `cedula` queda nullable en todo estado. La falta genera una `MARCA_REVISION`
(DP-36). RN-02 se reescribe; nueva regla **RN-53**.

**Qué habría que rehacer si Milagros lo rechaza.** Si exige cédula desde `ASISTENTE`, el alta de la puerta
pasa a tener tres campos obligatorios en vez de dos y hay que decidir qué se hace con quien no la lleva
encima. Impacto bajo en estructura, alto en el flujo de la puerta.

---

## DP-25 · Auditoría de modificación — ✅ **RESUELTA (2026-08-19)** `[DECISION-EQUIPO]`

> **Resolución:** se guarda **quién modificó por última vez y cuándo**, en toda tabla editable. Además,
> **bitácora completa de cambios en los campos de identidad de `PERSONA`** (cédula, nombre, apellido,
> teléfonos).

**Por qué importa.** El modelo tenía auditoría de **creación** (`registrado_por`, `registrado_en`, RN-06)
y **cero** auditoría de modificación. Con el guardia registrando en la puerta, los errores son certeza.

**Por qué la mezcla y no solo el último modificador.** El último-modificador pierde lo de en medio, y eso
es inconsistente con el resto del modelo, que es append-only para estados y notas. Pero la bitácora
completa en todo es caro y poco útil. Los campos de identidad son los únicos donde una edición equivocada
rompe en silencio la identidad y el deduplicado (ID-1, ID-6) — y son pocos.

**Efecto en el modelo.** Columnas `modificado_por` / `modificado_en` transversales. Nueva regla **RN-47**.

---

## DP-25b · Zona horaria — ✅ **RESUELTA (2026-08-19)** `[DECISION-EQUIPO]`

> **Resolución:** almacenar en **UTC**; presentar y **calcular todo corte de periodo** en la zona horaria
> de la sede. Nace `SEDE.zona_horaria`.

**Por qué no es cosmético.** Venezuela es UTC−4 sin horario de verano, así que parece inofensivo. Pero las
actividades son **vespertinas** (`01-contexto` §5.1: ~1 clase semanal de 2 h, horario vespertino). Una
charla el día 31 a las 20:00 local es el **día 1 a las 00:00 UTC**. Si el corte mensual del informe se
calcula en UTC, esa actividad cae en el mes siguiente y el informe descuadra por uno — exactamente lo que
RN-31 dice que hace que la internacional lo devuelva.

**Efecto en el modelo.** `SEDE.zona_horaria` obligatoria. Nueva regla **RN-55**.

---

## DP-26 · Momento de creación de la actividad — ✅ **RESUELTA (2026-08-19)** `[DECISION-EQUIPO]`

> **Resolución:** la actividad **se crea antes** de registrar participaciones.

**Efecto en el modelo.** Aparece `ACTIVIDAD.estado` — `PLANIFICADA`, `REALIZADA`, `CANCELADA` — campo que
no existía. Sin él no se distingue una actividad planificada con 0 asistentes de una cancelada, y hay caso
real: el terremoto de julio-2026 suspendió actividades culturales (`02` §2.1). Enum nuevo **E-20**.
Nueva regla **RN-48**.

**Efecto en la aplicación.** La pantalla de entrada al registro pasa a ser la lista de actividades
próximas, no el alta de personas.

---

## DP-27 · Cómo entra una mesa de asistentes — ✅ **RESUELTA (2026-08-19)** `[DECISION-EQUIPO]`

> **Resolución:** una sola pantalla por actividad, donde se agregan **tanto personas ya registradas**
> (miembros, amigos de la escuela, asistentes previos) **como personas nuevas**. Búsqueda por nombre,
> cédula o teléfono; si no aparece, alta mínima en el sitio.

**Por qué importa.** Es la respuesta al dolor ardiente. IMP-25 lo muestra en los datos: 1 actividad con 14
participaciones, no 14 altas independientes. Y el formulario persona-por-persona completo (14 × 12 campos)
es exactamente lo que hoy no se hace.

**Efecto en el modelo: ninguno.** `PARTICIPACION` con par único `(persona, actividad)` ya lo soporta.
Nueva regla **RN-49**.

**Lo que esta pantalla produce sola**, y por eso es la de mayor palanca del sistema:
`PARTICIPACION` · el alta mínima de DP-31 · `ATRIBUCION_CAPTACION` con medio y quién invitó **por evento**
(bucle A, el requisito de mayor intensidad del análisis: I=20.07) · `es_interno_en_la_fecha` sin preguntar
nada (RN-17, que es la cifra del informe) · las marcas de DP-36 · y la única transición automática de la
máquina de estados (`CONTACTO → ASISTENTE`).

---

## DP-28 · Autenticación de usuarios — ✅ **RESUELTA (2026-08-19)** `[DECISION-EQUIPO]`

> **Resolución:** **correo + contraseña** como vía base, y **Google (Gmail) como atajo opcional** sobre la
> misma cuenta, enlazado por correo verificado. Serán varios usuarios: encargados de área, el director, el
> guardia (DP-34).

**Por qué Google no puede ser la única vía.** Excluye a quien no tenga Gmail — el guardia, por ejemplo — y
pone el acceso a los datos de la escuela en manos de un tercero. Como atajo sí aporta: quita la gestión de
contraseñas a quien ya tiene cuenta.

**Efecto en el modelo.** `USUARIO` gana credenciales. `USUARIO.persona_id` sigue obligatorio: **todo
usuario es antes una persona de la escuela**, lo que hace que crear un usuario sean dos pasos — conviene
que el formulario los junte en un solo flujo. Nueva regla **RN-50**.

---

## DP-29 · Detección de duplicados en el alta — ✅ **RESUELTA (2026-08-19)** `[DECISION-EQUIPO]`

> **Resolución:** al crear una persona se valida si **la cédula** o **algún teléfono normalizado** ya
> existe, y se lanza la advertencia de que puede estar ya registrada. **La advertencia no impide guardar.**

**Dos niveles, no uno.** Cédula igual = casi seguro la misma persona (ID-1). Teléfono igual = puede ser
familiar: hay dos casos reales en los datos (P08: madre/hija, hermanas). Misma conducta no bloqueante,
distinto texto de aviso.

**Efecto en el modelo.** Exige índice sobre valor normalizado de teléfono → **confirma DP-33**. La fusión
sigue sin ser automática (ID-6, ID-7). Nueva regla **RN-51**.

---

## DP-30 · Vigencia del interés declarado — ✅ **RESUELTA (2026-08-19)** `[DECISION-EQUIPO]`

> **Resolución:** vale **el último declarado por línea** (`FILOSOFIA` / `CULTURA` / `VOLUNTARIADO`), no el
> último en absoluto.

**Por qué el matiz.** `INTERES_DECLARADO` es 1:N con fecha, y la consulta 7 (*"a quién invito al próximo
concierto"*) necesita saber cuál vale. El último absoluto borra información: quien declara interés en
voluntariado en marzo y en un concierto en junio perdería el voluntariado — y `03` §6 cita justamente
*"hay gente que solo le interesa el voluntariado"* (30-jul). Por línea, ambas señales sobreviven.

**Efecto en el modelo.** Ninguno estructural; cambia la consulta y la lectura del formulario. Nueva regla
**RN-52**.

---

## DP-31 · Campos obligatorios del alta — ✅ **RESUELTA (2026-08-19)** `[DECISION-EQUIPO]`

> **Resolución:** obligatorios **nombre y teléfono**. Todo lo demás opcional, salvo la cédula en la
> inscripción a curso (DP-24).

**Efecto en el modelo, que corrige a `04`.** `apellido` deja de ser requerido desde `ASISTENTE`. Eso encaja
con los datos reales: `MELANY VALENTINA` no tiene apellido distinguible (P16). La falta de apellido genera
`MARCA_REVISION`, no un bloqueo. Nueva regla **RN-53**.

---

## DP-32 · `REFERIDO` como entidad propia — ✅ **RESUELTA (2026-08-19)** `[DECISION-EQUIPO]`

> **Resolución:** **se elimina la entidad.** Un referido nace directamente como `PERSONA` en estado
> `CONTACTO`, con `ATRIBUCION_CAPTACION` apuntando a quien lo refirió.

**Por qué.** Era la entidad con el anclaje más débil del modelo (`[DATO]` de la planilla; nadie la pidió) y
duplicaba lo que ya existe:

| `REFERIDO` | ≈ | Lo que ya hay |
|---|---|---|
| `nombre` | | `PERSONA.nombre` |
| `telefono_1`, `telefono_2` | | `PERSONA_CONTACTO` (DP-33) |
| `persona_referente_id` | | `ATRIBUCION_CAPTACION.invitado_por_persona_id` |
| `estado_contacto` (un solo enum) | | `INTERACCION` — bitácora completa con canal, fecha y resultado |

Un `CONTACTO` sin cédula **ya es** exactamente nombre + teléfono (ID-3). Colapsarlos elimina una entidad,
elimina el paso de conversión de ID-9, y le da al referido la misma bitácora de seguimiento que a todo lo
demás en vez de un enum degenerado sin historial.

**Efecto en el modelo.** Fuera `REFERIDO` de `03` §3.1/§3.2/§3.3 y de `04` §18. RN-23 e ID-9 reescritas.

---

## DP-33 · Teléfonos y redes: columnas o tabla hija — ✅ **RESUELTA (2026-08-19)** `[DECISION-EQUIPO]`

> **Resolución:** **tabla hija** `PERSONA_CONTACTO(tipo, valor, valor_normalizado, es_principal)`.

**Por qué.** Hoy son 6 columnas: `telefono_principal`, `telefono_secundario`, `telefono_internacional`,
`instagram`, `facebook`, `otras_redes`. RN-39 pide buscar por teléfono e ID-6 deduplicar por teléfono
normalizado: con tres columnas eso son tres comparaciones por par de fichas. Una tabla hija resuelve
búsqueda, deduplicado y el `+57` de P02 con un solo índice. Enum nuevo **E-22**.

---

## DP-34 · ¿Quién registra en la puerta? — ✅ **RESUELTA (2026-08-19)** `[DECISION-EQUIPO]`

> **Resolución:** el guardia **tiene usuario propio**, porque es **miembro de la escuela y la puerta es su
> voluntariado**. No hace falta cuenta compartida ni anónima.

**Por qué era una contradicción.** DP-23 dice que solo un usuario puede dar de alta, y DP-28 enumera como
usuarios a encargados de área y al director — pero RN-27 cita a Milagros: alta *"desde seguridad hasta
desde la secretaría"*. La salida no es relajar la auditoría: es que el guardia también es de la escuela.

**Efecto en el modelo.** Ninguno nuevo, y confirma el patrón: `PERSONA` con `ROL_ASIGNADO` → `USUARIO` →
`PERMISO_SEDE`. `registrado_por` queda nominal, no genérico. Nueva regla **RN-50**.

---

## DP-35 · Vigencia de los permisos — ✅ **RESUELTA (2026-08-19)** `[DECISION-EQUIPO]`

> **Resolución:** el permiso se sigue **otorgando explícitamente** (como dijo Milagros), el sistema lo
> **sugiere** a partir del rol vigente, y **al cerrar un rol marca para revisión** los permisos asociados.

**El agujero que cierra.** `ROL_ASIGNADO` tiene `desde`/`hasta` (DP-12: los roles tienen vigencia).
`PERMISO_SEDE` y `PERMISO_AREA` **no tienen fechas**. Caso vivo: Milagros deja relaciones públicas de San
Cristóbal, Isdrey lo asume (DP-16) — y Milagros sigue leyendo todo para siempre, porque el rol caducó y el
permiso no.

| Opción | Implicación |
|---|---|
| Permiso derivado del rol vigente | Cero mantenimiento, pero contradice *"cada usuario tendría su grupo de permisos"* (30-jul) |
| Permiso explícito con `desde`/`hasta` | Respeta lo que ella dijo; hay que acordarse de poner la fecha |
| **Explícito + sugerido + marca al cerrar el rol** | Mantiene el otorgamiento manual y avisa solo. Reusa el patrón *avisa, no bloquea* |

**Efecto en el modelo.** Nueva regla **RN-54**. Resuelve además la mitad viva de DP-16 sin preguntar nada.

---

## DP-36 · La marca de revisión como concepto de primera clase — ✅ **RESUELTA (2026-08-19)** `[DECISION-EQUIPO]`

> **Resolución:** nace la entidad **`MARCA_REVISION`**. Guardar nunca se bloquea; lo que falta o es dudoso
> genera una marca resoluble, no un error.

**De dónde sale.** DP-24, DP-29 y DP-31 dicen tres veces lo mismo: *guarda siempre, avisa después*. Y
`06-calidad-de-datos.md` ya lo había inventado ad hoc, pero **solo para la importación**:
`TELEFONO_INVALIDO`, `DATO_SOSPECHOSO`, *"cédula pendiente y bandera de dato faltante"*, *"cola de
revisión"*. Con DP-24 eso pasa a ser también del uso diario, así que deja de ser un detalle del importador
y se vuelve parte del núcleo.

**Por qué importa más de lo que parece.** Sin la entidad, "avisa, no bloquea" es un mensaje que se pierde
al guardar. Con ella es una **bandeja de pendientes** — que es justo la mitad del formulario que hoy queda
vacía: en el Excel las columnas de intención y seguimiento tienen entre 11% y 25% de llenado.

**Efecto en el modelo.** Entidad nueva en `03` §3.1 y `04`; enum nuevo **E-21**. Nueva regla **RN-46**.
Unifica el mecanismo de la importación (`06`) con el del formulario.

---

## Resumen de la sesión 2026-08-19

| # | Decisión | Efecto estructural |
|---|---|---|
| DP-19 | PWA · PostgreSQL · UUIDv7 · UTC | Desbloquea construir |
| DP-23 | Sin autorregistro | `registrado_por` sigue obligatorio |
| **DP-24** | Cédula avisa, no bloquea | **`[POR-VALIDAR]` con Milagros** · reescribe RN-02 |
| DP-25 | Último modificador + bitácora de identidad | Columnas transversales |
| DP-25b | UTC + corte en zona de sede | `SEDE.zona_horaria` |
| DP-26 | Actividad antes | `ACTIVIDAD.estado`, enum E-20 |
| DP-27 | Pantalla mixta existentes + nuevos | Ninguno |
| DP-28 | Correo/contraseña + Google opcional | Credenciales en `USUARIO` |
| DP-29 | Aviso por cédula o teléfono | Índice normalizado |
| DP-30 | Último interés por línea | Ninguno |
| DP-31 | Nombre + teléfono obligatorios | `apellido` opcional |
| DP-32 | Fuera `REFERIDO` | **Una entidad menos** |
| DP-33 | `PERSONA_CONTACTO` | **Una entidad más**, seis columnas menos |
| DP-34 | El guardia tiene usuario | Ninguno |
| DP-35 | Permiso explícito + marca al cerrar rol | Cierra DP-16 |
| DP-36 | `MARCA_REVISION` | **Una entidad más** |

Balance de entidades: 22 → 23 (−`REFERIDO`, +`PERSONA_CONTACTO`, +`MARCA_REVISION`).

**Único pendiente que condiciona la operación: DP-24.** Todo lo demás está cerrado.

---

## DP-37 · Proveedor: Supabase — ✅ **RESUELTA (2026-08-19)** `[DECISION-EQUIPO]`

> **Resolución:** **Supabase** como plataforma (PostgreSQL gestionado + Auth + RLS + API generada).
> Precisa DP-19, no la contradice. Esquema físico completo en `07-esquema-fisico.md`.

**Por qué encaja con este modelo en concreto**, más allá de ser Postgres gestionado:

| Requisito | Qué aporta |
|---|---|
| DP-28: correo/contraseña + Google como atajo, con recuperación | Auth incluido. Resuelve la decisión completa |
| RN-27 a RN-30: escritura de alta casi abierta, **lectura restringida por sede y área** | Es un problema de *row-level security*. Declarativo en la base, no en código de aplicación |
| RN-40, RN-01: `notas_ficha` y `estados_persona` append-only | Se expresa quitando las políticas de UPDATE y DELETE |
| DP-03: un solo vínculo de sede vigente | Índice único parcial. El invariante lo garantiza el motor |
| RN-55: UTC con corte en zona de sede | `timestamptz`, cero fricción |
| Bus factor 1 | Sin operaciones que mantener, y stack muy conocido |

**El riesgo, declarado.** PostgREST **expone cada tabla por HTTP**. Lo único que la protege es la RLS, y
`01-contexto` §9 exige no exponer listados de personas ni su nivel de vínculo, sobre datos que incluyen
creencias, participación y **dos menores de edad reales**. Una política mal escrita no es un error de
negocio: es una filtración en un endpoint público.

Mitigaciones, obligatorias y no negociables (`07` F10, §8):
RLS activada en **todas** las tablas · `REVOKE ALL` al rol anónimo · `service_role` solo en servidor ·
**registro público desactivado** (Supabase lo trae activo, y eso violaría RN-50) ·
`security_invoker = on` en las diez vistas, o se saltan la RLS · cada política es un caso de prueba.

**Decisiones que arrastra**, todas en `07`: `usuarios` es tabla propia en `public` con clave ajena a
`auth.users`, nunca se escribe en el esquema `auth` (F9); dos denormalizaciones obligadas por el
rendimiento de la RLS, `personas.sede_vigente_id` y `participaciones.sede_id` (F5), que son la única
excepción consciente a D2 de `design.md`.

**Pendientes de verificación en el proyecto real** (`07` §12): versión de Postgres y `uuidv7()`,
disponibilidad de `btree_gist` y `unaccent`, comportamiento del plan gratuito ante inactividad, región más
cercana, y que el medio de pago en dólares sea sostenible por la organización.

**Qué habría que rehacer si se abandona Supabase.** Los datos son portables (`pg_dump`): el esquema, los
constraints, los triggers y las vistas se mueven enteros. Lo que se rehace es la autenticación y la RLS como
frontera de seguridad, que pasaría a ser un backend propio. Acoplamiento moderado, concentrado en dos
piezas.
