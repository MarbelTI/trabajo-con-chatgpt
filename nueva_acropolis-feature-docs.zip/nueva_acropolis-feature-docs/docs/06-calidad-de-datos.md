# D. Hallazgos de calidad de datos

**Fuente analizada:** `REGISTRO PARTICIPANTES TARIBA (1).xlsx` — datos reales, no esquema.
2 hojas · 20 columnas rotuladas · **44 filas con nombre → 41 personas distintas** · 61 filas con algún dato
· rango de fechas **2024-04-09 … 2024-09-28** · 10 eventos · 8 temas de charla.

> ### ⚠ El archivo de origen ya no está en el repositorio (2026-08-19)
>
> Se retiró de `docs/` por contener **datos personales identificados**: 41 personas con cédula, teléfono,
> correo y fecha de nacimiento, **incluidos dos menores de edad** al momento del registro (P25). Es
> exactamente lo que `01-contexto` §9 clasifica como dato sensible, y el repositorio no es el lugar para
> custodiarlo.
>
> **Ubicación de la copia congelada: `[PENDIENTE de registrar aquí]`.** Sin ese dato, la recomendación M-3
> de §5 —congelar una copia antes de tocar el original— queda sin destino verificable, y este proyecto ya
> perdió un Excel completo una vez (*"ahora sí se borró completamente"*, 30-jul).
>
> **Qué sigue siendo válido, que es casi todo.** El análisis de abajo se hizo sobre el archivo y no depende
> de que siga presente: las 25 patologías, sus reglas de saneamiento y los 30 casos de prueba `IMP-xx` son
> conclusiones cerradas. Las trazas `xlsx` de `03` y `04` —frecuencias, valores observados, catálogos
> semilla— siguen siendo correctas.
>
> **Qué ya no se puede hacer desde el repositorio**, y hay que decirlo: reproducir el análisis, verificar
> una frecuencia discutida, y sobre todo **extraer los colores de celda** (P14), que es la patología más
> peligrosa porque el estado vive en el relleno rojo y verde y desaparece en cualquier exportación plana.
> Si llega el momento del importador, hace falta el archivo original, no un CSV.
>
> **Nota histórica:** el archivo estuvo versionado entre `54d9b2a` (2026-08-16) y `a329c30` (2026-08-19).
> Ausente en `HEAD` **no significa ausente del repositorio**: sigue recuperable desde esos commits. Si el
> objetivo es que no exista en el historial, requiere reescritura (`git filter-repo` o BFG) y push forzado.
> Decisión pendiente.

Cada patología trae su **regla de saneamiento** propuesta y los **casos de prueba de importación** que
genera (`IMP-xx`). Las reglas son propuestas de análisis, no implementación.

---

## 1. Panorama del archivo

**Estructura.** Dos hojas con encabezados idénticos: `MARTES TÁRIBA BILBIOTECA` (39 filas con nombre) y
`SABADOS SPINNING BIKE` (5 filas con nombre + 17 filas fantasma). El nombre de la hoja codifica **día
recurrente + lugar**, no periodo ni curso, y no existe columna de sede ni de lugar.

**Completitud por columna** (sobre las 44 filas con nombre):

| Columna | Lleno | Columna | Lleno |
|---|---:|---|---:|
| FECHA | 100% | INVITADO POR (col. K) | 64% |
| TEMA DE LA CHARLA | 100% | COMENTARIO EXPERIENCIA | 86% |
| NOMBRE/APELLIDO | 100% | TEMAS SUGERIDOS | **25%** |
| CEDULA | 98% | LLAMADAS/MENSAJES | 82% |
| NUMERO DE TELEFONOS | 100% | COMENTARIOS DE LLAMADA | 16% |
| OCUPACION | 95% | NOMBRE INVITADOS SUGERIDOS | **18%** |
| FECHA NACIMIENTO | 95% | TELEFONOS DEL INVITADO | 14% |
| E-MAIL | 70% | LLAMADAS AL INVITADO | 11% |
| OTRAS REDES | 41% | COMENTARIOS DEL INVITADO | **0%** |
| POR CUAL MEDIO DE DIFUSION | 100% | INTERESADO | **61%** |

Lectura: la **captura de identidad es buena** (95–100%), la **captura de intención y de seguimiento es
pobre** (11–25%). El sistema debe atacar la segunda mitad de la planilla, que es justamente la que alimenta
los bucles de captación y seguimiento.

**Volumen de la migración de fase 1.** 41 personas, 10 actividades, ~44 participaciones, ~36 interacciones
de un solo toque, 14 atribuciones vía alianza, 5 referidos. A esto se suman, fuera de este archivo y sin
cuantificar: *"otra lista"* de contactos, los grupos de WhatsApp, las planillas en papel de 2024 hacia
atrás, el Excel de asistencia y el de Manuelita — y un **Excel grande que ya se perdió**
(*"ahora sí se borró completamente"*, 30-jul).

---

> **Actualización 2026-08-19.** Las banderas que este documento inventa por su cuenta —
> `TELEFONO_INVALIDO`, `DATO_SOSPECHOSO`, *"cédula pendiente y bandera de dato faltante"*, *"cola de
> revisión"* — dejan de ser un mecanismo exclusivo del importador. DP-36 las convierte en la entidad
> `MARCA_REVISION` del núcleo (`04` §21b, enum E-21), compartida con el alta manual: **guardar nunca se
> bloquea, lo que falta genera una marca resoluble** (RN-46). Las reglas de saneamiento de abajo no
> cambian; cambia dónde aterrizan sus banderas, que ahora llevan `origen = IMPORTACION`.

---

## 2. Patologías

### Tipos y formatos

| # | Patología | Evidencia | Regla de saneamiento |
|---|---|---|---|
| **P01** | Cédula y teléfono almacenados como número decimal | 100% de las filas: `27634020.0`, `4124302480.0` | Convertir a texto sin decimales; el teléfono recupera el `0` inicial perdido |
| **P02** | Teléfono fuera de formato nacional | `573152993750` (12 dígitos, prefijo Colombia `+57`) y `414718` (6 dígitos, truncado) | Si empieza por `57`, guardar como internacional E.164. Si tiene menos de 10 dígitos, **no adivinar**: importar con marca `TELEFONO_INVALIDO` para revisión manual |
| **P03** | Cédula vacía en fila con nombre | `FREDDY EDUARDO ORTIZ ACEVEDO` (1 de 44) | Importar como `ASISTENTE` con cédula pendiente y bandera de dato faltante; no bloquear la carga |
| **P05** | Correo sin `@` | `fmpadilla4380gmail.com` (Francisco Padilla) | Detectar el patrón `\d+gmail\.com` y proponer la corrección con `@`; requiere confirmación humana, no autocorrección |
| **P07** | Correo con espacio final | `lyndahadgialy@gmail.com ` | Recortar espacios en todos los campos de texto |
| **P17** | Espacios sobrantes generalizados, **incluso en los valores del enum** | **154 valores de texto** con espacios al inicio o al final, entre ellos los propios valores de la validación: `INVITADO `, `INSCRITO ` | Normalizar al importar; los enums se mapean por valor recortado |
| **P16** | Nombre y apellido en una sola columna | `MELANY VALENTINA` (sin apellido distinguible), `LILIA PADILLA DE LOBO` (apellido de casada), `ROSA ELENA LUNA DE RAMIREZ` | Separar por heurística **con revisión**: primer token = nombre, resto = apellido; marcar los casos con `DE` y los de un solo apellido para verificación |
| **P18** | Un solo campo de teléfono aunque la planilla pide dos | La planilla detallada tiene `N° de Teléfonos` con espacio para dos; el Excel tiene una columna | Importar a `telefono_principal`; el secundario queda vacío |

### Fechas

| # | Patología | Evidencia | Regla de saneamiento |
|---|---|---|---|
| **P09** | Fecha de nacimiento igual a la fecha del evento | `JHOAN MORIAN` → `2024-04-05` (el evento fue el 2024-04-09) | Descartar el valor, dejar `fecha_nacimiento` nula y marcar `DATO_SOSPECHOSO`. **No inferir la edad** |
| **P10** | Fecha de nacimiento incoherente con el rango de la cédula | `IRAIDA MONCADA`: cédula 18.019.467 (emisión típica ~1986-88) con nacimiento `1937-10-20` | Marcar para verificación; no corregir. La cédula manda como identificador, la fecha queda en duda |
| **P24** | Fecha de nacimiento ausente | 2 de 44 (`DARIANA BAEZ`, `ELEIDA MORA`) | Importar nula. Consecuencia directa: esas personas **no aparecerán en la vista de cumpleaños** (RN-35) |
| **P25** | **Menores de edad en el registro** | `MELANY VALENTINA` (nac. 2008-12-26, 15 años al registrarse) y `FRANKLIN RAMIREZ` (nac. 2009-05-06, 14 años) | Derivar `es_menor_de_edad` a la fecha del registro y marcar ambos para revisión de consentimiento (DP-09). No es un error de datos: es un hallazgo de cumplimiento |

### Identidad y duplicación

| # | Patología | Evidencia | Regla de saneamiento |
|---|---|---|---|
| **P04** | **Duplicación de personas entre hojas** | 3 personas con cédula y teléfono idénticos en ambas hojas, todas del evento `LIDERAZGO` del 2024-09-21: `JOSE GREGORIO WOVER CEDEÑO` (17422710), `LUISANA MAZZEI RAMIREZ` (16981999), `WILMER DAVID RINCON` (14896601) | Deduplicar por cédula → **una persona, una sola participación** en la actividad del 21-09. Causa raíz: la hoja no es una entidad; el evento sí (P22) |
| **P06** | Correo compartido por dos personas distintas | `jempresarymc@gmail.com` → `JOSE GUTIÉRREZ` (cédula 10826646) y `JHOAN MORIAN` (30616684) | Permitido: el correo **no es clave única** (ID-5). Marcar el par como relación familiar probable, sin fusionar |
| **P08** | Teléfono compartido por dos personas distintas | `4244394613` → `MARTHA HERNÁNDEZ` / `MELANY VALENTINA`; `4247086411` → `MERY OLIVA USECHE` / `BELKYS XIOMARA CORTES USECHE` | **Legítimo, no es error**: es la prueba de que el teléfono no puede ser clave única (ID-4). Consecuencia sobre DP-02: la identidad de un contacto sin cédula es intrínsecamente frágil |

### Columnas que mezclan conceptos

| # | Patología | Evidencia | Regla de saneamiento |
|---|---|---|---|
| **P15** | **Un enum con tres conceptos**: `INTERESADO` mezcla interés (`SI`), estado del embudo (`INSCRITO `) y resultado del contacto (`NO RESPONDIO`) | `SI` 14 · `INSCRITO ` 7 · `NO RESPONDIO` 6 · vacío 17 (sobre 44 filas con nombre) | Descomponer en tres destinos: `INTERES_DECLARADO.interes_curso`, `ESTADO_PERSONA_HIST.estado` e `INTERACCION.resultado` (RN-26) |
| **P19** | `OCUPACION` mezcla ocupación con procedencia institucional | `BIBLIOTECA` (2), `ROTARIA` (1) entre 21 valores | Mover esos 3 valores a `ORGANIZACION_ALIADA` y dejar la ocupación nula. Los 19 restantes forman el catálogo semilla del enum abierto E-07 (DP-17) |
| **P20** | `NOMBRE` (invitado por) mezcla **persona**, **institución** y **la propia escuela** | Personas: `ALEJANDRO` 4, `YRAIMA` 2, `MILAGRO ELENA`, `LUIS CORTES`, `CARLOS NADAL`, `OSCAR IZARRA`, `MANUEL MEDINA`, `LENUAM`, `MILAGRO Y ALEJANDRO`. Instituciones: `ROTARY` 9, `SPINNING BIKE` 4, `BIBLIOTECA` 1. La escuela: `NUEVA ACROPOILIS` (con error de tipeo) | Separar en `invitado_por_persona_id` (selector) y `organizacion_aliada_id`. `MILAGRO Y ALEJANDRO` = **dos referentes en una celda** → requiere decisión: se toma el primero y se anota el segundo (DP-04) |
| **P21** | `TEMA DE LA CHARLA` mezcla título de convocatoria con tema canónico | `NADA CAMBIA SI TU NO CAMBIAS` es el título; el tema real es *"filosofía natural"* (18-jul). Igual con `LA VIDA DESPUÉS DE LA MUERTE` (Buda) y *"cómo superar el dolor"* | Importar el valor a `ACTIVIDAD.titulo` y dejar `tema` nulo. **No inventar el tema canónico** de las 8 charlas: se lo pregunta a Milagros |
| **P22** | La hoja es una **dimensión implícita** (día + lugar) sin columna | `MARTES TÁRIBA BILBIOTECA` (nótese el error de tipeo en "BIBLIOTECA"), `SABADOS SPINNING BIKE` | Derivar `ACTIVIDAD.lugar` y `sede = TARIBA` del nombre de la hoja; documentar la derivación como supuesto explícito |

### Estructura del archivo

| # | Patología | Evidencia | Regla de saneamiento |
|---|---|---|---|
| **P11** | **Filas fantasma sin persona** | 17 filas en la hoja 2 con solo valores de validación (`1`, `SI`, `NO RESPONDIO`, `INSCRITO `) y ninguna identificación. 5 de ellas traen `ESTOICISMO` e `INSTAGRAM` | Descartar toda fila sin nombre **y** sin cédula. Registrar el descarte en el log de importación: son asistentes reales que se perdieron |
| **P12** | La misma variable vive en columna distinta según la hoja | Conteo de llamadas: validación `0..5` sobre `N2:N37` en la hoja 1, y sobre `O2:O13` y `R2:R15` en la hoja 2 — donde `O` está rotulada `COMENTARIOS / LLAMADA/MENSAJE` | Mapear por hoja, no por letra de columna. Caso de prueba obligatorio |
| **P13** | La validación no cubre el rango de datos | `INTERESADO` validado en `T2:T23`, con datos hasta `T40`; llamadas validadas hasta `N37` con datos hasta la fila 40 | Al importar, aceptar valores fuera del enum y enviarlos a revisión en lugar de rechazar la fila |
| **P14** | **Semántica codificada en el color de relleno** | Relleno rojo en `O27:O31` (celdas **vacías**), azul en `A25:A34` (el bloque completo de Rotary), y además naranja en `O32`, `O33`, `O35` y amarillo en `A38:A40` / `A2:A11`. La convención confirmada es solo la de rojo y verde: *"los que están en rojo… se salieron; los que están en verde son los que están activos"* (02-jul). **Naranja y amarillo no significan nada** (confirmado 2026-08-17) y se descartan | **Extraer rojo y verde como dato antes de importar** y traducirlos a estado. Sin este paso se pierden 5 salidas. Es la patología más peligrosa porque es invisible en cualquier exportación a CSV |
| **P23** | La celda vacía se confunde con "no" | `INTERESADO` vacío en 17 de 44 filas, incluidas **las 11 filas de `MITO DE LA CAVERNA`** | Importar como `SIN_CONTACTAR` / `SIN_DATO`, nunca como `NO`. Ver §4 |

---

## 3. Casos de prueba de importación

| ID | Entrada | Resultado esperado |
|---|---|---|
| **IMP-01** | Cédula `27634020.0` | `"27634020"` como texto, sin decimales, con `cedula_tipo = V` y marca de supuesto (el Excel no trae el prefijo) |
| **IMP-02** | Teléfono `4124302480.0` | `"04124302480"` — 11 dígitos con cero inicial |
| **IMP-03** | Teléfono `573152993750` | Se guarda como internacional `+573152993750`, no como teléfono nacional |
| **IMP-04** | Teléfono `414718` | Fila importada con `TELEFONO_INVALIDO`; el valor original se conserva sin transformar |
| **IMP-05** | Las 3 personas repetidas entre hojas | **3 personas**, no 6; **3 participaciones** en la actividad `LIDERAZGO 2024-09-21`, no 6 |
| **IMP-06** | Fila con nombre y sin cédula (`FREDDY ORTIZ`) | Persona creada en estado `ASISTENTE` con cédula nula y bandera de dato faltante |
| **IMP-07** | Las 17 filas fantasma de la hoja 2 | 0 personas creadas; 17 descartes registrados en el log, con el detalle de que 5 traían `ESTOICISMO`/`INSTAGRAM` |
| **IMP-08** | `fmpadilla4380gmail.com` | Correo marcado inválido; **no se autocorrige**; queda en cola de revisión |
| **IMP-09** | `jempresarymc@gmail.com` en dos filas con cédulas distintas | 2 personas distintas; el correo duplicado **no** provoca fusión |
| **IMP-10** | `4244394613` en dos filas con cédulas distintas | 2 personas distintas; el teléfono duplicado **no** provoca fusión |
| **IMP-11** | Fecha de nacimiento `2024-04-05` con evento del `2024-04-09` | `fecha_nacimiento` nula + marca `DATO_SOSPECHOSO` |
| **IMP-12** | `IRAIDA MONCADA`, cédula 18.019.467 con nacimiento 1937 | Persona importada íntegra + marca de incoherencia cédula/fecha para verificación |
| **IMP-13** | `MELANY VALENTINA`, nacida 2008-12-26, registrada 2024-04-09 | `es_menor_de_edad = verdadero` **a la fecha del registro**; entra en la cola de captura de representante (RN-37) y de consentimiento |
| **IMP-14** | `INTERESADO = "INSCRITO "` | Estado `PROBACIONISTA` en el historial + `interes_curso = SI`; **no** se guarda como resultado de contacto |
| **IMP-15** | `INTERESADO` vacío | `resultado = SIN_CONTACTAR`; **nunca** `NO_INTERESADO` |
| **IMP-16** | `POR CUAL MEDIO = "INVITADO "` y `NOMBRE = "ROTARY"` | `medio = ALIANZA` + `organizacion_aliada = ROTARY`; el campo de persona invitadora queda vacío |
| **IMP-17** | `POR CUAL MEDIO = "INVITADO "` y `NOMBRE = "ALEJANDRO"` | `medio = INVITADO_POR_PERSONA` + referencia a la persona Alejandro, resuelta por nombre y confirmada a mano |
| **IMP-18** | `NOMBRE = "MILAGRO Y ALEJANDRO"` | Un solo referente asignado + nota con el segundo nombre; entra en cola de revisión |
| **IMP-19** | `NOMBRE = "NUEVA ACROPOILIS"` | Se reconoce a la escuela misma, no una persona ni una alianza externa; `medio = OTRO` con nota |
| **IMP-20** | `OCUPACION = "ROTARIA"` / `"BIBLIOTECA"` | `ocupacion` nula + vínculo con la organización aliada correspondiente |
| **IMP-21** | Conteo de llamadas en la hoja 1 (col. `N`) y en la hoja 2 (col. `O`) | Ambos llegan a `INTERACCION` como el mismo número de interacciones; ninguno termina en el campo de comentario |
| **IMP-22** | Celda de `O27:O31` con relleno rojo y sin valor | Se genera un cambio de estado a `INACTIVO` (o marca de revisión) a partir del color, no del valor |
| **IMP-23** | Bloque `A25:A34` con relleno azul (Rotary) | Se preserva la pertenencia al bloque como captación vía `ORGANIZACION_ALIADA = ROTARY` en la actividad `MITO DE LA CAVERNA` |
| **IMP-23b** | Celdas con relleno naranja o amarillo | Se ignoran: no codifican nada (confirmado 2026-08-17) |
| **IMP-24** | Hoja `MARTES TÁRIBA BILBIOTECA` | `sede = TARIBA`, `lugar = "Biblioteca Táriba"`, `dia_semana = MARTES`; la derivación queda registrada como supuesto |
| **IMP-25** | Las 15 filas del evento del 2024-04-09 (`NADA CAMBIA SI TU NO CAMBIAS`, 14 filas + 1 del 04-23) | **1 actividad** con 14 participaciones para el 09-04 y otra para el 23-04, no 15 actividades |
| **IMP-26** | `TEMA = "NADA CAMBIA SI TU NO CAMBIAS"` | Va a `ACTIVIDAD.titulo`; `tema` queda nulo (no se inventa "filosofía natural") |
| **IMP-27** | Reimportación del mismo archivo | Idempotente: 0 personas nuevas, 0 participaciones duplicadas |
| **IMP-28** | Valor de `INTERESADO` fuera del enum en filas > 23 (sin validación) | Fila importada, valor en revisión; la fila **no** se rechaza |
| **IMP-29** | Cualquier valor de texto con espacios sobrantes (154 casos) | Recortado; el mapeo del enum funciona con el valor recortado |
| **IMP-30** | `MELANY VALENTINA` (sin apellido claro) | Nombre y apellido separados con marca de revisión, sin inventar apellido |

---

## 4. Advertencia sobre las conclusiones que estos datos **no** soportan

| Conclusión tentadora | Por qué no se sostiene |
|---|---|
| *"`MITO DE LA CAVERNA` no convirtió a nadie"* | Sus 11 filas tienen `INTERESADO` **vacío**. Es dato ausente, no negativo (P23) |
| *"La charla inaugural es la única que convierte"* | Las **6** filas `INSCRITO` de la hoja 1 están todas en `NADA CAMBIA SI TU NO CAMBIAS`, sí — pero la hoja 2 tiene otra (`FREDDY ORTIZ`, `ESTOICISMO`) y 17 filas del libro no tienen el campo lleno. La señal es real, la magnitud no es medible |
| *"El seguimiento se hace una vez"* | 33 de 36 filas registran `1` llamada. Es coherente con *"esto sí ya casi no lo hago"* (02-jul), pero mide **el registro**, no necesariamente el contacto |
| *"Radio, TV y YouTube no funcionan"* | Están en la lista de opciones y tienen 0 usos: nunca se probaron o nunca se registraron. No hay dato |
| *"41 personas es el universo de la escuela"* | Es solo **un** archivo de **una** sede, de abril a septiembre de 2024. Faltan las otras listas, el WhatsApp, el papel y un Excel ya perdido |

---

## 5. Recomendaciones de proceso para la migración

| # | Recomendación | Motivo |
|---|---|---|
| **M-1** | **Extraer los colores de celda antes de cualquier conversión a CSV** | P14: el estado vive en el color y desaparece en cualquier exportación plana |
| **M-2** | Importar con log de descartes y cola de revisión, nunca con rechazo silencioso de filas | P11 y P13: hay 17 filas descartables y valores fuera del enum que igual deben verse |
| **M-3** | Congelar una copia del archivo original antes de tocarlo | Ya se perdió un Excel completo (30-jul) |
| **M-4** | **Todas las decisiones que condicionan la importación quedaron resueltas el 2026-08-17** (DP-01 a DP-18). La transformación del histórico ya se puede especificar sin supuestos abiertos | Antes eran DP-01, DP-02, DP-04, DP-09 y DP-17 |
| **M-5** | Hacer la importación en dos pasadas: personas primero, actividades y participaciones después | La deduplicación por cédula (P04) debe resolverse antes de crear participaciones |
| **M-6** | Los 8 temas canónicos de las charlas de 2024 **no bloquean**: las actividades, charlas y cursos se cargarán como datos más adelante (decisión 2026-08-17). Al importar, `titulo` se llena y `tema` queda nulo | P21: confirmado que el título de convocatoria difiere del tema (*"a veces las charlas iniciales tienen otro título atractivo"*) y no se puede inferir |
| **M-7** | Inventariar las fuentes que faltan antes de estimar la migración total | El `.xlsx` es una fracción; el resto está en WhatsApp, papel y otros Excel |
