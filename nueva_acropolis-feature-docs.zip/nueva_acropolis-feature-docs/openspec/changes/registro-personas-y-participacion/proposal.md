# Registro de personas y participación — núcleo de fase 1

## Why

La gestión de personas, actividades y seguimiento de la sede vive hoy en varios Excel y cuadernos
personales que **lleva una sola persona a mano**. El análisis de descubrimiento (`docs/02` §4) mide cuatro
requisitos que ninguna fuente sostiene sola y que son los de mayor presión: base única de personas (R01,
`ARDIENTE`), estados con historial (R05, `ARDIENTE`), atribución de captación (R06, la mayor intensidad del
análisis: I=20.07) y alta sin fricción (R03, `ARDIENTE`).

Por qué ahora: el riesgo ya se materializó. *"El Excel grande… ahora sí se borró completamente"* (30-jul), y
*"eso lo manejo yo… más nadie tiene nada"* (02-jul) — bus factor 1 sobre el activo central de la sede. Cada
mes que pasa se acumulan asistencias que después nadie puede reconstruir para el informe.

## What Changes

- **Actividades creadas por adelantado**, con línea, círculo, etiquetas, sede, cupo opcional y estado
  (`PLANIFICADA` / `REALIZADA` / `CANCELADA`).
- **Una sola pantalla de registro de participación por actividad**, donde se agregan tanto personas ya
  registradas (miembros, amigos de la escuela, asistentes previos) como personas nuevas, buscando por
  nombre, cédula o teléfono. Es la pieza de mayor palanca: produce la participación, el alta mínima, la
  atribución de captación por evento y el conteo internos/externos sin preguntar nada extra.
- **Alta progresiva de personas**: obligatorios nombre y teléfono; el resto se pide y no bloquea.
- **Guardar nunca se bloquea** — **BREAKING** respecto a `RN-02` tal como estaba redactada: la cédula deja
  de ser obligatoria desde `ASISTENTE` y pasa a exigirse solo en la inscripción a curso. Lo que falta o es
  dudoso genera una marca de revisión resoluble, no un error de validación.
- **Aviso de posible duplicado** por cédula o por teléfono normalizado, no bloqueante, sin fusión
  automática.
- **Estados de la persona con historial** append-only, y roles acumulables con vigencia.
- **Atribución de captación** con medio extensible, quién invitó como selector de personas, y organización
  aliada como entidad propia.
- **Acceso por sede y por área**: usuarios ligados a personas de la escuela, con correo y contraseña y
  Google como atajo opcional. Escritura de alta casi universal, lectura restringida.
- **Auditoría**: quién creó y quién modificó por última vez cada registro; bitácora completa de cambios en
  los campos de identidad de la persona.
- **BREAKING** en el modelo documentado: desaparece la entidad `REFERIDO` (un referido nace como persona en
  estado `CONTACTO`) y los teléfonos y redes pasan de siete columnas de `PERSONA` a la tabla
  `PERSONA_CONTACTO`.

Fuera de alcance, deliberadamente: el importador del Excel histórico, la pantalla del informe OINA,
escolástica, economía y pagos, biblioteca, café, inventario y mensajería automática. Ver *Non-Goals* en
`design.md`.

## Capabilities

### New Capabilities

- `acceso-y-permisos`: usuarios ligados a personas de la escuela, autenticación, permisos por sede y por
  área con vigencia, y visibilidad restringida de los contactos-enlace.
- `registro-de-personas`: alta progresiva, búsqueda, estados con historial, roles, aviso de duplicado,
  marcas de revisión y auditoría de la ficha.
- `actividades-y-participacion`: catálogo de actividades con su estado y etiquetas, y registro de
  participación mixto —personas existentes y nuevas— con el derivado interno/externo.
- `atribucion-de-captacion`: medio de difusión, quién invitó, organización aliada, y los conteos de
  captación por persona y por alianza.

### Modified Capabilities

Ninguna. `openspec/specs/` está vacío: este es el primer change del proyecto.

## Impact

**Documentos de análisis** (fuente de verdad del dominio, ya actualizados el 2026-08-19):
`docs/03-especificacion-de-dominio.md`, `docs/04-diccionario-de-datos.md`,
`docs/05-decisiones-pendientes.md`, más notas en `docs/02` y `docs/06`.

**Decisiones que este change materializa**: DP-19 y DP-23 a DP-36 de `docs/05`.

**Sistemas**: no hay código todavía. Este change crea el primer esquema de base de datos, la
autenticación y las tres primeras pantallas. Stack resuelto en DP-19: PWA responsive, PostgreSQL, claves
UUIDv7, marcas de tiempo en UTC con cortes en la zona horaria de la sede.

**Dependencia externa pendiente**: la validación de Milagros sobre la obligatoriedad de la cédula (DP-24).
No bloquea el diseño; sí puede cambiar el flujo de la puerta.

**Lo que este change no elimina**: la planilla de papel. Sin autorregistro (DP-23), en un evento grande
alguien teclea en vivo o se transcribe después. Sustituye el Excel, no el papel.
