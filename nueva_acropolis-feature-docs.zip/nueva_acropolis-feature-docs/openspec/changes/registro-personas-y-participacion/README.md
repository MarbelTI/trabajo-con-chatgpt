# registro-personas-y-participacion

Nucleo de fase 1: alta progresiva de personas, actividades y registro de participacion, con acceso por sede y area
