## 0. Decisiones que faltan antes de tocar código

- [ ] 0.1 Validar DP-24 con Milagros: ¿la cédula se pide y avisa desde `ASISTENTE`, o se exige? Es el único pendiente que puede cambiar el flujo de la puerta
- [ ] 0.2 Elegir framework, ORM y hosting (fuera de DP-19 a propósito). Criterio: tecnología conocida, bus factor 1 es el riesgo #1
- [ ] 0.3 Confirmar con Milagros el catálogo inicial de sedes, áreas y usuarios que van a existir el primer día

## 1. Esquema base

- [ ] 1.1 Proyecto y conexión a PostgreSQL, con claves UUIDv7 y marcas de tiempo en UTC (F-9, F-10)
- [ ] 1.2 `SEDE` con `zona_horaria`, y `AREA` por sede (`docs/04` §2, §6)
- [ ] 1.3 `PERSONA` con los campos de `docs/04` §1, sin teléfonos ni redes, y con `modificado_por` / `modificado_en`
- [ ] 1.4 `PERSONA_CONTACTO` con `valor`, `valor_normalizado` indexado y `es_principal` único por tipo (`docs/04` §1b)
- [ ] 1.5 `PERSONA_SEDE` con un solo vínculo vigente por persona (`docs/04` §3)
- [ ] 1.6 `ESTADO_PERSONA_HIST` append-only sin solapamiento de fechas (`docs/04` §4)
- [ ] 1.7 `ROL_ASIGNADO` con vigencia y área condicional (`docs/04` §5)
- [ ] 1.8 `MARCA_REVISION` con las tres referencias mutuamente excluyentes y el enum E-21 (`docs/04` §21b)
- [ ] 1.9 Enums cerrados como datos semilla: E-01, E-02, E-04, E-06, E-06b, E-09, E-10, E-14, E-15, E-16, E-17, E-19, E-20, E-22
- [ ] 1.10 Catálogos abiertos con su semilla: E-03 tipos de actividad, E-05 áreas, E-07 ocupaciones (19 valores reales), E-08 sedes, E-11 medios de difusión, E-12, E-13
- [ ] 1.11 Normalización de teléfono y correo según F-1 a F-3 y F-8, con sus pruebas: `4124302480.0` → `04124302480`, `573152993750` → E.164, `414718` → inválido conservando el original
- [ ] 1.12 Bitácora de cambios de identidad de `PERSONA` (RN-47)

## 2. Acceso y permisos

- [ ] 2.1 `USUARIO` ligado a `PERSONA`, con correo único, hash de contraseña y `activo` (RN-50)
- [ ] 2.2 Ingreso con correo y contraseña, y recuperación por correo
- [ ] 2.3 Google como atajo opcional enlazado por correo verificado, nunca como única vía (DP-28)
- [ ] 2.4 `PERMISO_SEDE` y `PERMISO_AREA` con `desde` / `hasta`
- [ ] 2.5 Filtro de lectura por sede y por área en todas las consultas, con excepción de acceso global (RN-27 a RN-30)
- [ ] 2.6 Sugerencia de permisos a partir del rol vigente, sin crearlos automáticamente (RN-54)
- [ ] 2.7 Marca `PERMISO_SIN_ROL_VIGENTE` al cerrar un rol con permisos abiertos (DP-35)
- [ ] 2.8 Alta del primer usuario de acceso global y de un usuario de puerta, como prueba de D7

## 3. Personas

- [ ] 3.1 Alta mínima: nombre y teléfono obligatorios, resto opcional (RN-03, RN-53)
- [ ] 3.2 Formulario progresivo por estado: no pedir cédula en `CONTACTO`, no repreguntar lo capturado (RN-04, RN-05)
- [ ] 3.3 Generación de marcas al guardar: cédula, apellido, teléfono inválido, correo inválido, menor sin representante (RN-46)
- [ ] 3.4 Búsqueda por nombre, cédula y cualquier teléfono normalizado, ignorando acentos y mayúsculas (RN-39, F-5)
- [ ] 3.5 Aviso de posible duplicado con dos niveles —cédula y teléfono— no bloqueante (RN-51)
- [ ] 3.6 Máquina de estados con la única transición automática `CONTACTO → ASISTENTE` (RN-01, `docs/03` §5)
- [ ] 3.7 Derivación de menor de edad **a la fecha de registro** y captura del representante (RN-37)
- [ ] 3.8 Archivar sin borrar, y marca de contacto bloqueado con fecha (RN-41, RN-42)
- [ ] 3.9 Roles acumulables con vigencia, y listado de personas por área con su estado (RN-08, RN-09)
- [ ] 3.10 Traslado de sede: cerrar vínculo con motivo y abrir el nuevo (RN-34)
- [ ] 3.11 Ficha de persona con bitácora única: notas, interacciones y cambios de estado en una sola línea de tiempo (`docs/03` §7 consulta 8)
- [ ] 3.12 Fusión asistida de fichas, conservando historial de ambas y dejando rastro (ID-6, ID-7)
- [ ] 3.13 Bandeja de marcas pendientes por sede y por área, con resolución fechada y firmada (DP-36)

## 4. Actividades

- [ ] 4.1 `ACTIVIDAD` con sede, tipo, línea, círculo, título, tema opcional, inicio, lugar, cupo y `estado` (RN-14, RN-48)
- [ ] 4.2 `ETIQUETA` y `ACTIVIDAD_ETIQUETA` con creación de etiquetas por el usuario (RN-15)
- [ ] 4.3 Transiciones de estado de la actividad: planificada, realizada, cancelada
- [ ] 4.4 Vínculo opcional al grupo de un curso, para la clase suelta (RN-38)
- [ ] 4.5 Lista de actividades próximas como pantalla de entrada al registro (D10)
- [ ] 4.6 Cortes y presentación de fechas en la zona horaria de la sede, con prueba del caso del día 31 a las 20:00 (RN-55)

## 5. Participación — la pantalla de mayor palanca

- [ ] 5.1 `PARTICIPACION` con par único persona × actividad (`docs/04` §11)
- [ ] 5.2 Pantalla de la actividad con búsqueda por nombre, cédula y teléfono
- [ ] 5.3 Agregar persona existente con un toque, sin repreguntar datos
- [ ] 5.4 Alta en el sitio con nombre y teléfono, creando persona y participación en un paso
- [ ] 5.5 Captura de la atribución en el mismo flujo: medio, quién invitó, organización aliada
- [ ] 5.6 Derivación y congelado de `es_interno_en_la_fecha` (RN-17)
- [ ] 5.7 Contador de internos, externos y cupo en la propia pantalla, con aviso al alcanzarlo (RN-43)
- [ ] 5.8 Quitar un participante agregado por error, con auditoría del cambio
- [ ] 5.9 Prueba de la mesa de catorce: una actividad, catorce participaciones, cero duplicados (IMP-25)

## 6. Atribución de captación

- [ ] 6.1 `ATRIBUCION_CAPTACION` con medio, persona invitadora y organización aliada mutuamente coherentes (RN-20)
- [ ] 6.2 `ORGANIZACION_ALIADA` como entidad, con tipo (DP-04)
- [ ] 6.3 Selector de persona invitadora, sin texto libre (RN-20)
- [ ] 6.4 Marca de primera captación, una sola por persona
- [ ] 6.5 Derivación de `invitado_por_interno` a la fecha (RN-44)
- [ ] 6.6 Referido creado como persona en estado `CONTACTO` con su atribución (RN-23, ID-9)
- [ ] 6.7 Conteos: personas invitadas por cada quien, y personas captadas por cada alianza (RN-22)

## 7. Seguimiento e interés

- [ ] 7.1 `INTERACCION` con canal, fecha, resultado y nota, registrable en un toque (RN-24)
- [ ] 7.2 `NOTA_FICHA` append-only, visible para quien tenga acceso a la ficha (RN-40)
- [ ] 7.3 `INTERES_DECLARADO` con vigencia del último por línea (RN-52)
- [ ] 7.4 `CONSENTIMIENTO_CONTACTO` informativo, que no filtra envíos (RN-12)
- [ ] 7.5 Lista de invitación segmentada por interés vigente (`docs/03` §7 consulta 7)

## 8. Cierre

- [ ] 8.1 Vista de cumpleañeros del día y del mes en la entrada (RN-35)
- [ ] 8.2 Vistas derivadas de D2: estado vigente, sede vigente, último estatus, interno, categoría OINA, clases al corte
- [ ] 8.3 Repaso de las consultas 1 a 11 de `docs/03` §7 — la 12, el informe OINA, queda fuera de este change
- [ ] 8.4 Revisar que ninguna validación bloquee un guardado que RN-46 permite
- [ ] 8.5 Actualizar `docs/03` a `docs/05` si algo del desarrollo contradijo el análisis
