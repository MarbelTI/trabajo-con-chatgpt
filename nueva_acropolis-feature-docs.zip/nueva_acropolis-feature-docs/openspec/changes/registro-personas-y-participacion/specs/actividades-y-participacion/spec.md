# Actividades y participación

## ADDED Requirements

### Requirement: La actividad se crea antes y tiene estado
El sistema SHALL exigir que la actividad exista antes de registrar participaciones, y SHALL registrar su
estado como `PLANIFICADA`, `REALIZADA` o `CANCELADA`. (RN-48, DP-26)

#### Scenario: Registrar participación en actividad inexistente
- **WHEN** un usuario intenta registrar asistentes sin haber creado la actividad
- **THEN** el sistema le ofrece crear la actividad primero

#### Scenario: Actividad planificada sin asistentes
- **WHEN** una actividad planificada termina sin participaciones registradas
- **THEN** sigue distinguiéndose de una actividad cancelada

#### Scenario: Actividad cancelada
- **WHEN** se cancela una actividad ya creada
- **THEN** su estado pasa a `CANCELADA`
- **AND** deja de contar como actividad realizada en cualquier conteo

### Requirement: Datos obligatorios de la actividad
El sistema SHALL exigir en toda actividad la sede, el tipo, la línea, el círculo, el título de convocatoria
y la fecha y hora de inicio. El tema canónico SHALL ser opcional y distinto del título. (RN-14, RN-15b,
RN-16, DP-01)

#### Scenario: Título distinto del tema
- **WHEN** se crea una charla titulada "Nada cambia si tú no cambias" cuyo tema canónico es otro
- **THEN** el título y el tema se guardan en campos separados
- **AND** el tema puede quedar vacío

#### Scenario: Actividad sin círculo
- **WHEN** se intenta guardar una actividad sin círculo
- **THEN** el sistema lo exige antes de guardar

### Requirement: Etiquetas libres creadas por el usuario
El sistema SHALL permitir asignar varias etiquetas a una actividad y SHALL permitir al usuario crear
etiquetas nuevas. (RN-14, RN-15)

#### Scenario: Actividad con dos etiquetas
- **WHEN** se etiqueta una actividad como "Día de la Tierra" y "Día Internacional del Arte"
- **THEN** ambas quedan asociadas a la misma actividad

#### Scenario: Etiqueta nueva
- **WHEN** un usuario escribe una etiqueta que no existe
- **THEN** el sistema la crea y guarda quién la creó

### Requirement: Registro de participación mixto en una sola pantalla
El sistema SHALL permitir, desde la pantalla de una actividad, agregar tanto personas ya registradas como
personas nuevas. La búsqueda SHALL funcionar por nombre, cédula y teléfono, y el alta en el sitio SHALL
pedir solo nombre y teléfono. (RN-49, RN-53, DP-27, DP-31)

#### Scenario: Agregar a un miembro que ya está en la base
- **WHEN** un usuario busca a un miembro por su nombre y lo agrega a la actividad
- **THEN** se crea su participación sin volver a pedir ningún dato de la ficha

#### Scenario: Agregar a alguien que no existe
- **WHEN** la búsqueda no devuelve resultados y el usuario crea la persona con nombre y teléfono
- **THEN** la persona se crea, queda en estado `ASISTENTE` y su participación se registra en el mismo paso

#### Scenario: Persona ya registrada en esa actividad
- **WHEN** se intenta agregar a alguien que ya figura como participante de esa actividad
- **THEN** el sistema no crea una segunda participación

#### Scenario: Registrar una mesa de asistentes
- **WHEN** un usuario agrega catorce personas a la misma actividad
- **THEN** se crean catorce participaciones sobre una sola actividad

### Requirement: Internos y externos derivados, congelados a la fecha
El sistema SHALL derivar si cada participante era interno o externo **a la fecha de la actividad**, y SHALL
conservar ese valor sin recalcularlo después. Interno SHALL significar estado `PROBACIONISTA` o `MIEMBRO`, o
cualquier rol vigente. (RN-10, RN-17, DP-14)

#### Scenario: Conteo de la actividad
- **WHEN** se consulta una actividad realizada
- **THEN** el sistema muestra el total de asistentes y su desglose entre internos y externos

#### Scenario: Asistente que después se inscribe
- **WHEN** una persona asiste como externa y meses después pasa a `PROBACIONISTA`
- **THEN** su participación anterior sigue contando como externa

#### Scenario: Interno por rol sin estar inscrito
- **WHEN** participa una persona con rol vigente de celador pero en estado `ASISTENTE`
- **THEN** cuenta como interna

### Requirement: El cupo avisa y nunca bloquea
El sistema MAY registrar un cupo opcional por actividad. Cuando existe, SHALL avisar al alcanzarlo y no
SHALL impedir registrar a nadie. (RN-43, DP-13, DP-21)

#### Scenario: Cupo alcanzado
- **WHEN** el número de participantes iguala el cupo definido
- **THEN** el sistema avisa
- **AND** permite seguir agregando personas

### Requirement: La clase suelta es actividad y pertenece al grupo del curso
El sistema SHALL permitir que una actividad esté ligada opcionalmente al grupo de un curso, de modo que
alguien pueda asistir a una clase sin estar inscrito y esa asistencia quede registrada. (RN-38, DP-06)

#### Scenario: Asistente no inscrito en una clase
- **WHEN** se registra la participación de una persona no inscrita en una actividad ligada a un grupo
- **THEN** la participación se guarda igual
- **AND** cuenta para el conteo de clases asistidas de esa persona

### Requirement: Marcas de tiempo en UTC con cortes en la zona de la sede
El sistema SHALL almacenar toda marca de tiempo en UTC y SHALL calcular todo corte de periodo y toda
presentación de fecha en la zona horaria de la sede. (RN-55, DP-25b)

#### Scenario: Actividad vespertina el último día del mes
- **WHEN** se registra una actividad el día 31 a las 20:00 en la zona de la sede
- **THEN** cuenta dentro de ese mes en cualquier corte de periodo, no del siguiente

#### Scenario: Sede en otro país
- **WHEN** una sede tiene una zona horaria distinta
- **THEN** sus actividades se presentan y se cortan en su propia zona
