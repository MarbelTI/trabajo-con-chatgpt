# Atribución de captación

## ADDED Requirements

### Requirement: Toda captación registra el medio de difusión
El sistema SHALL registrar el medio por el que llegó la persona, y el catálogo de medios SHALL ser
extensible por el usuario. La atribución SHALL capturarse por evento, no una sola vez por persona.
(RN-20, RN-21)

#### Scenario: Captación en el alta de un evento
- **WHEN** un usuario agrega una persona nueva a una actividad
- **THEN** el formulario exige el medio de difusión antes de guardar

#### Scenario: Medio nuevo
- **WHEN** un usuario necesita un medio que no está en la lista
- **THEN** puede crearlo y queda disponible para los demás

#### Scenario: Segunda captación de la misma persona
- **WHEN** la misma persona vuelve por otro medio en otra actividad
- **THEN** se registra una segunda atribución
- **AND** solo la primera queda marcada como la que cuenta para el informe

### Requirement: Quién invitó es un selector de personas, no texto libre
Cuando el medio SHALL ser "invitado por alguien", el sistema SHALL exigir seleccionar a la persona que
invitó de entre las personas registradas. No SHALL aceptarse texto libre en ese campo. (RN-20, RN-22)

#### Scenario: Invitación personal
- **WHEN** se indica que la persona vino invitada por alguien
- **THEN** el sistema exige elegir a esa persona de la lista

#### Scenario: Conteo de invitaciones por persona
- **WHEN** se consulta cuántas personas invitó cada quien en un periodo
- **THEN** el sistema devuelve el conteo por persona invitadora

### Requirement: La organización aliada se distingue de la persona que invita
El sistema SHALL registrar la organización aliada como entidad propia, separada de la persona invitadora,
de modo que puedan contarse las personas captadas por cada alianza. (RN-20, DP-04)

#### Scenario: Captación vía club de servicio
- **WHEN** un grupo de personas llega a una charla por medio de un club de servicio aliado
- **THEN** la atribución apunta a la organización aliada y el campo de persona invitadora queda vacío

#### Scenario: Rendimiento por alianza
- **WHEN** se consulta qué alianzas trajeron más personas
- **THEN** el sistema devuelve el conteo por organización aliada

#### Scenario: Actividad realizada en alianza
- **WHEN** una actividad se organiza junto a una institución aliada
- **THEN** la actividad puede referenciar esa organización

### Requirement: Invitado por alguien de la escuela se deriva, no se captura
El sistema SHALL derivar si quien invitó pertenecía a la escuela a la fecha de la invitación, a partir de
su estado y sus roles. No SHALL existir un campo para capturarlo a mano. (RN-44, RN-10, DP-18)

#### Scenario: Invitación de un acropolitano
- **WHEN** quien invitó estaba en estado `MIEMBRO` a esa fecha
- **THEN** la atribución se cuenta como invitación de alguien de la escuela

#### Scenario: Invitación de un externo
- **WHEN** quien invitó era un asistente sin rol vigente a esa fecha
- **THEN** la atribución se cuenta como invitación de alguien externo

### Requirement: El referido nace como contacto
El sistema SHALL crear al referido directamente como persona en estado `CONTACTO`, con la atribución
apuntando a quien lo refirió. No SHALL existir una entidad intermedia de referido ni un paso de
conversión. (RN-23, ID-9, DP-32)

#### Scenario: Referido sugerido en una planilla de evento
- **WHEN** una persona sugiere a un conocido con su nombre y teléfono
- **THEN** se crea una persona en estado `CONTACTO` con esos datos
- **AND** su atribución apunta a quien lo refirió

#### Scenario: Seguimiento del referido
- **WHEN** un usuario llama al referido
- **THEN** el contacto se registra en la misma bitácora de interacciones que cualquier otra persona

#### Scenario: El referido asiste
- **WHEN** el referido se registra en una actividad
- **THEN** pasa a `ASISTENTE` sobre la misma ficha, sin crear una nueva
