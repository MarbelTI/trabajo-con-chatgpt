# Registro de personas

## ADDED Requirements

### Requirement: Solo un usuario autenticado da de alta personas
El sistema no SHALL ofrecer autorregistro. Toda persona SHALL ser creada por un usuario autenticado, y
todo registro SHALL guardar quién lo creó y cuándo. (RN-06, RN-45, DP-23)

#### Scenario: Alta desde el móvil en un evento
- **WHEN** un usuario autenticado crea una persona
- **THEN** la ficha queda con `registrado_por` igual a ese usuario y la fecha y hora del registro

#### Scenario: Conteo por quien registra
- **WHEN** se consulta cuántas personas registró cada usuario en un periodo
- **THEN** el sistema devuelve el conteo por usuario

### Requirement: Alta mínima de nombre y teléfono
El sistema SHALL crear una persona con solo nombre y teléfono. Los demás datos SHALL ser opcionales al
guardar, salvo la cédula en la inscripción a curso. (RN-03, RN-53, DP-24, DP-31)

#### Scenario: Alta con dos campos
- **WHEN** un usuario crea una persona con nombre y teléfono, sin apellido, cédula, fecha de nacimiento ni ocupación
- **THEN** la persona se guarda

#### Scenario: Falta el apellido
- **WHEN** se guarda una persona sin apellido distinguible
- **THEN** se crea una marca `APELLIDO_FALTANTE`
- **AND** el guardado no se impide

#### Scenario: Alta sin nombre
- **WHEN** se intenta guardar una persona sin nombre o sin teléfono
- **THEN** el sistema rechaza el guardado

### Requirement: La cédula se pide y avisa, y solo obliga en la inscripción
El sistema no SHALL exigir cédula en el estado `CONTACTO`. Desde `ASISTENTE` SHALL pedirla y, si falta,
SHALL crear una marca de revisión sin impedir el guardado. En la inscripción a curso la cédula SHALL ser
obligatoria. (RN-02 modificada, RN-46, DP-24)

#### Scenario: Asistente sin cédula
- **WHEN** se registra la participación de una persona sin cédula
- **THEN** la persona queda en estado `ASISTENTE`
- **AND** se crea una marca `CEDULA_FALTANTE`

#### Scenario: Contacto al que no se pide cédula
- **WHEN** se crea una persona en estado `CONTACTO`
- **THEN** el formulario no muestra el campo de cédula

#### Scenario: Inscripción a curso sin cédula
- **WHEN** se intenta inscribir a una persona sin cédula en un grupo de curso
- **THEN** el sistema exige la cédula antes de guardar la inscripción

### Requirement: Aviso de posible duplicado sin bloqueo ni fusión automática
El sistema SHALL avisar, al crear una persona, si la cédula o algún teléfono normalizado ya existe. El
aviso no SHALL impedir guardar, y el sistema no SHALL fusionar fichas automáticamente. (RN-51, ID-4, ID-5,
ID-6, DP-29)

#### Scenario: Cédula ya registrada
- **WHEN** se introduce una cédula que ya existe en otra ficha
- **THEN** el sistema avisa que es casi con seguridad la misma persona y ofrece abrir la ficha existente

#### Scenario: Teléfono compartido entre familiares
- **WHEN** se introduce un teléfono que ya existe en otra ficha con nombre distinto
- **THEN** el sistema avisa que podría ser un familiar
- **AND** permite guardar la persona nueva

#### Scenario: Fusión de fichas
- **WHEN** un usuario confirma que dos fichas son la misma persona
- **THEN** la fusión conserva el historial de estados, las participaciones y las interacciones de ambas
- **AND** queda rastro de la fusión en la ficha resultante

### Requirement: Búsqueda por nombre, cédula y teléfono
El sistema SHALL permitir buscar personas por nombre, por cédula y por cualquier teléfono registrado,
usando el valor normalizado. La comparación de nombres SHALL ignorar acentos, mayúsculas y espacios
sobrantes. (RN-39, F-5, F-8, DP-33)

#### Scenario: Búsqueda por teléfono secundario
- **WHEN** se busca por un teléfono que está registrado como secundario de una persona
- **THEN** la persona aparece en los resultados

#### Scenario: Búsqueda por nombre con acentos
- **WHEN** se busca "martha hernandez" y la ficha dice "MARTHA HERNÁNDEZ"
- **THEN** la persona aparece en los resultados

### Requirement: Un estado vigente con historial append-only
El sistema SHALL mantener exactamente un estado vigente por persona y un historial de transiciones con
fecha, autor y disparador. El historial no SHALL editarse ni borrarse. La única transición automática SHALL
ser `CONTACTO → ASISTENTE` al registrar la primera participación. (RN-01, RN-11, DP-05)

#### Scenario: Primera participación de un contacto
- **WHEN** se registra la participación de una persona en estado `CONTACTO`
- **THEN** su estado pasa a `ASISTENTE` automáticamente
- **AND** el historial guarda la transición con su disparador

#### Scenario: Inscripción al curso de filosofía
- **WHEN** un usuario inscribe a un asistente en un grupo del curso de filosofía
- **THEN** el estado pasa a `PROBACIONISTA` por acción manual, nunca por número de clases asistidas

#### Scenario: Persona inactiva
- **WHEN** una persona pasa a `INACTIVO`
- **THEN** se conserva su último estatus alcanzado y el punto del curso donde quedó
- **AND** sigue siendo destinataria de invitaciones

### Requirement: Nadie se borra
El sistema no SHALL ofrecer borrado de personas. SHALL permitir archivarlas y SHALL registrar el bloqueo de
contacto como marca informativa con fecha, sin impedir conservar la ficha ni su historial. (RN-41, RN-42)

#### Scenario: Persona que bloquea el contacto
- **WHEN** un usuario marca que la persona bloqueó el contacto
- **THEN** se guarda la marca con la fecha
- **AND** la ficha y su historial se conservan íntegros

#### Scenario: Intento de borrado
- **WHEN** un usuario busca la opción de eliminar una persona
- **THEN** el sistema solo ofrece archivar

### Requirement: Menor de edad con representante
El sistema SHALL derivar si la persona es menor de edad **a la fecha de registro** y, en ese caso, SHALL
pedir nombre, teléfono y parentesco del representante. Si falta, SHALL crear una marca de revisión sin
bloquear. (RN-37, DP-09)

#### Scenario: Registro de un menor
- **WHEN** se registra una persona nacida en 2009 con fecha de registro en 2024
- **THEN** queda marcada como menor de edad a la fecha del registro
- **AND** el consentimiento de contacto se atribuye al representante

#### Scenario: Menor sin representante capturado
- **WHEN** se guarda un menor de edad sin datos de representante
- **THEN** se crea una marca `MENOR_SIN_REPRESENTANTE`

### Requirement: Marcas de revisión como bandeja de trabajo
El sistema SHALL registrar como marca de revisión resoluble cada dato faltante, inválido o sospechoso, y
no SHALL bloquear el guardado por ninguno de ellos. Las marcas SHALL poder listarse pendientes por sede y
por área, y SHALL resolverse, nunca borrarse. (RN-46, DP-36)

#### Scenario: Teléfono con formato inválido
- **WHEN** se guarda un teléfono de menos de diez dígitos
- **THEN** se conserva el valor original sin transformar
- **AND** se crea una marca `TELEFONO_INVALIDO`

#### Scenario: Bandeja de pendientes
- **WHEN** un usuario abre la lista de marcas pendientes de su sede
- **THEN** ve las no resueltas con su tipo, su detalle y la ficha a la que apuntan

#### Scenario: Resolver una marca
- **WHEN** un usuario completa el dato que faltaba y resuelve la marca
- **THEN** la marca queda con fecha y autor de resolución
- **AND** deja de aparecer entre las pendientes

### Requirement: Auditoría de creación y de modificación
El sistema SHALL guardar en cada registro editable quién lo creó, quién lo modificó por última vez y
cuándo. Para los campos de identidad de la persona —cédula, nombre, apellido y teléfonos— SHALL guardar
además el historial completo de cambios. (RN-06, RN-47, DP-25)

#### Scenario: Edición de la ficha
- **WHEN** un usuario corrige la ocupación de una persona
- **THEN** la ficha guarda a ese usuario como último modificador y la fecha

#### Scenario: Corrección de la cédula
- **WHEN** un usuario cambia la cédula de una persona
- **THEN** se guarda el valor anterior, el nuevo, el usuario y la fecha en el historial de identidad

### Requirement: Roles acumulables con vigencia, ortogonales al estado
El sistema SHALL permitir varios roles simultáneos por persona, ligados a un área cuando corresponda, con
fecha de inicio y fin. Los roles SHALL ser independientes del estado del embudo. (RN-08, RN-09, DP-12)

#### Scenario: Probacionista que colabora en un área
- **WHEN** se asigna el rol de colaborador de relaciones públicas a una persona en estado `PROBACIONISTA`
- **THEN** conserva su estado y acumula el rol

#### Scenario: Listado del área
- **WHEN** el encargado de un área lista a las personas con rol vigente en ella
- **THEN** ve cada una con su estado del embudo

### Requirement: Un solo vínculo de sede vigente, con historial
El sistema SHALL mantener un único vínculo de sede vigente por persona y SHALL conservar el historial de
vínculos. El traslado SHALL cerrar el vínculo anterior y abrir el nuevo con su motivo. (RN-07, RN-34,
DP-03)

#### Scenario: Traslado entre filiales
- **WHEN** una persona se traslada de Táriba a San Cristóbal
- **THEN** el vínculo con Táriba se cierra con motivo `TRASLADO_FILIAL`
- **AND** se abre un vínculo vigente con San Cristóbal

#### Scenario: Usuario con acceso a dos sedes
- **WHEN** un usuario con permiso sobre dos sedes consulta la ficha de una persona
- **THEN** la persona sigue teniendo una sola sede vigente

### Requirement: Interés declarado vigente por línea
El sistema SHALL registrar el interés declarado con fecha y SHALL considerar vigente el último declarado
**por cada línea** de actividad, no el último en absoluto. (RN-52, DP-30)

#### Scenario: Dos intereses en líneas distintas
- **WHEN** una persona declara interés en voluntariado en marzo y en cultura en junio
- **THEN** ambos intereses siguen vigentes, uno por línea

#### Scenario: Redeclaración en la misma línea
- **WHEN** una persona declara un nuevo interés en la línea de cultura
- **THEN** el anterior de esa línea deja de ser el vigente y se conserva en el historial

#### Scenario: Lista de invitación segmentada
- **WHEN** se pide a quién invitar a un concierto
- **THEN** el sistema devuelve las personas cuyo interés vigente en la línea de cultura lo incluye
