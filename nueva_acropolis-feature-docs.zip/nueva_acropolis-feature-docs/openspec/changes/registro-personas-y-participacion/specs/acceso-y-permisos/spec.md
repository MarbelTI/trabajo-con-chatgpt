# Acceso y permisos

## ADDED Requirements

### Requirement: Todo usuario es una persona de la escuela
El sistema SHALL exigir que cada usuario esté vinculado a una persona registrada. No SHALL existir
cuentas anónimas ni compartidas entre varias personas. (RN-50, DP-28, DP-34)

#### Scenario: Crear usuario para una persona existente
- **WHEN** un administrador crea un usuario para una persona ya registrada
- **THEN** el usuario queda vinculado a esa persona
- **AND** todo registro que ese usuario cree queda firmado con su nombre

#### Scenario: Crear usuario para el guardia de la puerta
- **WHEN** se crea el usuario del guardia, que es miembro y cuya puerta es su voluntariado
- **THEN** se crea con permiso de escritura sobre su sede
- **AND** las personas que registre quedan atribuidas nominalmente a él, no a una cuenta genérica

#### Scenario: Intento de crear usuario sin persona
- **WHEN** se intenta crear un usuario sin persona vinculada
- **THEN** el sistema rechaza la operación

### Requirement: Autenticación con correo y contraseña, y Google como atajo opcional
El sistema SHALL permitir iniciar sesión con correo y contraseña. El sistema MAY permitir además iniciar
sesión con una cuenta de Google enlazada al mismo usuario por correo verificado. Google no SHALL ser la
única vía de acceso. (DP-28)

#### Scenario: Ingreso con correo y contraseña
- **WHEN** un usuario activo ingresa su correo y contraseña correctos
- **THEN** obtiene sesión con sus permisos de sede y área

#### Scenario: Ingreso con Google sobre una cuenta existente
- **WHEN** un usuario con cuenta de Google enlazada al mismo correo verificado inicia sesión con Google
- **THEN** accede al mismo usuario, no a uno nuevo

#### Scenario: Usuario desactivado
- **WHEN** un usuario marcado como inactivo intenta ingresar por cualquier vía
- **THEN** el acceso se deniega

### Requirement: Escritura de alta abierta, lectura restringida por sede
El sistema SHALL permitir dar de alta personas a cualquier usuario con escritura en su sede, y SHALL
restringir la lectura a las sedes sobre las que el usuario tiene permiso. Los usuarios con acceso global
SHALL ver todas las sedes. (RN-27, RN-29, RN-30)

#### Scenario: Lectura limitada a la propia sede
- **WHEN** un usuario con permiso solo sobre Táriba consulta el listado de personas
- **THEN** ve únicamente personas cuyo vínculo vigente es Táriba

#### Scenario: Usuario con permiso sobre dos sedes registra a alguien
- **WHEN** un usuario con permiso sobre San Cristóbal y Táriba da de alta una persona
- **THEN** el sistema le exige elegir la sede antes de guardar

#### Scenario: Acceso global
- **WHEN** el director nacional consulta el listado de personas
- **THEN** ve las de todas las sedes

### Requirement: Los contactos-enlace solo los ve el área que los custodia
El sistema SHALL restringir la lectura de los contactos-enlace marcados como restringidos al área que los
custodia, más los usuarios con acceso global. (RN-28, DP-08)

#### Scenario: Encargado de difusión consulta contactos-enlace
- **WHEN** el encargado de difusión abre el listado de contactos-enlace
- **THEN** ve los custodiados por difusión y no los de relaciones públicas

#### Scenario: Contacto-enlace de gobierno
- **WHEN** un usuario sin permiso sobre el área custodia intenta abrir un contacto-enlace restringido
- **THEN** el sistema no muestra la ficha

### Requirement: Los permisos tienen vigencia y se revisan al cerrar un rol
El sistema SHALL registrar los permisos con fecha de inicio y fin opcional, SHALL sugerir los permisos a
partir del rol vigente de la persona, y SHALL generar una marca de revisión cuando un rol se cierra y
quedan permisos abiertos asociados a él. El sistema no SHALL revocar permisos automáticamente.
(RN-54, DP-35)

#### Scenario: Relevo en el encargo de un área
- **WHEN** se cierra el rol de encargado de relaciones públicas de una persona
- **THEN** se crea una marca `PERMISO_SIN_ROL_VIGENTE` por cada permiso de área que siga abierto
- **AND** los permisos siguen activos hasta que alguien los resuelva

#### Scenario: Sugerencia al asignar un rol
- **WHEN** se asigna a alguien el rol de encargado de un área
- **THEN** el sistema propone el permiso de lectura de esa área
- **AND** el permiso solo se crea si el administrador lo confirma
