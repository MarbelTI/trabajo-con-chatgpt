# Diseño — Registro de personas y participación

## Context

El proyecto llega a este change con **cinco reuniones de descubrimiento, un Excel real de 41 personas y
2.600 líneas de análisis** en `docs/`. El dominio ya está especificado y no se re-deriva aquí:

| Documento | Qué aporta | Rol frente a este diseño |
|---|---|---|
| `docs/01-contexto-organizacional.md` | Contexto de la organización, fuentes públicas | Contexto |
| `docs/02-linea-tiempo-y-colision-qwf.md` | Qué se dijo, cuándo, y qué requisitos se refuerzan | Justifica la priorización |
| `docs/03-especificacion-de-dominio.md` | 23 entidades, ER, máquina de estados, RN-01 a RN-55, ID-1 a ID-9 | **Fuente de verdad del modelo** |
| `docs/04-diccionario-de-datos.md` | Campos, tipos, obligatoriedad, formatos F-1 a F-11, enums E-01 a E-22 | **Fuente de verdad de los atributos** |
| `docs/05-decisiones-pendientes.md` | DP-01 a DP-36 con pregunta, opciones, resolución y traza | **Bitácora canónica de decisiones** |
| `docs/06-calidad-de-datos.md` | 25 patologías del Excel + IMP-01 a IMP-30 | Insumo del importador, fuera de este change |

**Regla de este diseño: no duplicar `docs/`.** Cada decisión de abajo referencia su `DP-xx` y su `RN-xx`.
Si algo se contradice, gana `docs/`, y hay que corregir aquí.

**Restricciones del entorno** (`docs/01` §8, revisadas el 2026-08-19): uso móvil primero y también de
escritorio; WhatsApp es el canal dominante de la sede; la intermitencia de luz e internet **no** es
condicionante real —se usa desde el teléfono cuando hace falta, con conexión—, lo que elimina la necesidad
de operación offline. Datos sensibles: creencias, participación y menores de edad reales en los registros.

**Personas involucradas**: Milagros (relaciones públicas, dueña del requisito), Manuelita (secretaria
privada, consolida), Carlos (difusión), Isdrey (asume relaciones públicas de San Cristóbal), el profe
(director nacional), el guardia de la puerta (miembro, la puerta es su voluntariado).

## Goals / Non-Goals

**Goals**

1. Que registrar a alguien en el momento cueste menos que anotarlo en papel. El Excel demuestra el
   contrafactual: 33 de 36 filas con seguimiento tienen exactamente **1** contacto registrado — si
   registrar cuesta más de un toque, no se registra.
2. Grano de evento, no de contador: una fila por persona × actividad, una fila por transición de estado.
   Así cualquier línea del informe internacional es una consulta futura, incluso las que hoy no conocemos.
3. Auditoría real: quién registró, quién modificó, cuándo. Es la base de la confianza en la base única
   (bucle B de `docs/02` §5, el bucle raíz).
4. Multi-sede desde el esquema, con lectura restringida por sede y por área.
5. Tecnología aburrida: el riesgo #1 del proyecto es bus factor 1, y aplica también al software.

**Non-Goals**

- Importador del Excel histórico. `docs/06` ya tiene las 30 pruebas de aceptación; es otro change.
- Pantalla del informe OINA. El grano de evento la habilita; construirla exige la planilla grande campo a
  campo, que hoy no está en el repo.
- Escolástica (asistencia por sesión, notas), economía y pagos, biblioteca, café, inventario, mensajería
  automática y OCR de planillas. Puntos de extensión declarados en `docs/03` §8.
- Operación offline y sincronización.
- Borrado de datos: no existe (RN-41). Solo archivar y resolver marcas.
- Eliminar la planilla de papel. Sin autorregistro (DP-23), en un evento grande alguien teclea en vivo o
  transcribe después.

## Decisions

### D1 · Grano de evento, no contadores derivados

Toda cifra se calcula desde el detalle. `PARTICIPACION` es una fila por persona × actividad;
`ESTADO_PERSONA_HIST` es append-only con `desde`/`hasta`.

*Alternativa descartada*: contadores desnormalizados en `PERSONA` y `SEDE` (`total_asistencias`,
`altas_del_mes`). Más rápido de leer, imposible de auditar y garantiza el descuadre que RN-31 prohíbe
(*"si uno se pela por uno, de una vez le devuelven esa vaina"*).

### D2 · Campos derivados: vista por defecto, columna solo cuando la semántica es "congelado"

| Campo | Vista o columna | Por qué |
|---|---|---|
| `estado_vigente`, `sede_vigente`, `ultimo_estado_alcanzado`, `es_interno`, `categoria_oina` | **vista** | Se derivan del historial; recalcular es lo correcto |
| `clases_asistidas_al_corte` | **vista** | Cuenta participaciones con `grupo_id` (RN-38) |
| `es_menor_de_edad` | **columna** | Definido *a la fecha de registro*. Una vista lo volvería falso al cumplir 18 |
| `PARTICIPACION.es_interno_en_la_fecha` | **columna** | `docs/04` §11 lo declara congelado a la fecha del evento. Es RN-17, la cifra del informe |
| `ATRIBUCION_CAPTACION.es_primera_captacion` | **columna** | Regla de negocio: una sola verdadera por persona |

*Alternativa descartada*: materializar todo. Duplica la verdad y obliga a mantener consistencia a mano.

### D3 · Guardar nunca se bloquea → `MARCA_REVISION` como entidad de primera clase

DP-24, DP-29, DP-31 y DP-36 dicen lo mismo cuatro veces: *guarda siempre, avisa después*. Sin entidad, el
aviso es un mensaje que se pierde al guardar. Con entidad, es una **bandeja de pendientes**, que es
exactamente la mitad del formulario que hoy queda vacía (11%–25% de llenado en las columnas de intención y
seguimiento del Excel). Unifica el mecanismo del formulario con el del importador (`docs/06`), que ya lo
había inventado ad hoc.

*Alternativa descartada*: validación bloqueante. Contradice el patrón que Milagros ya fijó tres veces —el
cupo avisa y no bloquea (RN-43), la cédula no se exige al contacto (RN-02), la fusión se propone y no se
ejecuta (ID-6)— y en la puerta produciría el peor resultado posible: no registrar a nadie.

### D4 · Identidad débil asumida, deduplicado propuesto y nunca automático

Cédula como identificador natural cuando existe (ID-1); teléfono normalizado + nombre para el contacto sin
cédula (ID-3). **Sin unicidad global sobre el teléfono ni el correo**: hay dos casos reales de teléfono
compartido (P08: madre/hija, hermanas) y uno de correo compartido (P06). Dos niveles de aviso: cédula igual
es casi con seguridad la misma persona; teléfono igual puede ser un familiar. Ninguno impide guardar
(RN-51).

### D5 · Teléfonos y redes en `PERSONA_CONTACTO`, no en columnas

Siete columnas de `PERSONA` pasan a filas con `valor` + `valor_normalizado` indexado. RN-39 pide buscar por
teléfono e ID-6 deduplicar por teléfono normalizado: con tres columnas de teléfono eso son tres
comparaciones por par de fichas. Con una tabla hija, un índice. Resuelve además el `+57` de P02 sin columna
dedicada. (DP-33)

### D6 · Fuera la entidad `REFERIDO`

Un referido nace como `PERSONA` en estado `CONTACTO` con `ATRIBUCION_CAPTACION` hacia quien lo refirió. Era
la entidad de anclaje más débil del modelo (`[DATO]` de la planilla, nadie la pidió) y duplicaba nombre,
teléfonos, referente y seguimiento. Un contacto sin cédula **ya es** nombre + teléfono. Colapsarlas le da
al referido la misma bitácora que a todo lo demás, en vez de un enum sin historial. (DP-32)

### D7 · Todo usuario es antes una persona de la escuela

`USUARIO.persona_id` obligatorio. No hay cuentas anónimas ni compartidas: el guardia de la puerta tiene la
suya porque es miembro y la puerta es su voluntariado (DP-34). Eso hace que `registrado_por` sea siempre
nominal, que era el punto de RN-06, y resuelve la aparente contradicción entre DP-23 (solo un usuario da de
alta) y RN-27 (*"desde seguridad hasta desde la secretaría"*).

*Alternativa descartada*: usuario "puerta" compartido por sede. Simple, pero degrada la auditoría a
"alguien en la puerta" y mata la mitad de RN-06.

### D8 · Autenticación: correo y contraseña de base, Google como atajo

Google no puede ser la única vía: excluye a quien no tenga Gmail y pone el acceso a los datos de la escuela
en manos de un tercero. Como atajo opcional sobre la misma cuenta, enlazado por correo verificado, sí
aporta —quita la gestión de contraseña a quien ya tiene cuenta. (DP-28)

### D9 · Permiso explícito, sugerido por el rol, marcado al cerrar el rol

`ROL_ASIGNADO` tiene vigencia (DP-12); `PERMISO_SEDE` y `PERMISO_AREA` no la tenían. Caso vivo: Milagros
deja relaciones públicas de San Cristóbal, Isdrey lo asume (DP-16), y Milagros seguiría leyendo todo para
siempre. Se mantiene el otorgamiento manual que pidió Milagros (*"cada usuario tendría su grupo de
permisos"*), se añaden `desde`/`hasta`, y al cerrar un rol el sistema genera una marca
`PERMISO_SIN_ROL_VIGENTE`. (DP-35, RN-54)

*Alternativa descartada*: derivar el permiso del rol. Cero mantenimiento, pero contradice lo que ella dijo.

### D10 · La actividad se crea antes, y tiene estado

`PLANIFICADA` / `REALIZADA` / `CANCELADA` (E-20). Sin el estado, una actividad planificada sin asistentes es
indistinguible de una cancelada — y hay caso real: el terremoto de julio-2026 suspendió actividades
culturales. Consecuencia de aplicación: la pantalla de entrada al registro es la lista de actividades
próximas, no el alta de personas. (DP-26, RN-48)

### D11 · Una sola pantalla de participación, mixta

Buscar por nombre, cédula o teléfono → agregar existente con un toque; si no aparece, alta mínima en el
sitio (nombre + teléfono). Esa pantalla produce, sin pedir nada extra: `PARTICIPACION`, el alta mínima,
`ATRIBUCION_CAPTACION` por evento —el bucle A, I=20.07, el requisito de mayor intensidad del análisis—,
`es_interno_en_la_fecha` (RN-17, la cifra del informe), las marcas de D3 y la única transición automática de
la máquina de estados (`CONTACTO → ASISTENTE`). Es la pieza de mayor palanca del sistema. (DP-27, RN-49)

*Alternativa descartada*: formulario completo persona por persona. IMP-25 muestra el caso real: una
actividad con 14 participaciones. 14 × 12 campos es exactamente lo que hoy no se hace.

### D12 · Auditoría: último modificador en todo, bitácora completa en la identidad

`modificado_por` / `modificado_en` transversal; historial completo de cambios solo en `cedula`,
`cedula_tipo`, `nombre`, `apellido` y los teléfonos de `PERSONA_CONTACTO`. Son los únicos campos donde una
edición equivocada rompe en silencio la identidad (ID-1) y el deduplicado (ID-6), y son pocos. (DP-25,
RN-47)

*Alternativa descartada*: bitácora completa en todo. Caro y poco útil. Solo último modificador: pierde lo de
en medio en los campos donde importa.

### D13 · Stack: PWA responsive, PostgreSQL, UUIDv7, UTC (DP-19)

| Decisión | Razón concreta | Alternativa descartada |
|---|---|---|
| **PWA responsive** | Móvil y escritorio con un desarrollo. Sin offline, basta | App nativa: dos desarrollos, sin beneficio ahora |
| **PostgreSQL sobre Supabase** (DP-37) | `docs/03` §1 exige *"consultable por varias personas a la vez"*. Supabase añade dos encajes concretos: Auth resuelve DP-28 completo, y **RLS resuelve RN-27 a RN-30 de forma declarativa** en vez de en código de aplicación | SQLite: aguanta el volumen, no sirve para escrituras concurrentes. Postgres gestionado sin Supabase: habría que construir auth y permisos a mano |
| **UUIDv7 como PK** | Habrá fusión de datos: traslado entre filiales, consolidación de Manuelita, cargas de Excel. Ordenado por tiempo, indexa como entero, seguro en URL | `bigint` secuencial: más fácil de depurar, frágil al fusionar bases |
| **UTC + corte en zona de sede** | Las actividades son vespertinas: el día 31 a las 20:00 local es el día 1 en UTC. Cortar en UTC descuadra el informe por uno | Hora local en almacenamiento: rompe en cuanto una filial esté en otro país |
| **Tecnología conocida** | Bus factor 1 es el riesgo #1 (`docs/03` §9) | Stack novedoso: nadie más lo retoma |

## Risks / Trade-offs

| Riesgo | Mitigación |
|---|---|
| **RN-02 modificada sin la sede.** DP-24 suaviza la obligatoriedad de la cédula, que Milagros afirmó el 30-jul | Marcada `[POR-VALIDAR]` en `docs/03` y `docs/05`. El campo queda nullable con marca de revisión: si ella exige lo contrario, se endurece la validación sin tocar el esquema |
| **La base arranca vacía**, así que el aviso de duplicado no tiene contra qué comparar y Milagros teclea personas que ya existen en el Excel de 2024 | Asumido: el histórico entra a mano cuando la persona reaparece. El importador es un change posterior con IMP-01 a IMP-30 ya escritos |
| **El papel sobrevive.** Sin autorregistro, en un evento de 40 personas alguien teclea en vivo o transcribe después | Declarado en *Non-Goals* y en `docs/03` §1 para que no se lea como promesa incumplida. D11 minimiza el coste por persona |
| **Permiso huérfano** al cambiar de rol | D9: marca `PERMISO_SIN_ROL_VIGENTE`. Depende de que alguien atienda la bandeja |
| **Datos sensibles** (creencias, participación, dos menores reales en los datos de 2024) y percepción pública dividida | Lectura restringida por sede y área (RN-27 a RN-30), ningún listado público (RN-36), representante obligatorio para menores (RN-37). Tensión consciente: no existe borrado (RN-41), contra la recomendación de `docs/01` §9 — registrada en DP-09, no omitida |
| **Bandeja de marcas ignorada**: si nadie resuelve las marcas, "avisa, no bloquea" degenera en "no valida nada" | Contador visible de pendientes por sede y por área. Sin automatismo que las cierre sola |
| **Un solo change grande** con cuatro capabilities | Son inseparables: sin login no hay `registrado_por`, sin actividad no hay participación. Partirlo crearía dependencias entre changes que la herramienta no gestiona |

## Migration Plan

No hay datos que migrar: no existe sistema previo ni esquema anterior. Los Excel siguen vivos en paralelo
hasta que el importador (change posterior) los absorba, y `docs/06` M-3 ya obliga a congelar una copia del
original antes de tocarlo.

Despliegue: esquema y semilla (sedes con su zona horaria, áreas, enums cerrados, catálogo semilla de
ocupaciones y medios según `docs/04` §22) → autenticación con el primer usuario de acceso global →
actividades → participación. Reversión: el esquema es nuevo, se revierte destruyéndolo mientras no haya
datos reales; a partir de la primera actividad registrada, la reversión es por migración hacia atrás.

## Open Questions

1. **DP-24 — cédula obligatoria.** ¿Milagros acepta que se pida y avise en `ASISTENTE` en vez de exigirla?
   Único pendiente que puede cambiar el flujo de la puerta. No bloquea el diseño.
2. **DP-01, menor.** Confirmar que la numeración 1/2/3 de la planilla OINA es la categoría del informe y no
   otra lectura de los círculos. No bloquea nada de este change.
3. **DP-16, mitad viva.** Qué permisos y qué área concretos asume Isdrey. Es carga de datos, no modelo.
4. **Framework, hosting y ORM.** Fuera de DP-19 a propósito: no condicionan el modelo. Se deciden al
   empezar las tareas.
